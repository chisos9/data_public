# This script reproduces the validation exercise on the last 10 observations of
# the sample for models 1 and 2.

rm(list=ls())
cat("\014")

library(forecast)
library(zoo)
library(KFAS)
library(MASS)

setwd('~/Dropbox/EMCC/papers/bhk_gcb_model/replication_code/validation')

gcb_data<-read.csv("../GCB_model_global_2020.csv")
soi_data<-read.csv("../SOI_1866_2019.csv")
SOI<-zooreg(soi_data$mean[94:154],frequency=1,start=1959)  # 1959-2019: 94-154
E_FF<-zooreg(gcb_data$E_FF,frequency=1,start=1959)
E_LUC<-zooreg(gcb_data$E_LUC,frequency=1,start=1959)
E<-zooreg(gcb_data$E_FF+gcb_data$E_LUC,frequency=1,start=1959)
mX1<-zooreg(gcb_data[,c('S_LND','S_OCN','G_ATM','GGDP')],frequency=1,start=1959)
mX<-cbind(E,mX1)
cT<-nrow(mX)
cN<-4
axTime<-(1:cT)
cGtC1959<-2.127*315.39
cGtC1750<-2.127*279
vCreg<-(cGtC1959+cumsum(mX[,4]))
vCreg0<-vCreg/cGtC1750
BIM<-mX[,1]-mX[,2]-mX[,3]-mX[,4]
DE<-diff(E)
DE_FF<-diff(E_FF)
DE_LUC<-diff(E_LUC)

validation_period<-10
endidx<-cT-validation_period
endyear<-gcb_data$Year[endidx]

# Load results from 10-year ahead forecasts from model 1 and 2
# (conditional on observations of World GDP and SOI in case of model 2)
load(file='GCB_model2_results_valid.rda')
mdl.kfs_model2<-mdl.kfs
dfResults20<-dfResults

load(file='GCB_model1_results_valid.rda')
mdl.kfs_model1<-mdl.kfs
dfResults21<-dfResults

load(file='GCB_model2_results.rda')
mdl.kfs_model2_fullsample<-mdl.kfs

rm(mdl.kfs,dfResults)

critval<-1.64

# G_ATM*
middle<-mdl.kfs_model2$a[endidx:cT,2]
high<-mdl.kfs_model2$a[endidx:cT,2]+critval*sqrt(mdl.kfs_model2$P[2,2,endidx:cT])
low<-mdl.kfs_model2$a[endidx:cT,2]-critval*sqrt(mdl.kfs_model2$P[2,2,endidx:cT])
ymax<-max(mX[endidx:cT,4])
ymin<-min(low)
plot(gcb_data$Year[endidx:cT],high,type='l',lwd=1,lty=3,col='blue',xlab='Year',ylab='G_ATM* (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(gcb_data$Year[endidx:cT],rev(gcb_data$Year[endidx:cT])),c(high, rev(low)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(gcb_data$Year[endidx:cT],mX[endidx:cT,4],type='l',lwd=3,lty=3,col='red')
lines(gcb_data$Year[endidx:cT],mdl.kfs_model2_fullsample$alphahat[endidx:cT,2],lwd=2,lty=3,col='green')
lines(gcb_data$Year[endidx:cT],middle,lwd=3,lty=1,col='blue')
lines(gcb_data$Year[endidx:cT],low,lwd=1,lty=3,col='blue')
lines(gcb_data$Year[endidx:cT],mdl.kfs_model1$a[endidx:cT,2],lwd=3,lty=1,col='black')
legend("topleft",c("Data","G_ATM*|full sample","second model","first model"),col=c("red","green","blue","black"),lty=c(3,3,1,1),lwd=c(3,2,3,3),bty='n')

# S_LND signal
middle<-mdl.kfs_model2$m[endidx:cT,3]
high<-mdl.kfs_model2$m[endidx:cT,3]+critval*sqrt(mdl.kfs_model2$F[3,endidx:cT])
low<-mdl.kfs_model2$m[endidx:cT,3]-critval*sqrt(mdl.kfs_model2$F[3,endidx:cT])
ymax<-max(high)
ymin<-min(low)
plot(gcb_data$Year[endidx:cT],high,type='l',lwd=1,lty=3,col='blue',xlab='Year',ylab='S_LND (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(gcb_data$Year[endidx:cT],rev(gcb_data$Year[endidx:cT])),c(high, rev(low)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(gcb_data$Year[endidx:cT],mX[endidx:cT,2],type='l',lwd=3,lty=3,col='red')
lines(gcb_data$Year[endidx:cT],middle,lwd=3,lty=1,col='blue')
lines(gcb_data$Year[endidx:cT],low,lwd=1,lty=3,col='blue')
lines(gcb_data$Year[endidx:cT],mdl.kfs_model1$m[endidx:cT,3],lwd=3,lty=1,col='black')
legend("topleft",c("Data","second model","first model"),col=c("red","blue","black"),lty=c(3,1,1),lwd=c(3,3,3),bty='n')

# S_OCN signal
middle<-mdl.kfs_model2$m[endidx:cT,4]
high<-mdl.kfs_model2$m[endidx:cT,4]+critval*sqrt(mdl.kfs_model2$F[4,endidx:cT])
low<-mdl.kfs_model2$m[endidx:cT,4]-critval*sqrt(mdl.kfs_model2$F[4,endidx:cT])
ymax<-max(high)
ymin<-min(low)
plot(gcb_data$Year[endidx:cT],high,type='l',lwd=1,lty=3,col='blue',xlab='Year',ylab='S_OCN (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(gcb_data$Year[endidx:cT],rev(gcb_data$Year[endidx:cT])),c(high, rev(low)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(gcb_data$Year[endidx:cT],mX[endidx:cT,3],type='l',lwd=3,lty=3,col='red')
lines(gcb_data$Year[endidx:cT],middle,lwd=3,lty=1,col='blue')
lines(gcb_data$Year[endidx:cT],low,lwd=1,lty=3,col='blue')
lines(gcb_data$Year[endidx:cT],mdl.kfs_model1$m[endidx:cT,4],lwd=3,lty=1,col='black')
legend("topleft",c("Data","second model","first model"),col=c("red","blue","black"),lty=c(3,1,1),lwd=c(3,3,3),bty='n')

# E signal
middle<-mdl.kfs_model2$m[endidx:cT,2]
high<-mdl.kfs_model2$m[endidx:cT,2]+critval*sqrt(mdl.kfs_model2$F[2,endidx:cT])
low<-mdl.kfs_model2$m[endidx:cT,2]-critval*sqrt(mdl.kfs_model2$F[2,endidx:cT])
ymax<-max(high)
ymin<-min(low)
plot(gcb_data$Year[endidx:cT],high,type='l',lwd=1,lty=3,col='blue',xlab='Year',ylab='E (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(gcb_data$Year[endidx:cT],rev(gcb_data$Year[endidx:cT])),c(high, rev(low)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(gcb_data$Year[endidx:cT],mX[endidx:cT,1],type='l',lwd=3,lty=3,col='red')
lines(gcb_data$Year[endidx:cT],middle,lwd=3,lty=1,col='blue')
lines(gcb_data$Year[endidx:cT],low,lwd=1,lty=3,col='blue')
lines(gcb_data$Year[endidx:cT],mdl.kfs_model1$m[endidx:cT,2],lwd=3,lty=1,col='black')
legend("topleft",c("Data","second model","first model"),col=c("red","blue","black"),lty=c(3,1,1),lwd=c(3,3,3),bty='n')





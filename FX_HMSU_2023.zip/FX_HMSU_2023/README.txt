This folder contains the LaTeX source files for the paper "Exchange Rates and Macroeconomic Fundamentals: Evidence of Instabilities from Time-Varying Factor Loadings"

- FX_HMSU_main.tex: 		Produces the main paper in the corresponding PDF-file FX_HMSU_main.pdf
- FX_HMSU_Appendices.tex: 	Produces the Appendices to the main paper in the corresponding PDF-file FX_HMSU_Appendices.pdf
- FXpaper.cls: 			Sets the layout of the .tex files

----------------------------------------------------------------------------------------------------------------------------------------------------

FOR ONLINE SUPPLEMENTARY MATERIAL ONLY:
- FX_HMSU_Data_Summary.tex: 	Produces a Summary of the real-time OECD data set and the corresponding PDF-file FX_HMSU_Data_Summary.pdf
- MacroCorrVid.avi:		An animation of the Figure 1 in the paper

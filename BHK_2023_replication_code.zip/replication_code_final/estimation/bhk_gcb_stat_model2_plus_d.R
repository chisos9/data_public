# This program estimates Model 2 in 
# Bennedsen, Hillebrand, and Koopman, "A Statistical Model of the Global Carbon Budget"

rm(list=ls())
cat("\014")

library(forecast)
library(zoo)
library(KFAS)
library(MASS)

SHOW <- FALSE   # shows plots in R window
PLOT <- FALSE  # prints plots to jpg files

setwd('~/Dropbox/EMCC/papers/bhk_gcb_model/replication_code_final/estimation')

# data
gcb_data<-read.csv("../GCB_model_global_2021.csv")
soi_data<-read.csv("../soi_3dp_1866_2020.csv")
SOI<-soi_data$Annual[94:155]  # 1959-2020: 94-155
E_FF<-zooreg(gcb_data$E_FF,frequency=1,start=1959)
E_LUC<-zooreg(gcb_data$E_LUC,frequency=1,start=1959)
E<-zooreg(gcb_data$E_FF+gcb_data$E_LUC,frequency=1,start=1959)
mX1<-zooreg(gcb_data[,c('S_LND','S_OCN','G_ATM','GGDP')],frequency=1,start=1959)  # this is different from not Jan_21 version
mX<-cbind(E,mX1)
cGtC1959<-2.127*315.39
cGtC1750<-2.127*279
vCreg<-(cGtC1959+cumsum(mX[,4]))
vCreg0<-vCreg/cGtC1750
BIM<-mX[,1]-mX[,2]-mX[,3]-mX[,4]
DE<-diff(E)
DE_FF<-diff(E_FF)
DE_LUC<-diff(E_LUC)

# housekeeping
cT<-nrow(mX) # no of obs
cN<-4 # no of measurement variables
cr<-18 # no of state variables
axTime<-(1:cT)

# Definition of state sapce model
va1<-matrix(0,cr,1)
PinitXE<-3
# Big K initialization
mP1<-1000000*diag(1,cr)
mP1[5,5]<-1.5
mP1[6,6]<-0.50
mP1[7,7]<-0.02
mP1[8,8]<-PinitXE
mP1inf<-diag(0,cr)

# define KFAS state space model with mObs as measurement variables
mObs<-cbind(vCreg,E,mX[,2],mX[,3])
mdl<-SSModel(as.matrix(mObs) ~ -1 + SSMcustom(Z=array(NA,c(cN,cr,cT)),T=array(NA,c(cr,cr,cT)),R=array(NA,c(cr,cr,cT)),Q=matrix(NA,cr,cr),a1=va1,P1=mP1,P1inf=mP1inf),H=matrix(0,cN,cN))

# objective function of the state space model
objf <- function(pars,model,estimate=TRUE){
  beta1<-10*exp(-pars[1])/((1+exp(-pars[1]))*cGtC1750)
  beta2<-10*exp(-pars[2])/((1+exp(-pars[2]))*cGtC1750)
  mZ<-matrix(0,cN,cr)
  mZ[1,1]<-mZ[1,5]<-mZ[2,9]<-mZ[3,3]<-mZ[3,6]<-mZ[4,4]<-mZ[4,7]<-1
  mZ1<-array(0,c(cN,cr,cT))
  mZ1[, ,]<-mZ
  mZ1[2,15,39]<-1 # 1997 in E equation
  model$Z<-mZ1
  cInv<-1/(1+beta1+beta2)
  mT<-matrix(0,cr,cr)
  mT[1,1]<-mT[1,8]<-mT[1,9]<-cInv
  mT[1,10]<-mT[1,11]<- -cInv
  mT[2,1]<- -(beta1+beta2)*cInv
  mT[2,8]<-mT[2,9]<-cInv
  mT[2,10]<-mT[2,11]<- -cInv
  mT[3,1]<-mT[3,8]<-mT[3,9]<-beta1*cInv
  mT[3,10]<-(1+beta2)*cInv
  mT[3,11]<- -beta1*cInv
  mT[4,1]<-mT[4,8]<-mT[4,9]<-beta2*cInv
  mT[4,10]<- -beta2*cInv
  mT[4,11]<-(1+beta1)*cInv
  mT[5,5]<-exp(-pars[3])/(1+exp(-pars[3]))
  mT[7,7]<-exp(-pars[4])/(1+exp(-pars[4]))
  mT[8,8]<-exp(-pars[5])/(1+exp(-pars[5]))
  mT[1,16]<-cInv   # plus d in E* equation
  mT[2,16]<-cInv
  mT[3,16]<-beta1*cInv
  mT[4,16]<-beta2*cInv
  mT[9,16]<-1
  mT[9,8]<-mT[9,9]<-mT[10,10]<-mT[11,11]<-mT[12,12]<-mT[13,13]<-mT[14,14]<-mT[15,15]<-mT[16,16]<-mT[17,17]<-mT[18,18]<-1
  mT1<-array(0,c(cr,cr,cT))
  for (j in 1:cT){
    mT1[, , j]<-mT
    if (j<cT){
      mT1[1,14,j]<-mT1[2,14,j]<-mX[j+1,5]*cInv
      mT1[3,14,j]<-beta1*mX[j+1,5]*cInv
      mT1[4,14,j]<-beta2*mX[j+1,5]*cInv
      mT1[9,14,j]<-mX[j+1,5]
    }
    if (j<cT){
      mT1[1,12,j]<- -SOI[j+1]*cInv
      mT1[1,13,j]<- -SOI[j+1]*cInv
      mT1[2,12,j]<- -SOI[j+1]*cInv
      mT1[2,13,j]<- -SOI[j+1]*cInv
      mT1[3,12,j]<-(1+beta2)*SOI[j+1]*cInv
      mT1[3,13,j]<- -beta1*SOI[j+1]*cInv
      mT1[4,12,j]<- -beta2*SOI[j+1]*cInv
      mT1[4,13,j]<-(1+beta1)*SOI[j+1]*cInv
    }
    # if (j==33){  # 1991C                    # to put the 1991 dummy in C or in G_ATM is equivalent, 
    #   mT1[1,17,j]<-cInv                     # this is just a matter of how one wants to define G_ATM
    #   mT1[2,17,j]<- -cInv*(beta1+beta2)     # (shall the spike from the 1991 dummy show in the smoothed process).
    #   mT1[3,17,j]<-beta1*cInv
    #   mT1[4,17,j]<-beta2*cInv
    # }
    if (j==33){  # 1991G_ATM
      mT1[1,17,j]<-cInv
      mT1[2,17,j]<-cInv
      mT1[3,17,j]<-beta1*cInv
      mT1[4,17,j]<-beta2*cInv
    }
    if (j==33){ # 1991E
      mT1[1,18,j]<-mT1[2,18,j]<-cInv
      mT1[3,18,j]<-beta1*cInv
      mT1[4,18,j]<-beta2*cInv
      mT1[9,18,j]<-1
    }
  }
  model$T<-mT1
  mQ<-matrix(0,cr,cr)
  mQ[5,5]<-exp(pars[6]) # var X1
  mQ[6,6]<-exp(pars[7]) # var X2
  mQ[7,7]<-exp(pars[8]) # var X3
  mQ[8,8]<-exp(pars[9]) # var XE
  r12<-(1-exp(-pars[10]))/(1+exp(-pars[10]))
  r13<-(1-exp(-pars[11]))/(1+exp(-pars[11]))
  mQ[5,6]<-mQ[6,5]<-r12*sqrt(mQ[5,5])*sqrt(mQ[6,6])
  mQ[5,7]<-mQ[7,5]<-r13*sqrt(mQ[5,5])*sqrt(mQ[7,7])
  model$Q[, ,1]<-mQ
  s_E<-7*exp(-pars[12])/(1+exp(-pars[12]))
  mR<-matrix(0,cr,cr)
  mR[5:8,5:8]<-diag(4)      # Note that R is incompletely populated:
  mRpar<-mR                 # There are also non-zero entries in cols 1-4 and 9.
  mRpar[8,8]<-s_E           # However, the entries 1-4 and 9 of the state error vector 
  mR1<-array(0,c(cr,cr,cT)) # are zero, and therefore, this doesn't matter.
  # 1959-1995
    mR1[, , 1:37]<-mR
  # 1996-2018
    mR1[, , 38:cT]<-mRpar
  model$R<-mR1
  if (estimate){
    -logLik(model)
  } else {
    model
  }
}

# estimation
load(file="parameters_model2_plus_d.rda")
mdl.opt<-optim(vPi,fn=objf,model=mdl,method="Nelder-Mead",control=list(trace=4,maxit=10000),hessian=TRUE)
vPi<-mdl.opt$par
save(vPi,file="parameters_model2_plus_d.rda")

# evaluate Kalman filter and smoother in the optimum
mdl.fit<-objf(vPi, mdl, estimate = FALSE)
mdl.kfs<-KFS(mdl.fit,filtering=c('state','signal','disturbance'),smoothing=c('state','signal','disturbance'),simplify=FALSE)

# calculate model parameters from transformed parameters inside optimization
beta1_est<-10*exp(-vPi[1])/(1+exp(-vPi[1]))
beta2_est<-10*exp(-vPi[2])/(1+exp(-vPi[2]))
c_est<-1+(beta1_est+beta2_est)/cGtC1750
phi1_est<-exp(-vPi[3])/(1+exp(-vPi[3]))
phi3_est<-exp(-vPi[4])/(1+exp(-vPi[4]))
phi4_est<-exp(-vPi[5])/(1+exp(-vPi[5]))
sigma2_eta1_est<-exp(vPi[6])
sigma2_eta2_est<-exp(vPi[7])
sigma2_eta3_est<-exp(vPi[8])
sigma2_eta4_est<-exp(vPi[9])
r12_est<-(1-exp(-vPi[10]))/(1+exp(-vPi[10]))
r13_est<-(1-exp(-vPi[11]))/(1+exp(-vPi[11]))
s_E_est<-7*exp(-vPi[12])/(1+exp(-vPi[12]))

# parameter estimates from constant states
c1_filt<-mdl.kfs$alphahat[1,10]
c1_filt_se<-sqrt(mdl.kfs$V[10,10,cT])
c2_filt<-mdl.kfs$alphahat[1,11]
c2_filt_se<-sqrt(mdl.kfs$V[11,11,cT])
beta3_filt<-mdl.kfs$alphahat[1,12]
beta3_filt_se<-sqrt(mdl.kfs$V[12,12,cT])
beta4_filt<-mdl.kfs$alphahat[1,13]
beta4_filt_se<-sqrt(mdl.kfs$V[13,13,cT])
beta5_filt<-mdl.kfs$alphahat[1,14]
beta5_filt_se<-sqrt(mdl.kfs$V[14,14,cT])
beta6_filt<-mdl.kfs$alphahat[1,15]
beta6_filt_se<-sqrt(mdl.kfs$V[15,15,cT])
d_filt<-mdl.kfs$alphahat[1,16]
d_filt_se<-sqrt(mdl.kfs$V[16,16,cT])
beta8_filt<-mdl.kfs$alphahat[1,17]
beta8_filt_se<-sqrt(mdl.kfs$V[17,17,cT])
beta9_filt<-mdl.kfs$alphahat[1,18]
beta9_filt_se<-sqrt(mdl.kfs$V[18,18,cT])

# standard errors on MLE påarameters by delta method
mJ<-diag(12)  # Jacobian
mJ[1:2,1:2]<-diag(-10*exp(-vPi[1:2])/(1+exp(-vPi[1:2]))^2)
mJ[3:5,3:5]<-diag(-exp(-vPi[3:5])/(1+exp(-vPi[3:5]))^2)
mJ[6:9,6:9]<-diag(exp(vPi[6:9]))
mJ[10,10]<- -2*exp(-vPi[10])/(1+exp(-vPi[10]))^2
mJ[11,11]<- -2*exp(-vPi[11])/(1+exp(-vPi[11]))^2
mJ[12,12]<- -7*exp(-vPi[12])/(1+exp(-vPi[12]))^2
H_<-ginv(mdl.opt$hessian) # Moore-Penrose inverse from MASS package
vSe<-sqrt(diag(mJ%*%H_%*%mJ))

# Table of all parameter estimates and standard errors
dfResults<-data.frame(
  label=c("beta1","beta2","phi1","phi3","phi4","sigma2_eta1","sigma2_eta2","sigma2_eta3","sigma2_eta4","r12","r13","s_E","c1","c2","beta3","beta4","beta5","beta6","d","beta8","beta9"),
  stringsAsFactors = FALSE,
  coefficients=c(beta1_est,beta2_est,phi1_est,phi3_est,phi4_est,sigma2_eta1_est,sigma2_eta2_est,sigma2_eta3_est,sigma2_eta4_est,r12_est,r13_est,s_E_est,c1_filt,c2_filt,beta3_filt,beta4_filt,beta5_filt,beta6_filt,d_filt,beta8_filt,beta9_filt),
  standarderrors=c(vSe[1],vSe[2],vSe[3],vSe[4],vSe[5],vSe[6],vSe[7],vSe[8],vSe[9],vSe[10],vSe[11],vSe[12],c1_filt_se,c2_filt_se,beta3_filt_se,beta4_filt_se,beta5_filt_se,beta6_filt_se,d_filt_se,beta8_filt_se,beta9_filt_se)
)
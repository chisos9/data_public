# See bhk_gcb_model_v02.pdf for explanations of the models in this sequence.

rm(list=ls())
cat("\014")

library(forecast)
library(zoo)
library(KFAS)
library(MASS)

setwd('~/Dropbox/EMCC/papers/bhk_gcb_model/replication_code_2022/estimation')

# data
gcb_data<-read.csv("../GCB_model_global_2021.csv")
soi_data<-read.csv("~/Dropbox/EMCC/Data/SOI/soi_3dp_1866_2020.csv")
SOI<-soi_data$Annual[94:155]  # 1959-2020: 94-155
E_FF<-zooreg(gcb_data$E_FF,frequency=1,start=1959)
E_LUC<-zooreg(gcb_data$E_LUC,frequency=1,start=1959)
E<-zooreg(gcb_data$E_FF+gcb_data$E_LUC,frequency=1,start=1959)
mX1<-zooreg(gcb_data[,c('S_LND','S_OCN','G_ATM','DGDP')],frequency=1,start=1959)  # this is different from not Jan_21 version
mX<-cbind(E,mX1)
cGtC1959<-2.127*315.39
cGtC1750<-2.127*279
vCreg<-(cGtC1959+cumsum(mX[,4]))
vCreg0<-vCreg/cGtC1750
BIM<-mX[,1]-mX[,2]-mX[,3]-mX[,4]
DE<-diff(E)
DE_FF<-diff(E_FF)
DE_LUC<-diff(E_LUC)

# housekeeping
cT<-nrow(mX) # no of obs
cN<-4 # no of measurement variables
cr<-12 # no of state variables
axTime<-(1:cT)

# Definition of state space model
va1<-matrix(0,cr,1)
PinitXE<-3
# Big K initialization
mP1<-1000000*diag(1,cr)
mP1[5,5]<-1.5
mP1[6,6]<-0.50
mP1[7,7]<-0.02
mP1[8,8]<-PinitXE
mP1inf<-diag(0,cr)

# define KFAS state space model with mObs as measurement variables
mObs<-cbind(vCreg,E,mX[,2],mX[,3])
mdl<-SSModel(as.matrix(mObs) ~ -1 + SSMcustom(Z=matrix(NA,cN,cr),T=matrix(NA,cr,cr),R=matrix(NA,cr,cr),Q=matrix(NA,cr,cr),a1=va1,P1=mP1,P1inf=mP1inf),H=matrix(0,cN,cN))

# objective function of the state space model
objf <- function(pars,model,estimate=TRUE){
  beta1<-10*exp(-pars[1])/((1+exp(-pars[1]))*cGtC1750)
  beta2<-10*exp(-pars[2])/((1+exp(-pars[2]))*cGtC1750)
  mZ<-matrix(0,cN,cr)
  mZ[1,1]<-mZ[1,5]<-mZ[2,9]<-mZ[3,3]<-mZ[3,6]<-mZ[4,4]<-mZ[4,7]<-1
  model$Z[, ,1]<-mZ
  cInv<-1/(1+beta1+beta2)
  mT<-matrix(0,cr,cr)
  mT[1,1]<-mT[1,8]<-mT[1,9]<-mT[1,12]<-cInv
  mT[1,10]<-mT[1,11]<- -cInv
  mT[2,1]<- -(beta1+beta2)*cInv
  mT[2,8]<-mT[2,9]<-mT[2,12]<-cInv
  mT[2,10]<-mT[2,11]<- -cInv
  mT[3,1]<-mT[3,8]<-mT[3,9]<-mT[3,12]<-beta1*cInv
  mT[3,10]<-(1+beta2)*cInv
  mT[3,11]<- -beta1*cInv
  mT[4,1]<-mT[4,8]<-mT[4,9]<-mT[4,12]<-beta2*cInv
  mT[4,10]<- -beta2*cInv
  mT[4,11]<-(1+beta1)*cInv
  mT[5,5]<-exp(-pars[3])/(1+exp(-pars[3]))
  mT[7,7]<-exp(-pars[4])/(1+exp(-pars[4]))
  mT[8,8]<-exp(-pars[5])/(1+exp(-pars[5]))
  mT[9,8]<-mT[9,9]<-mT[9,12]<-mT[10,10]<-mT[11,11]<-mT[12,12]<-1
  model$T[, ,1]<-mT
  mQ<-matrix(0,cr,cr)
  mQ[5,5]<-exp(pars[6]) # var X1
  mQ[6,6]<-exp(pars[7]) # var X2
  mQ[7,7]<-exp(pars[8]) # var X3
  mQ[8,8]<-exp(pars[9]) # var XE
  r12<-(1-exp(-pars[10]))/(1+exp(-pars[10]))
  r13<-(1-exp(-pars[11]))/(1+exp(-pars[11]))
  mQ[5,6]<-mQ[6,5]<-r12*sqrt(mQ[5,5])*sqrt(mQ[6,6])
  mQ[5,7]<-mQ[7,5]<-r13*sqrt(mQ[5,5])*sqrt(mQ[7,7])
  model$Q[, ,1]<-mQ
  mR<-matrix(0,cr,cr)
  mR[5:8,5:8]<-diag(4)      # Note that R is incompletely populated:
                            # There are also non-zero entries in cols 1-4 and 9.
                            # However, the entries 1-4 and 9 of the state error vector 
                            # are zero, and therefore, this doesn't matter.
  model$R[, ,1]<-mR
  if (estimate){
    -logLik(model)
  } else {
    model
  }
}

# estimation
load(file="parameters_model1_noX4.rda") # load parameter start vector (this is a *very* good starting point)
mdl.opt<-optim(vPi,fn=objf,model=mdl,method="Nelder-Mead",control=list(trace=4,maxit=10000),hessian=TRUE) # use your favorite numerical optimizer here
vPi<-mdl.opt$par
save(vPi,file="parameters_model1_noX4.rda") # save incremental improvements

# evaluate Kalman filter and smoother in the optimum
mdl.fit<-objf(vPi, mdl, estimate = FALSE)
mdl.kfs<-KFS(mdl.fit,filtering=c('state','signal','disturbance'),smoothing=c('state','signal','disturbance'),simplify=FALSE)

# save results to file
save(mdl.fit,mdl.kfs,file="GCB_model1_results_noX4.rda")

# calculate model parameters from transformed parameters inside optimization
beta1_est<-10*exp(-vPi[1])/(1+exp(-vPi[1]))
beta2_est<-10*exp(-vPi[2])/(1+exp(-vPi[2]))
c_est<-1+(beta1_est+beta2_est)/cGtC1750
phi1_est<-exp(-vPi[3])/(1+exp(-vPi[3]))
phi3_est<-exp(-vPi[4])/(1+exp(-vPi[4]))
phiE_est<-exp(-vPi[5])/(1+exp(-vPi[5]))
sigma2_eta1_est<-exp(vPi[6])
sigma2_eta2_est<-exp(vPi[7])
sigma2_eta3_est<-exp(vPi[8])
sigma2_etaE_est<-exp(vPi[9])
r12_est<-(1-exp(-vPi[10]))/(1+exp(-vPi[10]))
r13_est<-(1-exp(-vPi[11]))/(1+exp(-vPi[11]))

# parameter estimates from constant states
c1_filt<-mdl.kfs$alphahat[1,10]
c1_filt_se<-sqrt(mdl.kfs$V[10,10,cT])
c2_filt<-mdl.kfs$alphahat[1,11]
c2_filt_se<-sqrt(mdl.kfs$V[11,11,cT])
d_filt<-mdl.kfs$alphahat[1,12]
d_filt_se<-sqrt(mdl.kfs$V[12,12,cT])

# standard errors on MLE parameters by delta method
mJ<-diag(11)  # Jacobian
mJ[1:2,1:2]<-diag(-10*exp(-vPi[1:2])/(1+exp(-vPi[1:2]))^2)
mJ[3:5,3:5]<-diag(-exp(-vPi[3:5])/(1+exp(-vPi[3:5]))^2)
mJ[6:9,6:9]<-diag(exp(vPi[6:9]))
mJ[10,10]<- -2*exp(-vPi[10])/(1+exp(-vPi[10]))^2
mJ[11,11]<- -2*exp(-vPi[11])/(1+exp(-vPi[11]))^2
H_<-ginv(mdl.opt$hessian) # Moore-Penrose inverse from MASS package
vSe<-sqrt(diag(mJ%*%H_%*%mJ))

# Table of all parameter estimates and standard errors
dfResults<-data.frame(
  label=c("beta1","beta2","phi1","phi3","phiE","sigma2_eta1","sigma2_eta2","sigma2_eta3","sigma2_etaE","r12","r13","c1","c2","d"),
  stringsAsFactors = FALSE,
  coefficients=c(beta1_est,beta2_est,phi1_est,phi3_est,phiE_est,sigma2_eta1_est,sigma2_eta2_est,sigma2_eta3_est,sigma2_etaE_est,r12_est,r13_est,c1_filt,c2_filt,d_filt),
  standarderrors=c(vSe[1],vSe[2],vSe[3],vSe[4],vSe[5],vSe[6],vSe[7],vSe[8],vSe[9],vSe[10],vSe[11],c1_filt_se,c2_filt_se,d_filt_se)
)

# Re-run filtering with constant states set at estimated values and initial variance zero
mdl.kfs_old<-mdl.kfs
va1new<-matrix(0,cr,1)
va1new[10:cr]<-mdl.kfs$att[cT,10:cr]
# Big K initialization
mP1new<-1000000*diag(1,cr)
mP1new[5,5]<-1.5
mP1new[6,6]<-0.50
mP1new[7,7]<-0.02
mP1new[8,8]<-PinitXE
mP1new[10:cr,10:cr]<-diag(0,cr-9)
mP1inf<-diag(0,cr)
mdl.fit1<-SSModel(as.matrix(mObs) ~ -1 + SSMcustom(Z=mdl.fit$Z,T=mdl.fit$T,R=mdl.fit$R,Q=mdl.fit$Q,a1=va1new,P1=mP1new,P1inf=mP1inf),H=mdl.fit$H)
mdl.kfs<-KFS(mdl.fit1,filtering=c('state','signal','disturbance'),smoothing=c('state','signal','disturbance'),simplify=FALSE)

# Prepare residual ACF and PACF plots and calculate Ljung-Box stats
stdres<-rstandard(mdl.kfs,type='recursive')
C.acf<-acf(stdres[5:cT,1],plot=FALSE)
C.pacf<-pacf(stdres[5:cT,1],plot=FALSE)
E.acf<-acf(stdres[5:cT,2],plot=FALSE)
E.pacf<-pacf(stdres[5:cT,2],plot=FALSE)
S_LND.acf<-acf(stdres[5:cT,3],plot=FALSE)
S_LND.pacf<-pacf(stdres[5:cT,3],plot=FALSE)
S_OCN.acf<-acf(stdres[5:cT,4],plot=FALSE)
S_OCN.pacf<-pacf(stdres[5:cT,4],plot=FALSE)

# Residual diagnostics on standardized residuals and smoothed disturbances
kurtosis <- function(x) {
  m4 <- mean((x-mean(x))^4)
  kurt <- m4/(sd(x)^4)
  return(kurt)
}
skewness <-  function(x) {
  m3 <- mean((x-mean(x))^3)
  skew <- m3/(sd(x)^3)
  return(skew)
}
jarque_bera <- function(x){
  k<-kurtosis(x)
  s<-skewness(x)
  jb<-cT/6*(s^2+(k-3)^2/4)
  return(jb)
}
durbin_watson <- function(x){
  cn<-length(x)
  x<-x-mean(x)
  num<-sum((x[2:cn]-x[1:(cn-1)])^2)
  den<-sum(x^2)
  dw<-num/den
}
# mDiag0 is a table of residual diagnostics as reported in the paper
# Organization: Mean | Std.Dev. | Skewness | Kurtosis | Ljung-Box(1) | Jarque-Bera | Durbin-Watson
mDiag0<-matrix(NA,4,7)
mDiag0[1,1]<-mean(stdres[5:cT,1])
mDiag0[2,1]<-mean(stdres[5:cT,2])
mDiag0[3,1]<-mean(stdres[5:cT,3])
mDiag0[4,1]<-mean(stdres[5:cT,4])
mDiag0[1,2]<-sd(stdres[5:cT,1])
mDiag0[2,2]<-sd(stdres[5:cT,2])
mDiag0[3,2]<-sd(stdres[5:cT,3])
mDiag0[4,2]<-sd(stdres[5:cT,4])
mDiag0[1,3]<-skewness(stdres[5:cT,1])
mDiag0[2,3]<-skewness(stdres[5:cT,2])
mDiag0[3,3]<-skewness(stdres[5:cT,3])
mDiag0[4,3]<-skewness(stdres[5:cT,4])
mDiag0[1,4]<-kurtosis(stdres[5:cT,1])
mDiag0[2,4]<-kurtosis(stdres[5:cT,2])
mDiag0[3,4]<-kurtosis(stdres[5:cT,3])
mDiag0[4,4]<-kurtosis(stdres[5:cT,4])
stdresC.lb<-Box.test(stdres[5:cT,1],lag=1,type='Ljung-Box')
stdresE.lb<-Box.test(stdres[5:cT,2],lag=1,type='Ljung-Box')
stdresS_LND.lb<-Box.test(stdres[5:cT,3],lag=1,type='Ljung-Box')
stdresS_OCN.lb<-Box.test(stdres[5:cT,4],lag=1,type='Ljung-Box')
mDiag0[1,5]<-stdresC.lb$statistic
mDiag0[2,5]<-stdresE.lb$statistic
mDiag0[3,5]<-stdresS_LND.lb$statistic
mDiag0[4,5]<-stdresS_OCN.lb$statistic
mDiag0[1,6]<-jarque_bera(stdres[5:cT,1])
mDiag0[2,6]<-jarque_bera(stdres[5:cT,2])
mDiag0[3,6]<-jarque_bera(stdres[5:cT,3])
mDiag0[4,6]<-jarque_bera(stdres[5:cT,4])
mDiag0[1,7]<-durbin_watson(stdres[5:cT,1])
mDiag0[2,7]<-durbin_watson(stdres[5:cT,2])
mDiag0[3,7]<-durbin_watson(stdres[5:cT,3])
mDiag0[4,7]<-durbin_watson(stdres[5:cT,4])

# # plot correlograms of standardized residuals
# 
# plot(gcb_data$Year, stdres[,1],type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab=' ')
# title('Standardized residual for C equation')
# 
# plot(C.acf, lwd=5, col="blue", main=" ")
# legend("topright",c("ACF","2-sided 95% CI"),col=c("blue","blue"),lty=c(1,2),lwd=c(5,1),bty='n')
# title('Standardized residual for C equation')
# 
# plot(C.pacf, lwd=5, col="blue", main=" ")
# legend("topright",c("PACF","2-sided 95% CI"),col=c("blue","blue"),lty=c(1,2),lwd=c(5,1),bty='n')
# title('Standardized residual for C equation')
# 
# plot(gcb_data$Year, stdres[,2],type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab=' ')
# title('Standardized residual for E equation')
# 
# plot(E.acf, lwd=5, col="blue", main=" ")
# legend("topright",c("ACF","2-sided 95% CI"),col=c("blue","blue"),lty=c(1,2),lwd=c(5,1),bty='n')
# title('Standardized residual for E equation')
# 
# plot(E.pacf, lwd=5, col="blue", main=" ")
# legend("topright",c("PACF","2-sided 95% CI"),col=c("blue","blue"),lty=c(1,2),lwd=c(5,1),bty='n')
# title('Standardized residual for E equation')
# 
# plot(gcb_data$Year, stdres[,3],type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab=' ')
# title('Standardized residual for S_LND equation')
# 
# plot(S_LND.acf, lwd=5, col="blue", main=" ")
# legend("topright",c("ACF","2-sided 95% CI"),col=c("blue","blue"),lty=c(1,2),lwd=c(5,1),bty='n')
# title('Standardized residual for S_LND equation')
# 
# plot(S_LND.pacf, lwd=5, col="blue", main=" ")
# legend("topright",c("PACF","2-sided 95% CI"),col=c("blue","blue"),lty=c(1,2),lwd=c(5,1),bty='n')
# title('Standardized residual for S_LND equation')
# 
# plot(gcb_data$Year, stdres[,4],type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab=' ')
# title('Standardized residual for S_OCN equation')
# 
# plot(S_OCN.acf, lwd=5, col="blue", main=" ")
# legend("topright",c("ACF","2-sided 95% CI"),col=c("blue","blue"),lty=c(1,2),lwd=c(5,1),bty='n')
# title('Standardized residual for S_OCN equation')
# 
# plot(S_OCN.pacf, lwd=5, col="blue", main=" ")
# legend("topright",c("PACF","2-sided 95% CI"),col=c("blue","blue"),lty=c(1,2),lwd=c(5,1),bty='n')
# title('Standardized residual for S_OCN equation')
# 
# # Plot smoothed states and observations
# 
# smooth_out<-1
# C_smooth<-zooreg(c(matrix(NA,smooth_out,1),mdl.kfs$alphahat[(smooth_out+1):cT,1]),frequency=1,start=1959)
# plot(gcb_data$Year,C_smooth,type='l',lwd=5,col='blue',xlab='Year',ylab='C(GtC)')
# lines(gcb_data$Year,vCreg,type='l',lwd=5,lty=3,col='red')
# legend("topleft",c("smoothed","data"),col=c("blue","red"),lty=c(1,3),lwd=c(5,5),bty='n')
# 
# X1_smooth<-zooreg(c(matrix(NA,smooth_out,1),mdl.kfs$alphahat[(smooth_out+1):cT,5]),frequency=1,start=1959)
# plot(gcb_data$Year,X1_smooth,type='l',lwd=5,col='blue',xlab='Year',ylab='X1(GtC)')
# lines(gcb_data$Year,matrix(0,cT,1),lwd=2,col='black')
# legend("topleft",c("smoothed"),col=c("blue"),lty=c(1),lwd=c(5),bty='n')
# 
# G_ATM_smooth<-zooreg(c(matrix(NA,smooth_out,1),mdl.kfs$alphahat[(smooth_out+1):cT,2]),frequency=1,start=1959)
# plot(gcb_data$Year,mX[,4],type='l',lwd=5,lty=3,col='red',xlab='Year',ylab='G_ATM(GtC/yr)')
# lines(gcb_data$Year,G_ATM_smooth,type='l',lwd=5,col='blue')
# legend("topleft",c("smoothed","data"),col=c("blue","red"),lty=c(1,3),lwd=c(5,5),bty='n')
# 
# E_smooth<-zooreg(c(matrix(NA,smooth_out,1),mdl.kfs$alphahat[(smooth_out+1):cT,9]),frequency=1,start=1959)
# plot(gcb_data$Year,E_smooth,type='l',lwd=5,col='blue',xlab='Year',ylab='E(GtC/yr)')
# lines(gcb_data$Year,E,type='l',lwd=5,lty=3,col='red')
# legend("topleft",c("smoothed","data"),col=c("blue","red"),lty=c(1,3),lwd=c(5,5),bty='n')
# 
# XE_smooth<-zooreg(c(matrix(NA,smooth_out,1),mdl.kfs$alphahat[(smooth_out+1):cT,8]),frequency=1,start=1959)
# plot(gcb_data$Year,XE_smooth,type='l',lwd=5,col='blue',xlab='Year',ylab='XE(GtC/yr)')
# lines(gcb_data$Year,matrix(0,cT,1),lwd=2,col='black')
# legend("topleft",c("smoothed"),col=c("blue"),lty=c(1),lwd=c(5),bty='n')
# 
# S_LND_smooth<-zooreg(c(matrix(NA,smooth_out,1),mdl.kfs$alphahat[(smooth_out+1):cT,3]),frequency=1,start=1959)
# plot(gcb_data$Year,mX[,2],type='l',lwd=5,lty=3,col='red',xlab='Year',ylab='S_LND(GtC/yr)')
# lines(gcb_data$Year,S_LND_smooth,type='l',lwd=5,col='blue')
# legend("topleft",c("smoothed","data"),col=c("blue","red"),lty=c(1,3),lwd=c(5,5),bty='n')
# 
# X2_smooth<-zooreg(c(matrix(NA,smooth_out,1),mdl.kfs$alphahat[(smooth_out+1):cT,6]),frequency=1,start=1959)
# plot(gcb_data$Year,X2_smooth,type='l',lwd=5,col='blue',xlab='Year',ylab='X2(GtC)')
# lines(gcb_data$Year,matrix(0,cT,1),lwd=2,col='black')
# legend("topleft",c("smoothed"),col=c("blue"),lty=c(1),lwd=c(5),bty='n') #
# 
# S_OCN_smooth<-zooreg(c(matrix(NA,smooth_out,1),mdl.kfs$alphahat[(smooth_out+1):cT,4]),frequency=1,start=1959)
# plot(gcb_data$Year,mX[,3],type='l',lwd=5,lty=3,col='red',xlab='Year',ylab='S_OCN(GtC/yr)')
# lines(gcb_data$Year,S_OCN_smooth,type='l',lwd=5,col='blue')
# legend("topleft",c("smoothed","data"),col=c("blue","red"),lty=c(1,3),lwd=c(5,5),bty='n')
# 
# X3_smooth<-zooreg(c(matrix(NA,smooth_out,1),mdl.kfs$alphahat[(smooth_out+1):cT,7]),frequency=1,start=1959)
# plot(gcb_data$Year,X3_smooth,type='l',lwd=5,col='blue',xlab='Year',ylab='X3(GtC/yr)')
# lines(gcb_data$Year,matrix(0,cT,1),lwd=2,col='black') #
# legend("topleft",c("smoothed"),col=c("blue"),lty=c(1),lwd=c(5),bty='n')
# 
# 
# # Plot of filtered and smoothed constant states
# critval<-1.64
# 
# # use original filtered and smoothed states for confidence bands
# mdl.kfs_diagn<-mdl.kfs
# mdl.kfs<-mdl.kfs_old
# 
# # c_1
# plot(gcb_data$Year,mdl.kfs$att[,10],type='l',lwd=5,col='green',xlab='Year',ylab='c_1') # ,ylim=c(-9,-3.5)
# lines(gcb_data$Year,mdl.kfs$alphahat[,10],type='l',lwd=5,col='blue')
# lines(gcb_data$Year,mdl.kfs$alphahat[,10]-critval*sqrt(mdl.kfs$V[10,10,]),type='l',lwd=5,lty=3,col='red')
# lines(gcb_data$Year,mdl.kfs$alphahat[,10]+critval*sqrt(mdl.kfs$V[10,10,]),type='l',lwd=5,lty=3,col='red')
# legend("topright",c("smoothed","90% confidence","filtered"),col=c("blue","red","green"),lty=c(1,3,1),lwd=c(5,5,5),bty='n')
# 
# #c_2
# plot(gcb_data$Year,mdl.kfs$att[,11],type='l',lwd=5,col='green',xlab='Year',ylab='c_2') # ,ylim=c(-7.5,-2)
# lines(gcb_data$Year,mdl.kfs$alphahat[,11],type='l',lwd=5,col='blue')
# lines(gcb_data$Year,mdl.kfs$alphahat[,11]-critval*sqrt(mdl.kfs$V[11,11,]),type='l',lwd=5,lty=3,col='red')
# lines(gcb_data$Year,mdl.kfs$alphahat[,11]+critval*sqrt(mdl.kfs$V[11,11,]),type='l',lwd=5,lty=3,col='red')
# legend("topright",c("smoothed","90% confidence","filtered"),col=c("blue","red","green"),lty=c(1,3,1),lwd=c(5,5,5),bty='n')
# 
# #d
# plot(gcb_data$Year,mdl.kfs$att[,12],type='l',lwd=5,col='green',xlab='Year',ylab='d')
# lines(gcb_data$Year,mdl.kfs$alphahat[,12],type='l',lwd=5,col='blue')
# lines(gcb_data$Year,mdl.kfs$alphahat[,12]-critval*sqrt(mdl.kfs$V[12,12,]),type='l',lwd=5,lty=3,col='red')
# lines(gcb_data$Year,mdl.kfs$alphahat[,12]+critval*sqrt(mdl.kfs$V[12,12,]),type='l',lwd=5,lty=3,col='red')
# legend("bottomright",c("smoothed","90% confidence","filtered"),col=c("blue","red","green"),lty=c(1,3,1),lwd=c(5,5,5),bty='n')
# 

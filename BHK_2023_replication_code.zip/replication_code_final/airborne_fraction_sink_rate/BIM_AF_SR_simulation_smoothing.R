# This program produces the figures of the budget imbalance, the airborne fraction,
# and the sink rate in the paper.  It calls a KFAS routine for simulation smoothing, 
# because confidence bounds on functions of states are required.
# The variance decomposition for BIM reported in the paper is calculated at the 
# end of this file.

rm(list=ls())
cat("\014")

library(forecast)
library(zoo)
library(KFAS)
library(MASS)

SHOW <- TRUE   # shows plots in R window
PLOT <- FALSE  # prints plots to jpg files

setwd('~/Dropbox/EMCC/papers/bhk_gcb_model/replication_code_final/airborne_fraction_sink_rate')
gcb_data<-read.csv("../GCB_model_global_2021.csv")
soi_data<-read.csv("~/Dropbox/EMCC/Data/SOI/soi_3dp_1866_2020.csv")
SOI<-soi_data$Annual[94:155]  # 1959-2020: 94-155
E_FF<-zooreg(gcb_data$E_FF,frequency=1,start=1959)
E_LUC<-zooreg(gcb_data$E_LUC,frequency=1,start=1959)
E<-zooreg(gcb_data$E_FF+gcb_data$E_LUC,frequency=1,start=1959)
mX1<-zooreg(gcb_data[,c('S_LND','S_OCN','G_ATM','GGDP')],frequency=1,start=1959)
mX<-cbind(E,mX1)
cT<-nrow(mX)
cGtC1959<-2.127*315.39
cGtC1750<-2.127*279
vCreg<-(cGtC1959+cumsum(mX[,4]))
vCreg0<-vCreg/cGtC1750
BIM<-mX[,1]-mX[,2]-mX[,3]-mX[,4]

I1991<-matrix(0,cT,1)
I1991[33+1]<-1
I1991<-zooreg(I1991,frequency=1,start=1959)
I1997<-matrix(0,cT,1)
I1997[39]<-1
I1997<-zooreg(I1997,frequency=1,start=1959)

cNumMC<-10000
set.seed(9)

load(file='GCB_model2_results_X1lag.rda') # version w/ lag of X1 as state 16 for BIM
mdl.kfsModel2<-mdl.kfs
mdl.fitModel2<-mdl.fit
rm('mdl.kfs','mdl.fit')

load(file='GCB_model1_results_noX4.rda')
mdl.kfsModel1<-mdl.kfs
mdl.fitModel1<-mdl.fit
rm('mdl.kfs','mdl.fit')

conf<-0.90
up_idx<-ceiling((conf+(1-conf)/2)*cNumMC)
down_idx<-floor((1-conf)/2*cNumMC)

state_sim_model2<-simulateSSM(mdl.fitModel2, type = c("states"), filtered = FALSE, nsim = cNumMC,antithetics = FALSE, conditional = TRUE)

mAFModel2<-matrix(NA,cT-1,cNumMC)
mSRModel2<-matrix(NA,cT-1,cNumMC)
#mBIM<-matrix(NA,cT-1,cNumMC)
for (j in 1:cNumMC){
  mAFModel2[,j]<-state_sim_model2[2:cT,2,j]/state_sim_model2[2:cT,9,j]
  mSRModel2[,j]<-(state_sim_model2[2:cT,3,j]+state_sim_model2[2:cT,4,j])/(state_sim_model2[2:cT,1,j]-cGtC1750)
  #mBIM[,j]<- -state_sim[2:cT,5,j]+state_sim[2:cT,18,j]-state_sim[2:cT,6,j]-state_sim[2:cT,7,j]  # must agree w/ data by def.
}

AF2_up<-matrix(NA,cT-1,1)
AF2_down<-matrix(NA,cT-1,1)
SR2_up<-matrix(NA,cT-1,1)
SR2_down<-matrix(NA,cT-1,1)
for (t in 1:(cT-1)){
  AF_sort<-sort(mAFModel2[t,])
  SR_sort<-sort(mSRModel2[t,])
  AF2_up[t]<-AF_sort[up_idx]
  AF2_down[t]<-AF_sort[down_idx]
  SR2_up[t]<-SR_sort[up_idx]
  SR2_down[t]<-SR_sort[down_idx]
}


state_sim_model1<-simulateSSM(mdl.fitModel1, type = c("states"), filtered = FALSE, nsim = cNumMC,antithetics = FALSE, conditional = TRUE)

mAFModel1<-matrix(NA,cT-1,cNumMC)
mSRModel1<-matrix(NA,cT-1,cNumMC)
#mBIM<-matrix(NA,cT-1,cNumMC)
for (j in 1:cNumMC){
  mAFModel1[,j]<-state_sim_model1[2:cT,2,j]/state_sim_model1[2:cT,9,j]
  mSRModel1[,j]<-(state_sim_model1[2:cT,3,j]+state_sim_model1[2:cT,4,j])/(state_sim_model1[2:cT,1,j]-cGtC1750)
  #mBIM[,j]<- -state_sim[2:cT,5,j]+state_sim[2:cT,18,j]-state_sim[2:cT,6,j]-state_sim[2:cT,7,j]  # must agree w/ data by def.
}

AF1_up<-matrix(NA,cT-1,1)
AF1_down<-matrix(NA,cT-1,1)
SR1_up<-matrix(NA,cT-1,1)
SR1_down<-matrix(NA,cT-1,1)
for (t in 1:(cT-1)){
  AF_sort<-sort(mAFModel1[t,])
  SR_sort<-sort(mSRModel1[t,])
  AF1_up[t]<-AF_sort[up_idx]
  AF1_down[t]<-AF_sort[down_idx]
  SR1_up[t]<-SR_sort[up_idx]
  SR1_down[t]<-SR_sort[down_idx]
}


beta6_filt<-mdl.kfsModel2$alphahat[1,15]
beta8_filt<-mdl.kfsModel2$alphahat[1,17]

BIM_X<- -mdl.kfsModel2$alphahat[,5]+mdl.kfsModel2$alphahat[,16]-mdl.kfsModel2$alphahat[,6]-mdl.kfsModel2$alphahat[,7]-beta8_filt*I1991+beta6_filt*I1997
BIM_PRED<- -mdl.kfsModel2$a[,5]+mdl.kfsModel2$a[,16]-mdl.kfsModel2$a[,6]-mdl.kfsModel2$a[,7]
BIM_PRED<-BIM_PRED[1:cT]
BIM_var<-mdl.kfsModel2$P[7,7,]+mdl.kfsModel2$P[6,6,]+2*mdl.kfsModel2$P[6,7,]+mdl.kfsModel2$P[5,5,]+mdl.kfsModel2$P[16,16,]-2*mdl.kfsModel2$P[16,5,]+2*mdl.kfsModel2$P[5,6,]-2*mdl.kfsModel2$P[16,6,]+2*mdl.kfsModel2$P[5,7,]-2*mdl.kfsModel2$P[16,7,]
BIM_var<-BIM_var[1:cT]

AF_smooth<-mdl.kfsModel2$alphahat[2:cT,2]/mdl.kfsModel2$alphahat[2:cT,9]
AF_smooth1<-mdl.kfsModel1$alphahat[2:cT,2]/mdl.kfsModel1$alphahat[2:cT,9]

SR_smooth<-(mdl.kfsModel2$alphahat[2:cT,3]+mdl.kfsModel2$alphahat[2:cT,4])/(mdl.kfsModel2$alphahat[2:cT,1]-cGtC1750)
SR_smooth1<-(mdl.kfsModel1$alphahat[2:cT,3]+mdl.kfsModel1$alphahat[2:cT,4])/(mdl.kfsModel1$alphahat[2:cT,1]-cGtC1750)


if (SHOW){
  plot(gcb_data$Year,BIM_X,type='l',lwd=3,col='blue',ylim=c(-2.5,2.5),xlab='Year',ylab='GtC/yr')
  lines(BIM,type='l',lwd=2,lty=2,col='red')
  legend("topleft",c("-(Delta(X_1)-X_2+X_3) smoothed","data BIM"),col=c("blue","red"),lty=c(1,3),lwd=c(3,2),bty='n')
  title('Budget Imbalance BIM')
  
  plot(gcb_data$Year,BIM_PRED,type='l',lwd=3,col='blue',ylim=c(-2.5,2.5),xlab='Year',ylab='GtC/yr')
  polygon(c(gcb_data$Year[2:cT],rev(gcb_data$Year[2:cT])),c(BIM_PRED[2:cT]+1.64*sqrt(BIM_var[2:cT]), rev(BIM_PRED[2:cT]-1.64*sqrt(BIM_var[2:cT]))),col=adjustcolor("grey",alpha.f=0.5),border=NA)
  lines(gcb_data$Year,BIM_PRED,type='l',lwd=3,col='blue')
  lines(BIM,type='l',lwd=2,lty=2,col='red')
  legend("topleft",c("-(Delta(X_1)-X_2+X_3) predicted","90% conf.int.","data BIM"),col=c("blue","grey","red"),lty=c(1,1,3),lwd=c(3,3,2),bty='n')
  title('Budget Imbalance BIM')
  
  plot(gcb_data$Year,-mdl.kfsModel2$alphahat[,5]+mdl.kfsModel2$alphahat[,16],type='l',lwd=2,col='black',ylim=c(-2.5,2.5),xlab='Year',ylab='GtC/yr')
  lines(gcb_data$Year,-mdl.kfsModel2$alphahat[,6],type='l',lwd=2,col='green')
  lines(gcb_data$Year,-mdl.kfsModel2$alphahat[,7],type='l',lwd=2,col='red')
  lines(BIM,type='l',lwd=3,lty=1,col='blue')
  legend("topleft",c("BIM data","-Delta(X1)","-X2","-X3"),col=c("blue","black","green","red"),lty=c(1,1,1,1),lwd=c(3,2,2,2),bty='n')
  title('Budget Imbalance BIM')
  
  plot(gcb_data$Year,mX[,4]/mX[,1],type='l',lty=3,lwd=2,col='red',xlab='Year',ylab='ratio')
  polygon(c(gcb_data$Year[2:cT],rev(gcb_data$Year[2:cT])),c(AF2_up, rev(AF2_down)),col=adjustcolor("blue",alpha.f=.5),border=NA)
  polygon(c(gcb_data$Year[2:cT],rev(gcb_data$Year[2:cT])),c(AF1_up, rev(AF1_down)),col=adjustcolor("black",alpha.f=.5),border=NA)
  lines(gcb_data$Year[2:cT],AF_smooth1,type='l',lty=1,lwd=2,col='black')
  lines(gcb_data$Year[2:cT],AF_smooth,type='l',lwd=3,col='blue')
  legend("topright",c("Data","AF full model and 90% conf.int.","AF simplified model and 90% conf.int."),col=c("red","blue","black"),lty=c(3,1,1),lwd=c(2,3,2),bty='n')
  title('Airborne Fraction')
  
  plot(gcb_data$Year,(mX[,2]+mX[,3])/(vCreg-cGtC1750),type='l',lty=3,lwd=2,col='red',xlab='Year',ylab='ratio')
  polygon(c(gcb_data$Year[2:cT],rev(gcb_data$Year[2:cT])),c(SR2_up, rev(SR2_down)),col=adjustcolor("blue",alpha.f=.5),border=NA)
  polygon(c(gcb_data$Year[2:cT],rev(gcb_data$Year[2:cT])),c(SR1_up, rev(SR1_down)),col=adjustcolor("black",alpha.f=.5),border=NA)
  lines(gcb_data$Year[2:cT],SR_smooth1,type='l',lty=1,lwd=2,col='black')
  lines(gcb_data$Year[2:cT],SR_smooth,type='l',lwd=3,col='blue')
  legend("topright",c("Data","SR full model and 90% conf.int.","SR simplified model and 90% conf.int."),col=c("red","blue","black"),lty=c(3,1,1),lwd=c(2,3,2),bty='n')
  title('Sink Rate')
}

if (PLOT){
  
  qual<-100
  wd<-15
  ht<-15
  uts<-"cm"
  resn<-300
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/BIM_2021_logdiff.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,BIM_X,type='l',lwd=3,col='blue',ylim=c(-2.5,2.5),xlab='Year',ylab='GtC/yr')
  lines(BIM,type='l',lwd=2,lty=2,col='red')
  legend("topleft",c("-(Delta(X_1)-X_2+X_3) smoothed","data BIM"),col=c("blue","red"),lty=c(1,3),lwd=c(3,2),bty='n')
  title('Budget Imbalance BIM')
  #dev.off()

  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/BIM_pred_2021_logdiff.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,BIM_PRED,type='l',lwd=3,col='blue',ylim=c(-2.5,2.5),xlab='Year',ylab='GtC/yr')
  polygon(c(gcb_data$Year[2:cT],rev(gcb_data$Year[2:cT])),c(BIM_PRED[2:cT]+1.64*sqrt(BIM_var[2:cT]), rev(BIM_PRED[2:cT]-1.64*sqrt(BIM_var[2:cT]))),col=adjustcolor("grey",alpha.f=0.5),border=NA)
  lines(gcb_data$Year,BIM_PRED,type='l',lwd=3,col='blue')
  lines(BIM,type='l',lwd=2,lty=2,col='red')
  legend("topleft",c("-(Delta(X_1)-X_2+X_3) predicted","90% conf.int.","data BIM"),col=c("blue","grey","red"),lty=c(1,1,3),lwd=c(3,3,2),bty='n')
  title('Budget Imbalance BIM')
  #dev.off()

  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/BIM_X_2021_logdiff.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,-mdl.kfsModel2$alphahat[,5]+mdl.kfsModel2$alphahat[,16],type='l',lwd=2,col='black',ylim=c(-2.5,2.5),xlab='Year',ylab='GtC/yr')
  lines(gcb_data$Year,-mdl.kfsModel2$alphahat[,6],type='l',lwd=2,col='green')
  lines(gcb_data$Year,-mdl.kfsModel2$alphahat[,7],type='l',lwd=2,col='red')
  lines(BIM,type='l',lwd=3,lty=1,col='blue')
  legend("topleft",c("BIM data","-Delta(X1)","-X2","-X3"),col=c("blue","black","green","red"),lty=c(1,1,1,1),lwd=c(3,2,2,2),bty='n')
  title('Budget Imbalance BIM')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/AF_2021_logdiff.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,mX[,4]/mX[,1],type='l',lty=3,lwd=2,col='red',xlab='Year',ylab='ratio')
  polygon(c(gcb_data$Year[2:cT],rev(gcb_data$Year[2:cT])),c(AF2_up, rev(AF2_down)),col=adjustcolor("blue",alpha.f=.5),border=NA)
  polygon(c(gcb_data$Year[2:cT],rev(gcb_data$Year[2:cT])),c(AF1_up, rev(AF1_down)),col=adjustcolor("black",alpha.f=.5),border=NA)
  lines(gcb_data$Year[2:cT],AF_smooth1,type='l',lty=1,lwd=2,col='black')
  lines(gcb_data$Year[2:cT],AF_smooth,type='l',lwd=3,col='blue')
  legend("topright",c("Data","AF full model and 90% conf.int.","AF simplified model and 90% conf.int."),col=c("red","blue","black"),lty=c(3,1,1),lwd=c(2,3,2),bty='n')
  title('Airborne Fraction')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/SR_2021_logdiff.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,(mX[,2]+mX[,3])/(vCreg-cGtC1750),type='l',lty=3,lwd=2,col='red',xlab='Year',ylab='ratio')
  polygon(c(gcb_data$Year[2:cT],rev(gcb_data$Year[2:cT])),c(SR2_up, rev(SR2_down)),col=adjustcolor("blue",alpha.f=.5),border=NA)
  polygon(c(gcb_data$Year[2:cT],rev(gcb_data$Year[2:cT])),c(SR1_up, rev(SR1_down)),col=adjustcolor("black",alpha.f=.5),border=NA)
  lines(gcb_data$Year[2:cT],SR_smooth1,type='l',lty=1,lwd=2,col='black')
  lines(gcb_data$Year[2:cT],SR_smooth,type='l',lwd=3,col='blue')
  legend("topright",c("Data","SR full model and 90% conf.int.","SR simplified model and 90% conf.int."),col=c("red","blue","black"),lty=c(3,1,1),lwd=c(2,3,2),bty='n')
  title('Sink Rate')
  #dev.off()
}

# Variance decomposition
mComp<-matrix(0,cT,3)
mComp[,1]<- -mdl.kfsModel2$alphahat[,5]+mdl.kfsModel2$alphahat[,16]
mComp[,2]<- -mdl.kfsModel2$alphahat[,6]
mComp[,3]<- -mdl.kfsModel2$alphahat[,7]

mCov<-cov(mComp)
cVarBIM<-mCov[1,1]+mCov[2,2]+mCov[3,3]+2*mCov[1,2]+2*mCov[1,3]+2*mCov[2,3]
cComp1<-(mCov[1,1]+mCov[1,2]+mCov[1,3])/cVarBIM
cComp2<-(mCov[2,1]+mCov[2,2]+mCov[2,3])/cVarBIM
cComp3<-(mCov[3,1]+mCov[3,2]+mCov[3,3])/cVarBIM



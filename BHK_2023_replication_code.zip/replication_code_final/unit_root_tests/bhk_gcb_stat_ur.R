# Unit root analysis of the Global Carbon Budget

rm(list=ls())
cat("\014")

library(urca)
library(forecast)
library(zoo)
#library(car)

gcp_data<-read.csv("../GCB_model_global_2021.csv")
soi_data<-read.csv("../soi_3dp_1866_2020.csv")
SOI<-soi_data$Annual[94:155]  # 1959-2020: 94-155
DSOI<-diff(soi_data$Annual[93:155])

mX<-zooreg(gcp_data[,c('E_FF','E_LUC','G_ATM','S_LND','S_OCN','BIM','DGDP')],frequency=1,start=1959)
BIM<-mX[,6]
vE<-mX[,1]+mX[,2]
DDGDP<-diff(mX[,7])

GGDP<-gcp_data$GGDP
DGGDP<-diff(GGDP)

cT<-nrow(gcp_data)
cGtC1959<-2.127*315.39

DE_FF<-diff(mX[,1],lag=1)
DE_LUC<-diff(mX[,2],lag=1)
DE<-diff(vE,lag=1)
DG_ATM<-diff(mX[,3],lag=1)
C<-cumsum(mX[,3])+cGtC1959
DS_LND<-diff(mX[,4],lag=1)
DS_OCN<-diff(mX[,5],lag=1)
DBIM<-diff(BIM,lag=1)


# # Test time series for being I(1): ADF (ur.df), KPSS (ur.kpss) 

# # Fossil Fuel Emissions 
E_FF.df <- ur.df(gcp_data$E_FF,type = "trend",lags = 5,selectlags = "BIC") 
E_FF.dfdrift <- ur.df(gcp_data$E_FF,type = "drift",lags = 5,selectlags = "BIC") 
E_FF.acf <-acf(E_FF.df@res, plot = FALSE) 
# plot(E_FF.acf, main="Autocorrelation function FF Emissions") 
E_FF.pacf<-pacf(E_FF.df@res,plot=FALSE) 
# plot(E_FF.pacf, main="Partial Autocorrelation function FF Emissions") 
DE_FF.df<-ur.df(DE_FF,type="drift",lags=5,selectlags="BIC")
DE_FF.acf<-acf(DE_FF.df@res,plot=FALSE) 
# plot(DE_FF.acf,main="Autocorrelation function Delta FF Emissions") 
DE_FF.pacf<-pacf(DE_FF.df@res,plot=FALSE) 
# plot(DE_FF.pacf, main="Partial Autocorrelation function Delta FF Emissions") 

# # Land Use Change Emissions 
E_LUC.df<-ur.df(gcp_data$E_LUC,type="trend",lags=5,selectlags="BIC") 
E_LUC.dfdrift <- ur.df(gcp_data$E_LUC,type = "drift",lags = 5,selectlags = "BIC") 
E_LUC.lm <- lm(gcp_data$E_LUC[2:cT]~gcp_data$E_LUC[1:(cT-1)])
#linearHypothesis(E_LUC.lm,c("(Intercept)=0","gcp_data$E_LUC[1:60]=1"))
E_LUC.acf<-acf(E_LUC.df@res,plot=FALSE) 
# plot(E_LUC.acf,main="Autocorrelation function LUC Emissions") 
E_LUC.pacf<-pacf(E_LUC.df@res,plot=FALSE) 
# plot(E_LUC.pacf, main="Partial Autocorrelation function LUC Emissions") 
DE_LUC.df<-ur.df(DE_LUC,type="drift",lags=5,selectlags="BIC") 
DE_LUC.acf<-acf(DE_LUC.df@res,plot=FALSE) 
# plot(DE_LUC.acf,main="Autocorrelation function Delta LUC Emissions") 
DE_LUC.pacf<-pacf(DE_LUC.df@res,plot=FALSE) 
# plot(DE_LUC.pacf, main="Partial Autocorrelation function Delta FF Emissions")

# # Anthropogenic emissions
E.df <- ur.df(vE,type = "trend",lags = 5,selectlags = "BIC") 
E.dfdrift <- ur.df(vE,type = "drift",lags = 5,selectlags = "BIC") 
E.acf <-acf(E.df@res, plot = FALSE) 
# plot(E.acf, main="Autocorrelation function Anthr. Emissions") 
E.pacf<-pacf(E.df@res,plot=FALSE) 
# plot(E.pacf, main="Partial Autocorrelation function Anthr. Emissions") 
DE.df<-ur.df(DE,type="drift",lags=5,selectlags="BIC")
DE.acf<-acf(DE.df@res,plot=FALSE) 
# plot(DE.acf,main="Autocorrelation function Delta Anthr. Emissions") 
DE.pacf<-pacf(DE.df@res,plot=FALSE) 
# plot(DE.pacf, main="Partial Autocorrelation function Delta Anthr. Emissions") 

# # Atm. CO2 concentration 
C.df<-ur.df(C,type="trend",lags=5,selectlags="BIC") 
C.acf<-acf(C.df@res,plot=FALSE) 
# plot(C.acf,main="Autocorrelation function Atm. CO2 Concentration") 
C.pacf<-pacf(C.df@res,plot=FALSE) 
# plot(C.pacf, main="Partial Autocorrelation function Atm. CO2 Concentration") 


# # Growth in atm. CO2 concentration 
G_ATM.df<-ur.df(gcp_data$G_ATM,type="trend",lags=5,selectlags="BIC") 
G_ATM.acf<-acf(G_ATM.df@res,plot=FALSE) 
# plot(G_ATM.acf,main="Autocorrelation function Atm. CO2 Concentration") 
G_ATM.pacf<-pacf(G_ATM.df@res,plot=FALSE) 
# plot(G_ATM.pacf, main="Partial Autocorrelation function Atm. CO2 Concentration") 
DG_ATM.df<-ur.df(DG_ATM,type="drift",lags=5,selectlags="BIC") 
DG_ATM.acf<-acf(DG_ATM.df@res,plot=FALSE) 
# plot(DG_ATM.acf,main="Autocorrelation function Delta Atm. CO2 Conc.")
DG_ATM.pacf<-pacf(DG_ATM.df@res,plot=FALSE) 
# plot(DG_ATM.pacf, main="Partial Autocorrelation function Delta Atm. CO2 Conc.") 

# # Ocean sink 
S_OCN.df<-ur.df(gcp_data$S_OCN,type="trend",lags=5,selectlags="BIC") 
S_OCN.acf<-acf(S_OCN.df@res,plot=FALSE) 
# plot(S_OCN.acf,main="Autocorrelation function Ocean Sink") 
S_OCN.pacf<-pacf(S_OCN.df@res,plot=FALSE) 
# plot(S_OCN.pacf, main="Partial Autocorrelation function Ocean Sink") 
DS_OCN.df<-ur.df(DS_OCN,type="drift",lags=5,selectlags="BIC") 
DS_OCN.acf<-acf(DS_OCN.df@res,plot=FALSE) 
# plot(DS_OCN.acf,main="Autocorrelation function Delta Ocean Sink") 
DS_OCN.pacf<-pacf(DS_OCN.df@res,plot=FALSE) 
# plot(DS_OCN.pacf, main="Partial Autocorrelation function Delta Ocean Sink") 

# # Land sink 
S_LND.df<-ur.df(gcp_data$S_LND,type="trend",lags=5,selectlags="BIC") #
S_LND.acf<-acf(S_LND.df@res,plot=FALSE) 
# plot(S_LND.acf,main="Autocorrelation function Land Sink") 
S_LND.pacf<-pacf(S_LND.df@res,plot=FALSE) 
# plot(S_LND.pacf, main="Partial Autocorrelation function Land Sink") 
DS_LND.df<-ur.df(DS_LND,type="drift",lags=5,selectlags="BIC")
DS_LND.acf<-acf(DS_LND.df@res,plot=FALSE) 
# plot(DS_LND.acf,main="Autocorrelation function Delta Land Sink") 
DS_LND.pacf<-pacf(DS_LND.df@res,plot=FALSE) 
# plot(DS_LND.pacf, main="Partial Autocorrelation function Delta Land Sink")

# # Budget imbalance
BIM.df <- ur.df(BIM,type = "trend",lags = 5,selectlags = "BIC") 
BIM.acf <-acf(BIM.df@res, plot = FALSE) 
# plot(BIM.acf, main="Autocorrelation function Budget imbalance") 
BIM.pacf<-pacf(BIM.df@res,plot=FALSE) 
# plot(BIM.pacf, main="Partial Autocorrelation function Budget imbalance") 
DBIM.df<-ur.df(DBIM,type="drift",lags=5,selectlags="BIC")
DBIM.acf<-acf(DBIM.df@res,plot=FALSE) 
# plot(DBIM.acf,main="Autocorrelation function Delta budget imbalance") 
DBIM.pacf<-pacf(DBIM.df@res,plot=FALSE) 
# plot(DBIM.pacf, main="Partial Autocorrelation function Delta budget imbalance")

# # SOI
SOI.df <- ur.df(SOI,type = "trend",lags = 5,selectlags = "BIC") 
SOI.acf <-acf(SOI.df@res, plot = FALSE) 
# plot(SOI.acf, main="Autocorrelation function SOI") 
SOI.pacf<-pacf(SOI.df@res,plot=FALSE) 
# plot(SOI.pacf, main="Partial Autocorrelation function SOI") 
DSOI.df<-ur.df(DSOI,type="drift",lags=5,selectlags="BIC")
DSOI.acf<-acf(DSOI.df@res,plot=FALSE) 
# plot(DSOI.acf,main="Autocorrelation function Delta budget imbalance") 
DSOI.pacf<-pacf(DSOI.df@res,plot=FALSE) 
# plot(DSOI.pacf, main="Partial Autocorrelation function Delta budget imbalance")

# # DGDP
DGDP.df <- ur.df(mX[3:cT,7],type = "trend",lags = 5,selectlags = "BIC") 
DGDP.acf <-acf(DGDP.df@res, plot = FALSE) 
# plot(GGDP.acf, main="Autocorrelation function GGDP") 
DGDP.pacf<-pacf(DGDP.df@res,plot=FALSE) 
# plot(GGDP.pacf, main="Partial Autocorrelation function GGDP") 
DDGDP.df<-ur.df(DDGDP[3:(cT-1)],type="drift",lags=5,selectlags="BIC")
DDGDP.acf<-acf(DDGDP.df@res,plot=FALSE) 
# plot(DGGDP.acf,main="Autocorrelation function Delta GGDP") 
DDGDP.pacf<-pacf(DDGDP.df@res,plot=FALSE) 
# plot(DGGDP.pacf, main="Partial Autocorrelation function Delta GGDP")

# # GGDP
GGDP.df <- ur.df(GGDP,type = "trend",lags = 5,selectlags = "BIC") 
GGDP.acf <-acf(GGDP.df@res, plot = FALSE) 
# plot(GGDP.acf, main="Autocorrelation function GGDP") 
GGDP.pacf<-pacf(GGDP.df@res,plot=FALSE) 
# plot(GGDP.pacf, main="Partial Autocorrelation function GGDP") 
DGGDP.df<-ur.df(DGGDP,type="drift",lags=5,selectlags="BIC")
DGGDP.acf<-acf(DGGDP.df@res,plot=FALSE) 
# plot(DGGDP.acf,main="Autocorrelation function Delta GGDP") 
DGGDP.pacf<-pacf(DGGDP.df@res,plot=FALSE) 
# plot(DGGDP.pacf, main="Partial Autocorrelation function Delta GGDP")


# # Unit root tests:  Phillips-Perron (ur.pp) # # Fossil Fuel Emissions 
E_FF.pp<-ur.pp(gcp_data$E_FF,type="Z-tau",model="trend",lags="short") 
DE_FF.pp<-ur.pp(DE_FF,type="Z-tau",model="constant",lags="short") 
# # Land Use Change Emissions 
E_LUC.pp<-ur.pp(gcp_data$E_LUC,type="Z-tau",model="trend",lags="short")
DE_LUC.pp<-ur.pp(DE_LUC,type="Z-tau",model="constant",lags="short") 
# # Anthropogenic emissions
E.pp<-ur.pp(vE,type="Z-tau",model="trend",lags="short")
DE.pp<-ur.pp(DE,type="Z-tau",model="constant",lags="short") 
# # Atm. CO2 concentration 
C.pp<-ur.pp(C,type="Z-tau",model="trend",lags="short")
# # Growth atm. CO2 concentration 
G_ATM.pp<-ur.pp(gcp_data$G_ATM,type="Z-tau",model="trend",lags="short")
DG_ATM.pp<-ur.pp(DG_ATM,type="Z-tau",model="constant",lags="short") 
# # Ocean sink 
S_OCN.pp<-ur.pp(gcp_data$S_OCN,type="Z-tau",model="trend",lags="short")
DS_OCN.pp<-ur.pp(DS_OCN,type="Z-tau",model="constant",lags="short") 
# # Land sink 
S_LND.pp<-ur.pp(gcp_data$S_LND,type="Z-tau",model="trend",lags="short") 
DS_LND.pp<-ur.pp(DS_LND,type="Z-tau",model="constant",lags="short")
# # Budget imbalance
BIM.pp<-ur.pp(BIM,type="Z-tau",model="trend",lags="short")
DBIM.pp<-ur.pp(DBIM,type="Z-tau",model="constant",lags="short") 
# # SOI
SOI.pp<-ur.pp(SOI,type="Z-tau",model="trend",lags="short")
DSOI.pp<-ur.pp(DSOI,type="Z-tau",model="constant",lags="short") 
# # DGDP
DGDP.pp<-ur.pp(mX[3:cT,7],type="Z-tau",model="trend",lags="short")
DDGDP.pp<-ur.pp(DDGDP[3:(cT-1)],type="Z-tau",model="constant",lags="short") 
# # GGDP
GGDP.pp<-ur.pp(GGDP,type="Z-tau",model="trend",lags="short")
DGGDP.pp<-ur.pp(DGGDP[3:(cT-1)],type="Z-tau",model="constant",lags="short") 

# # Unit root tests:  Kwiatkowski-Phillips-Schmidt-Shin (ur.kpss) 
# # Fossil Fuel Emissions 
E_FF.kpss<-ur.kpss(gcp_data$E_FF,type="tau",lags="short") 
DE_FF.kpss<-ur.kpss(DE_FF,type="mu",lags="short") 
# # Land Use Change Emissions 
E_LUC.kpss<-ur.kpss(gcp_data$E_LUC,type="tau",lags="short") 
DE_LUC.kpss<-ur.kpss(DE_LUC,type="mu",lags="short")
# # Anthropogenic Emissions 
E.kpss<-ur.kpss(vE,type="tau",lags="short") 
DE.kpss<-ur.kpss(DE,type="mu",lags="short") 
# # Atm. CO2 concentration
C.kpss<-ur.kpss(C,type="tau",lags="short")
# # Growth atm. CO2 concentration
G_ATM.kpss<-ur.kpss(gcp_data$G_ATM,type="tau",lags="short") 
G_ATM.kpssmu<-ur.kpss(gcp_data$G_ATM,type="mu",lags="short") 
# # Ocean sink
S_OCN.kpss<-ur.kpss(gcp_data$S_OCN,type="tau",lags="short") 
S_OCN.kpssmu<-ur.kpss(gcp_data$S_OCN,type="mu",lags="short") 
# # Land sink 
S_LND.kpss<-ur.kpss(gcp_data$S_LND,type="tau",lags="short") 
S_LND.kpssmu<-ur.kpss(gcp_data$S_LND,type="mu",lags="short")
# # Budget imbalance 
BIM.kpss<-ur.kpss(BIM,type="tau",lags="short") 
BIM.kpssmu<-ur.kpss(BIM,type="mu",lags="short") 
# # SOI 
SOI.kpss<-ur.kpss(SOI,type="tau",lags="short") 
SOI.kpssmu<-ur.kpss(SOI,type="mu",lags="short") 
# # DGDP
DGDP.kpss<-ur.kpss(mX[3:cT,7],type="tau",lags="short") 
DGDP.kpssmu<-ur.kpss(mX[3:cT,7],type="mu",lags="short") 
# # GGDP
GGDP.kpss<-ur.kpss(GGDP,type="tau",lags="short") 
GGDP.kpssmu<-ur.kpss(GGDP,type="mu",lags="short") 

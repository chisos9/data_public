rm(list=ls())
cat("\014")


library(forecast)
library(zoo)
library(KFAS)
library(MASS)

SHOW <- FALSE   # shows plots in R window
PLOT <- FALSE  # prints plots to jpg files

setwd("~/Dropbox/EMCC/papers/bhk_gcb_model/replication_code_final/data_plots")

gcb_data<-read.csv("../GCB_model_global_2021.csv")
soi_data<-read.csv("../soi_3dp_1866_2020.csv")
SOI<-soi_data$Annual[94:155]  # 1959-2020: 94-155
E_FF<-zooreg(gcb_data$E_FF,frequency=1,start=1959)
E_LUC<-zooreg(gcb_data$E_LUC,frequency=1,start=1959)
E<-zooreg(gcb_data$E_FF+gcb_data$E_LUC,frequency=1,start=1959)
# E[39]<-E[39]-0.55 # kill outlier in E in 1997
mX1<-zooreg(gcb_data[,c('S_LND','S_OCN','G_ATM','DGDP')],frequency=1,start=1959)
mX<-cbind(E,mX1)
cT<-nrow(mX)
cN<-4
cr<-17
axTime<-(1:cT)
cGtC1959<-2.127*315.39
cGtC1750<-2.127*279
vCreg<-(cGtC1959+cumsum(mX[,4]))
vCreg0<-vCreg/cGtC1750
BIM<-mX[,1]-mX[,2]-mX[,3]-mX[,4]

I1991<-matrix(0,cT,1)
I1991[33]<-1
I1991<-zooreg(I1991,frequency=1,start=1959)
I1997<-matrix(0,cT,1)
I1997[39]<-1
I1997<-zooreg(I1997,frequency=1,start=1959)

if (SHOW){

  plot(gcb_data$Year,vCreg,type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC')
  title('Atmospheric CO2 concentrations')

  plot(gcb_data$Year,E_FF,type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('Fossil fuel emissions E_FF')

  plot(gcb_data$Year[2:cT],diff(E_FF),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('First differences E_FF')

  plot(gcb_data$Year,E_LUC,type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('Land-use change emissions E_LUC')

  plot(gcb_data$Year[2:cT],diff(E_LUC),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('First differences E_LUC')

  plot(gcb_data$Year,E,type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('Anthropogenic emissions E=E_FF+E_LUC')

  plot(gcb_data$Year[2:cT],diff(E),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('First differences E')

  plot(gcb_data$Year,mX[,4],type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('First differences C')

  plot(gcb_data$Year[2:cT],diff(mX[,4]),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('First differences G_ATM')

  plot(gcb_data$Year,mX[,2],type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('Land sink S_LND')

  plot(gcb_data$Year[2:cT],diff(mX[,2]),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('First differences S_LND')

  plot(gcb_data$Year,mX[,3],type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('Ocean sink S_OCN')

  plot(gcb_data$Year[2:cT],diff(mX[,3]),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  title('First differences S_OCN')

  plot(gcb_data$Year,gcb_data$GDP/10^12,type='l',lwd=3,col='blue',xlab='Year',ylab='trillion constant 2015 USD')
  title('World GDP in constant 2015 USD')

  plot(gcb_data$Year,gcb_data$DGDP,type='l',lwd=3,col='blue',xlab='Year',ylab='trillion constant 2015 USD')
  title('World GDP differences')

  plot(gcb_data$Year,gcb_data$GGDP,type='l',lwd=3,col='blue',xlab='Year',ylab='percentage')
  title('World GDP log-differences')
  
  plot(gcb_data$Year,SOI,type='l',lwd=3,col='blue',xlab='Year',ylab='studentized')
  title('Southern Oscillation Index')

}

if (PLOT){
  
  qual<-100
  wd<-15
  ht<-15
  uts<-"cm"
  resn<-300

  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/C_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,vCreg,type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC')
  #title('Atmospheric CO2 concentrations')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/E_FF_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,E_FF,type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('Fossil fuel emissions E_FF')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/DE_FF_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year[2:cT],diff(E_FF),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('First differences E_FF')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/E_LUC_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,E_LUC,type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('Land-use change emissions E_LUC')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/DE_LUC_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year[2:cT],diff(E_LUC),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('First differences E_LUC')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/E_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,E,type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('Anthropogenic emissions E=E_FF+E_LUC')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/DE_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year[2:cT],diff(E),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('First differences E')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/G_ATM_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,mX[,4],type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('First differences C')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/DG_ATM_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year[2:cT],diff(mX[,4]),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('First differences G_ATM')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/S_LND_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,mX[,2],type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('Land sink S_LND')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/DS_LND_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year[2:cT],diff(mX[,2]),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('First differences S_LND')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/S_OCN_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,mX[,3],type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('Ocean sink S_OCN')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/DS_OCN_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year[2:cT],diff(mX[,3]),type='l',lwd=5, col="blue", main=" ",xlab='Year',ylab='GtC/year')
  #title('First differences S_OCN')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/GDP_level_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,gcb_data$GDP/10^12,type='l',lwd=3,col='blue',xlab='Year',ylab='trillion constant 2015 USD')
  #title('World GDP in constant 2010 USD')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/GDP_diff_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,gcb_data$DGDP,type='l',lwd=3,col='blue',xlab='Year',ylab='trillion constant 2015 USD')
  #title('World GDP differences')
  #dev.off()
  
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/GDP_growth_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,gcb_data$DGDP,type='l',lwd=3,col='blue',xlab='Year',ylab='percentage')
  #title('World GDP log-differences')
  #dev.off()

  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/SOI_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  plot(gcb_data$Year,SOI,type='l',lwd=3,col='blue',xlab='Year',ylab='studentized')
  #title('Southern Oscillation Index')
  #dev.off()
  
}
# This estimates model 2 on the sample and forecasts cP=3 periods into the future.
# The forecast results from model 1 are loaded from file 'GCB_model1_results_forecast.rda'.
# The forecasts of GDP and SOI are hard-coded into this file.
# This program prints out the forecast figure in the paper. ('bhk_gcb_stat_model1_forecast.R'
# only produces the results file to be used here.)
# The results for the table in the paper are contained in data frames dfFcModel1 and dfFcModel2.
# To use either IMF or World Bank GDP forecasts, use the switch in line 48.

rm(list=ls())
cat("\014")

library(forecast)
library(zoo)
library(KFAS)
library(MASS)

SHOW <- FALSE   # shows plots in R window
PLOT <- FALSE  # prints plots to jpg files

setwd('~/Dropbox/EMCC/papers/bhk_gcb_model/replication_code_final/forecasts')

load(file='GCB_model1_results_forecast.rda')
rm(dfResults)
mdl.kfsbb<-mdl.kfs
rm(mdl.kfs)

gcb_data<-read.csv("../GCB_model_global_2021.csv")
cR<-length(gcb_data$Year)
cP<-3
cT<-cR+cP

soi_data<-read.csv("~/Dropbox/EMCC/Data/SOI/soi_3dp_1866_2020.csv")
SOI_raw<-soi_data$Annual[94:155]  # 1959-2020: 94-155
SOI<-matrix(NA,cT,1)
SOI[1:cR]<-SOI_raw
SOI[(cR+1):cT]<-c(0.558,-0.081,-0.130) # from SOI forecast model
E_FF<-zooreg(gcb_data$E_FF,frequency=1,start=1959)
E_LUC<-zooreg(gcb_data$E_LUC,frequency=1,start=1959)
E<-zooreg(gcb_data$E_FF+gcb_data$E_LUC,frequency=1,start=1959)
mX1<-zooreg(gcb_data[,c('S_LND','S_OCN','G_ATM','GGDP')],frequency=1,start=1959)
mX<-cbind(E,mX1)
GGDP_IMF<-c(gcb_data$GGDP,0.061,0.032,0.029) # from IMF Jul 2022
GDP_IMF<-c(gcb_data$GDP,gcb_data$GDP[cR]*(1+GGDP_IMF[cR+1]),gcb_data$GDP[cR]*(1+GGDP_IMF[cR+1])*(1+GGDP_IMF[cR+2]),gcb_data$GDP[cR]*(1+GGDP_IMF[cR+1])*(1+GGDP_IMF[cR+2])*(1+GGDP_IMF[cR+3]))
DGDP_IMF<-c(gcb_data$DGDP,(GDP_IMF[cR+1]-GDP_IMF[cR])/10^12,(GDP_IMF[cR+2]-GDP_IMF[cR+1])/10^12,(GDP_IMF[cR+3]-GDP_IMF[cR+2])/10^12)
GGDP_WB<-c(gcb_data$GGDP,0.057,0.029,0.030) # from World Bank
GDP_WB<-c(gcb_data$GDP,gcb_data$GDP[cR]*(1+GGDP_WB[cR+1]),gcb_data$GDP[cR]*(1+GGDP_WB[cR+1])*(1+GGDP_WB[cR+2]),gcb_data$GDP[cR]*(1+GGDP_WB[cR+1])*(1+GGDP_WB[cR+2])*(1+GGDP_WB[cR+3]))
DGDP_WB<-c(gcb_data$DGDP,(GDP_WB[cR+1]-GDP_WB[cR])/10^12,(GDP_WB[cR+2]-GDP_WB[cR+1])/10^12,(GDP_WB[cR+3]-GDP_WB[cR+2])/10^12)

# By default, the code uses the IMF forecast.  If you would like to use the World Bank forecast
# instead, overwrite the IMF with the WB forecast by commenting-in the following line.
#DGDP_IMF<-DGDP_WB
cN<-4
cr<-17
axTime<-(1:cR)
cGtC1959<-2.127*315.39
cGtC1750<-2.127*279
vCreg<-(cGtC1959+cumsum(mX[,4]))
vCreg0<-vCreg/cGtC1750
BIM<-mX[,1]-mX[,2]-mX[,3]-mX[,4]

validation_period<-cP
endyear<-gcb_data$Year[cR]+validation_period
year_axis<-(gcb_data$Year[1]:endyear)

# Definition of SSM

va1<-matrix(0,cr,1)

PinitX4<-3
# Big K initialization
mP1<-1000000*diag(1,cr)
mP1[5,5]<-1.5
mP1[6,6]<-0.50
mP1[7,7]<-0.02
mP1[8,8]<-PinitX4
mP1inf<-diag(0,cr)

mObs<-matrix(NA,cT,4)
mObs[1:(cT-validation_period),]<-cbind(vCreg,E,mX[,2],mX[,3])
mdl<-SSModel(as.matrix(mObs) ~ -1 + SSMcustom(Z=array(NA,c(cN,cr,cT)),T=array(NA,c(cr,cr,cT)),R=array(NA,c(cr,cr,cT)),Q=matrix(NA,cr,cr),a1=va1,P1=mP1,P1inf=mP1inf),H=matrix(0,cN,cN))

# objective function of the state space model
objf <- function(pars,model,estimate=TRUE){
  beta1<-10*exp(-pars[1])/((1+exp(-pars[1]))*cGtC1750)
  beta2<-10*exp(-pars[2])/((1+exp(-pars[2]))*cGtC1750)
  mZ<-matrix(0,cN,cr)
  mZ[1,1]<-mZ[1,5]<-mZ[2,9]<-mZ[3,3]<-mZ[3,6]<-mZ[4,4]<-mZ[4,7]<-1
  mZ1<-array(0,c(cN,cr,cT))
  mZ1[, ,]<-mZ
  mZ1[2,15,39]<-1 # 1997 in E equation
  model$Z<-mZ1
  cInv<-1/(1+beta1+beta2)
  mT<-matrix(0,cr,cr)
  mT[1,1]<-mT[1,8]<-mT[1,9]<-cInv
  mT[1,10]<-mT[1,11]<- -cInv
  mT[2,1]<- -(beta1+beta2)*cInv
  mT[2,8]<-mT[2,9]<-cInv
  mT[2,10]<-mT[2,11]<- -cInv
  mT[3,1]<-mT[3,8]<-mT[3,9]<-beta1*cInv
  mT[3,10]<-(1+beta2)*cInv
  mT[3,11]<- -beta1*cInv
  mT[4,1]<-mT[4,8]<-mT[4,9]<-beta2*cInv
  mT[4,10]<- -beta2*cInv
  mT[4,11]<-(1+beta1)*cInv
  mT[5,5]<-exp(-pars[3])/(1+exp(-pars[3]))
  mT[7,7]<-exp(-pars[4])/(1+exp(-pars[4]))
  mT[8,8]<-exp(-pars[5])/(1+exp(-pars[5]))
  mT[9,8]<-mT[9,9]<-mT[10,10]<-mT[11,11]<-mT[12,12]<-mT[13,13]<-mT[14,14]<-mT[15,15]<-mT[16,16]<-mT[17,17]<-1
  mT1<-array(0,c(cr,cr,cT))
  mT1[, ,]<-mT
  # GDP
  mT1[1,14,1:(cT-1)]<-mT1[2,14,1:(cT-1)]<-GGDP_IMF[2:cT]*cInv
  mT1[3,14,1:(cT-1)]<-beta1*GGDP_IMF[2:cT]*cInv
  mT1[4,14,1:(cT-1)]<-beta2*GGDP_IMF[2:cT]*cInv
  mT1[9,14,1:(cT-1)]<-GGDP_IMF[2:cT]
  # SOI
  mT1[1,12,1:(cT-1)]<- -SOI[2:cT]*cInv
  mT1[1,13,1:(cT-1)]<- -SOI[2:cT]*cInv
  mT1[2,12,1:(cT-1)]<- -SOI[2:cT]*cInv
  mT1[2,13,1:(cT-1)]<- -SOI[2:cT]*cInv
  mT1[3,12,1:(cT-1)]<-(1+beta2)*SOI[2:cT]*cInv
  mT1[3,13,1:(cT-1)]<- -beta1*SOI[2:cT]*cInv
  mT1[4,12,1:(cT-1)]<- -beta2*SOI[2:cT]*cInv
  mT1[4,13,1:(cT-1)]<-(1+beta1)*SOI[2:cT]*cInv
  # I1991 in G_ATM*
  mT1[1,16,33]<-cInv
  mT1[2,16,33]<-cInv
  mT1[3,16,33]<-beta1*cInv
  mT1[4,16,33]<-beta2*cInv
  # # I1991 in C*
  # mT1[1,16,33]<-cInv                   # to put the 1991 dummy in C or in G_ATM is equivalent,
  # mT1[2,16,33]<- -cInv*(beta1+beta2)   # this is just a matter of how one wants to define G_ATM  
  # mT1[3,16,33]<-beta1*cInv             # (shall the spike from the 1991 dummy show in the smoothed process).
  # mT1[4,16,33]<-beta2*cInv
  # I1991 in E*
  mT1[1,17,33]<-mT1[2,17,33]<-cInv
  mT1[3,17,33]<-beta1*cInv
  mT1[4,17,33]<-beta2*cInv
  mT1[9,17,33]<-1
  model$T<-mT1
  mQ<-matrix(0,cr,cr)
  mQ[5,5]<-exp(pars[6]) # var X1
  mQ[6,6]<-exp(pars[7]) # var X2
  mQ[7,7]<-exp(pars[8]) # var X3
  mQ[8,8]<-exp(pars[9]) # var XE
  r12<-(1-exp(-pars[10]))/(1+exp(-pars[10]))
  r13<-(1-exp(-pars[11]))/(1+exp(-pars[11]))
  mQ[5,6]<-mQ[6,5]<-r12*sqrt(mQ[5,5])*sqrt(mQ[6,6])
  mQ[5,7]<-mQ[7,5]<-r13*sqrt(mQ[5,5])*sqrt(mQ[7,7])
  model$Q[, ,1]<-mQ
  s_E<-7*exp(-pars[12])/(1+exp(-pars[12]))
  mR<-matrix(0,cr,cr)
  mR[5:8,5:8]<-diag(4)      # Note that R is incompletely populated:
  mRpar<-mR                 # There are also non-zero entries in cols 1-4 and 9.
  mRpar[8,8]<-s_E           # However, the entries 1-4 and 9 of the state error vector 
  mR1<-array(0,c(cr,cr,cT)) # are zero, and therefore, this doesn't matter.
  # 1959-1995
  mR1[, , 1:37]<-mR
  # 1996-2019
  mR1[, , 38:cT]<-mRpar
  model$R<-mR1
  if (estimate){
    -logLik(model)
  } else {
    model
  }
}

load(file="parameters_model2_forecast.rda")
mdl.opt<-optim(vPi,fn=objf,model=mdl,method="Nelder-Mead",control=list(trace=4,maxit=10000),hessian=TRUE)
vPi<-mdl.opt$par
save(vPi,file="parameters_model2_forecast.rda")

mdl.fit<-objf(vPi, mdl, estimate = FALSE)
mdl.kfs<-KFS(mdl.fit,filtering=c('state','signal','disturbance'),smoothing=c('state','signal','disturbance'),simplify=FALSE)

beta1_est<-10*exp(-vPi[1])/(1+exp(-vPi[1]))
beta2_est<-10*exp(-vPi[2])/(1+exp(-vPi[2]))
c_est<-1+(beta1_est+beta2_est)/cGtC1750
phi1_est<-exp(-vPi[3])/(1+exp(-vPi[3]))
phi3_est<-exp(-vPi[4])/(1+exp(-vPi[4]))
phiE_est<-exp(-vPi[5])/(1+exp(-vPi[5]))
sigma2_eta1_est<-exp(vPi[6])
sigma2_eta2_est<-exp(vPi[7])
sigma2_eta3_est<-exp(vPi[8])
sigma2_etaE_est<-exp(vPi[9])
r12_est<-(1-exp(-vPi[10]))/(1+exp(-vPi[10]))
r13_est<-(1-exp(-vPi[11]))/(1+exp(-vPi[11]))
s_E_est<-7*exp(-vPi[12])/(1+exp(-vPi[12]))

c1_filt<-mdl.kfs$alphahat[1,10]
c1_filt_se<-sqrt(mdl.kfs$V[10,10,cT])
c2_filt<-mdl.kfs$alphahat[1,11]
c2_filt_se<-sqrt(mdl.kfs$V[11,11,cT])
beta3_filt<-mdl.kfs$alphahat[1,12]
beta3_filt_se<-sqrt(mdl.kfs$V[12,12,cT])
beta4_filt<-mdl.kfs$alphahat[1,13]
beta4_filt_se<-sqrt(mdl.kfs$V[13,13,cT])
beta5_filt<-mdl.kfs$alphahat[1,14]
beta5_filt_se<-sqrt(mdl.kfs$V[14,14,cT])
beta6_filt<-mdl.kfs$alphahat[1,15]
beta6_filt_se<-sqrt(mdl.kfs$V[15,15,cT])
beta7_filt<-mdl.kfs$alphahat[1,16]
beta7_filt_se<-sqrt(mdl.kfs$V[16,16,cT])
beta8_filt<-mdl.kfs$alphahat[1,17]
beta8_filt_se<-sqrt(mdl.kfs$V[17,17,cT])


# standard errors by delta method
mJ<-diag(12)  # Jacobian
mJ[1:2,1:2]<-diag(-10*exp(-vPi[1:2])/(1+exp(-vPi[1:2]))^2)
mJ[3:5,3:5]<-diag(-exp(-vPi[3:5])/(1+exp(-vPi[3:5]))^2)
mJ[6:9,6:9]<-diag(exp(vPi[6:9]))
mJ[10,10]<- -2*exp(-vPi[10])/(1+exp(-vPi[10]))^2
mJ[11,11]<- -2*exp(-vPi[11])/(1+exp(-vPi[11]))^2
mJ[12,12]<- -7*exp(-vPi[12])/(1+exp(-vPi[12]))^2
# H_<-solve(mdl.opt$hessian) # Fisher
H_<-ginv(mdl.opt$hessian) # Moore-Penrose inverse from MASS package
vSe<-sqrt(diag(mJ%*%H_%*%mJ))

dfResults<-data.frame(
  label=c("beta1","beta2","phi1","phi3","phiE","sigma2_eta1","sigma2_eta2","sigma2_eta3","sigma2_etaE","r12","r13","s_E","c1","c2","beta3","beta4","beta5","beta6","beta7","beta8"),
  stringsAsFactors = FALSE,
  coefficients=c(beta1_est,beta2_est,phi1_est,phi3_est,phiE_est,sigma2_eta1_est,sigma2_eta2_est,sigma2_eta3_est,sigma2_etaE_est,r12_est,r13_est,s_E_est,c1_filt,c2_filt,beta3_filt,beta4_filt,beta5_filt,beta6_filt,beta7_filt,beta8_filt),
  standarderrors=c(vSe[1],vSe[2],vSe[3],vSe[4],vSe[5],vSe[6],vSe[7],vSe[8],vSe[9],vSe[10],vSe[11],vSe[12],c1_filt_se,c2_filt_se,beta3_filt_se,beta4_filt_se,beta5_filt_se,beta6_filt_se,beta7_filt_se,beta8_filt_se)
)

dfFcModel2<-data.frame(
  label=c("2021","2021se","2022","2022se","2023","2023se"),
  stringsAsFactors = FALSE,
  C=c(0,0,0),
  G_ATM=c(0,0,0),
  E=c(0,0,0),
  S_LND=c(0,0,0),
  S_OCN=c(0,0,0)
)

dfFcModel1<-data.frame(
  label=c("2021","2021se","2022","2022se","2023","2023se"),
  stringsAsFactors = FALSE,
  C=c(0,0,0),
  G_ATM=c(0,0,0),
  E=c(0,0,0),
  S_LND=c(0,0,0),
  S_OCN=c(0,0,0)
)

#plots
yrs_bck<-5
critval<-1.64

if (PLOT){
  qual<-100
  wd<-15
  ht<-15
  uts<-"cm"
  resn<-300
}

# C
data<-as.vector(vCreg[(cT-yrs_bck):cT])
pred<-c(matrix(NA,yrs_bck+1-validation_period,1),mdl.kfs$m[(cT-validation_period+1):cT,1])
up<-c(matrix(NA,yrs_bck+1-validation_period,1),pred[(yrs_bck+2-validation_period):(yrs_bck+1)]+critval*sqrt(mdl.kfs$F[1,(cT-validation_period+1):cT]))
down<-c(matrix(NA,yrs_bck+1-validation_period,1),pred[(yrs_bck+2-validation_period):(yrs_bck+1)]-critval*sqrt(mdl.kfs$F[1,(cT-validation_period+1):cT]))
predbb<-c(matrix(NA,yrs_bck+1-validation_period,1),mdl.kfsbb$m[(cT-validation_period+1):cT,1])
upbb<-c(matrix(NA,yrs_bck+1-validation_period,1),predbb[(yrs_bck+2-validation_period):(yrs_bck+1)]+critval*sqrt(mdl.kfsbb$F[1,(cT-validation_period+1):cT]))
downbb<-c(matrix(NA,yrs_bck+1-validation_period,1),predbb[(yrs_bck+2-validation_period):(yrs_bck+1)]-critval*sqrt(mdl.kfsbb$F[1,(cT-validation_period+1):cT]))

dfFcModel2$C[1]<-pred[yrs_bck+1-2]
dfFcModel2$C[2]<-sqrt(mdl.kfs$F[1,(cT-2)])
dfFcModel2$C[3]<-pred[yrs_bck+1-1]
dfFcModel2$C[4]<-sqrt(mdl.kfs$F[1,(cT-1)])
dfFcModel2$C[5]<-pred[yrs_bck+1]
dfFcModel2$C[6]<-sqrt(mdl.kfs$F[1,(cT)])
dfFcModel1$C[1]<-predbb[yrs_bck+1-2]
dfFcModel1$C[2]<-sqrt(mdl.kfsbb$F[1,(cT-2)])
dfFcModel1$C[3]<-predbb[yrs_bck+1-1]
dfFcModel1$C[4]<-sqrt(mdl.kfsbb$F[1,(cT-1)])
dfFcModel1$C[5]<-predbb[yrs_bck+1]
dfFcModel1$C[6]<-sqrt(mdl.kfsbb$F[1,(cT)])

if (SHOW){
  ymax<-max(c(up,upbb,pred,predbb,data),na.rm=TRUE)
  ymin<-min(c(down,downbb,pred,predbb,data),na.rm=TRUE)
  plot(year_axis[(cT-yrs_bck):cT],data,type='l',lwd=4,lty=3,ylim=c(ymin,ymax),col="green",main=" ",xlab='Year',ylab='C (GtC)')
  lines(year_axis[(cT-yrs_bck):cT],predbb,lwd=4,lty=1,col="black")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(upbb, rev(downbb)),col=adjustcolor("black",alpha.f=.1),border=NA)
  lines(year_axis[(cT-yrs_bck):cT],pred,lwd=4,lty=1,col="blue")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(up, rev(down)),col=adjustcolor("blue",alpha.f=.1),border=NA)
  points(year_axis[63],884.38,type='p',pch=19,col='red')
  points(year_axis[63],883.59,type='p',pch=21,col='black')
  arrows(x0=year_axis[63], y0=883.59-critval*.835, x1=year_axis[63], y1=883.59+critval*.835, code=3, angle=90, length=0.1)
  legend("topleft",c("Data","full model, 90% conf.int.","simplified model, 90% conf.int.","observation","Betts et al. forecast"),col=c("green","blue","black","red","black"),lty=c(3,1,1,NA,NA),lwd=c(3,3,3,NA,NA),pch=c(NA,NA,NA,19,21),bty='n')
}
if (PLOT){
  ##jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/forecast_C_logdiff_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  ymax<-max(c(up,upbb,pred,predbb,data),na.rm=TRUE)
  ymin<-min(c(down,downbb,pred,predbb,data),na.rm=TRUE)
  plot(year_axis[(cT-yrs_bck):cT],data,type='l',lwd=4,lty=3,ylim=c(ymin,ymax),col="green",main=" ",xlab='Year',ylab='C (GtC)')
  lines(year_axis[(cT-yrs_bck):cT],predbb,lwd=4,lty=1,col="black")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(upbb, rev(downbb)),col=adjustcolor("black",alpha.f=.1),border=NA)
  lines(year_axis[(cT-yrs_bck):cT],pred,lwd=4,lty=1,col="blue")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(up, rev(down)),col=adjustcolor("blue",alpha.f=.1),border=NA)
  points(year_axis[63],884.38,type='p',pch=19,col='red')
  points(year_axis[63],883.59,type='p',pch=21,col='black')
  arrows(x0=year_axis[63], y0=883.59-critval*.835, x1=year_axis[63], y1=883.59+critval*.835, code=3, angle=90, length=0.1)
  legend("topleft",c("Data","full model, 90% conf.int.","simplified model, 90% conf.int.","observation","Betts et al. forecast"),col=c("green","blue","black","red","black"),lty=c(3,1,1,NA,NA),lwd=c(3,3,3,NA,NA),pch=c(NA,NA,NA,19,21),bty='n')
  #dev.off()
}


# G_ATM
data<-as.vector(gcb_data$G_ATM[(cT-yrs_bck):cT])
pred<-c(matrix(NA,yrs_bck+1-validation_period,1),mdl.kfs$a[(cT-validation_period+1):cT,2])
up<-c(matrix(NA,yrs_bck+1-validation_period,1),pred[(yrs_bck+2-validation_period):(yrs_bck+1)]+critval*sqrt(mdl.kfs$P[2,2,(cT-validation_period+1):cT]))
down<-c(matrix(NA,yrs_bck+1-validation_period,1),pred[(yrs_bck+2-validation_period):(yrs_bck+1)]-critval*sqrt(mdl.kfs$P[2,2,(cT-validation_period+1):cT]))
predbb<-c(matrix(NA,yrs_bck+1-validation_period,1),mdl.kfsbb$a[(cT-validation_period+1):cT,2])
upbb<-c(matrix(NA,yrs_bck+1-validation_period,1),predbb[(yrs_bck+2-validation_period):(yrs_bck+1)]+critval*sqrt(mdl.kfsbb$P[2,2,(cT-validation_period+1):cT]))
downbb<-c(matrix(NA,yrs_bck+1-validation_period,1),predbb[(yrs_bck+2-validation_period):(yrs_bck+1)]-critval*sqrt(mdl.kfsbb$P[2,2,(cT-validation_period+1):cT]))

dfFcModel2$G_ATM[1]<-pred[yrs_bck+1-2]
dfFcModel2$G_ATM[2]<-sqrt(mdl.kfs$P[2,2,(cT-2)])
dfFcModel2$G_ATM[3]<-pred[yrs_bck+1-1]
dfFcModel2$G_ATM[4]<-sqrt(mdl.kfs$P[2,2,(cT-1)])
dfFcModel2$G_ATM[5]<-pred[yrs_bck+1]
dfFcModel2$G_ATM[6]<-sqrt(mdl.kfs$P[2,2,(cT)])
dfFcModel1$G_ATM[1]<-predbb[yrs_bck+1-2]
dfFcModel1$G_ATM[2]<-sqrt(mdl.kfsbb$P[2,2,(cT-2)])
dfFcModel1$G_ATM[3]<-predbb[yrs_bck+1-1]
dfFcModel1$G_ATM[4]<-sqrt(mdl.kfsbb$P[2,2,(cT-1)])
dfFcModel1$G_ATM[5]<-predbb[yrs_bck+1]
dfFcModel1$G_ATM[6]<-sqrt(mdl.kfsbb$P[2,2,(cT)])

if (SHOW){
  ymax<-max(c(up,upbb,pred,predbb,data),na.rm=TRUE)
  ymin<-min(c(down,downbb,pred,predbb,data),na.rm=TRUE)
  plot(year_axis[(cT-yrs_bck):cT],data,type='l',lwd=4,lty=3,ylim=c(ymin,ymax),col="green",main=" ",xlab='Year',ylab='G_ATM (GtC/Yr)')
  lines(year_axis[(cT-yrs_bck):cT],predbb,lwd=4,lty=1,col="black")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(upbb, rev(downbb)),col=adjustcolor("black",alpha.f=.1),border=NA)
  lines(year_axis[(cT-yrs_bck):cT],pred,lwd=4,lty=1,col="blue")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(up, rev(down)),col=adjustcolor("blue",alpha.f=.1),border=NA)
  points(year_axis[63],5.23,type='p',pch=19,col='red')
  points(year_axis[63],4.34,type='p',pch=21,col='black')
  arrows(x0=year_axis[63], y0=4.34-critval*.835, x1=year_axis[63], y1=4.34+critval*.835, code=3, angle=90, length=0.1)
  legend("bottomleft",c("Data","full model, 90% conf.int.","simplified model, 90% conf.int.","observation","Betts et al. forecast"),col=c("green","blue","black","red","black"),lty=c(3,1,1,NA,NA),lwd=c(3,3,3,NA,NA),pch=c(NA,NA,NA,19,21),bty='n')
}

if (PLOT){
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/forecast_G_ATM_logdiff_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  ymax<-max(c(up,upbb,pred,predbb,data),na.rm=TRUE)
  ymin<-min(c(down,downbb,pred,predbb,data),na.rm=TRUE)
  plot(year_axis[(cT-yrs_bck):cT],data,type='l',lwd=4,lty=3,ylim=c(ymin,ymax),col="green",main=" ",xlab='Year',ylab='G_ATM (GtC/Yr)')
  lines(year_axis[(cT-yrs_bck):cT],predbb,lwd=4,lty=1,col="black")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(upbb, rev(downbb)),col=adjustcolor("black",alpha.f=.1),border=NA)
  lines(year_axis[(cT-yrs_bck):cT],pred,lwd=4,lty=1,col="blue")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(up, rev(down)),col=adjustcolor("blue",alpha.f=.1),border=NA)
  points(year_axis[63],5.23,type='p',pch=19,col='red')
  points(year_axis[63],4.34,type='p',pch=21,col='black')
  arrows(x0=year_axis[63], y0=4.34-critval*.835, x1=year_axis[63], y1=4.34+critval*.835, code=3, angle=90, length=0.1)
  legend("bottomleft",c("Data","full model, 90% conf.int.","simplified model, 90% conf.int.","observation","Betts et al. forecast"),col=c("green","blue","black","red","black"),lty=c(3,1,1,NA,NA),lwd=c(3,3,3,NA,NA),pch=c(NA,NA,NA,19,21),bty='n')
  #dev.off()
}

# E
data<-as.vector(E[(cT-yrs_bck):cT])
pred<-c(matrix(NA,yrs_bck+1-validation_period,1),mdl.kfs$m[(cT-validation_period+1):cT,2])
up<-c(matrix(NA,yrs_bck+1-validation_period,1),pred[(yrs_bck+2-validation_period):(yrs_bck+1)]+critval*sqrt(mdl.kfs$F[2,(cT-validation_period+1):cT]))
down<-c(matrix(NA,yrs_bck+1-validation_period,1),pred[(yrs_bck+2-validation_period):(yrs_bck+1)]-critval*sqrt(mdl.kfs$F[2,(cT-validation_period+1):cT]))
predbb<-c(matrix(NA,yrs_bck+1-validation_period,1),mdl.kfsbb$m[(cT-validation_period+1):cT,2])
upbb<-c(matrix(NA,yrs_bck+1-validation_period,1),predbb[(yrs_bck+2-validation_period):(yrs_bck+1)]+critval*sqrt(mdl.kfsbb$F[2,(cT-validation_period+1):cT]))
downbb<-c(matrix(NA,yrs_bck+1-validation_period,1),predbb[(yrs_bck+2-validation_period):(yrs_bck+1)]-critval*sqrt(mdl.kfsbb$F[2,(cT-validation_period+1):cT]))

dfFcModel2$E[1]<-pred[yrs_bck+1-2]
dfFcModel2$E[2]<-sqrt(mdl.kfs$F[2,(cT-2)])
dfFcModel2$E[3]<-pred[yrs_bck+1-1]
dfFcModel2$E[4]<-sqrt(mdl.kfs$F[2,(cT-1)])
dfFcModel2$E[5]<-pred[yrs_bck+1]
dfFcModel2$E[6]<-sqrt(mdl.kfs$F[2,(cT)])
dfFcModel1$E[1]<-predbb[yrs_bck+1-2]
dfFcModel1$E[2]<-sqrt(mdl.kfsbb$F[2,(cT-2)])
dfFcModel1$E[3]<-predbb[yrs_bck+1-1]
dfFcModel1$E[4]<-sqrt(mdl.kfsbb$F[2,(cT-1)])
dfFcModel1$E[5]<-predbb[yrs_bck+1]
dfFcModel1$E[6]<-sqrt(mdl.kfsbb$F[2,(cT)])

if (SHOW){
  ymax<-max(c(up,upbb,pred,predbb,data),na.rm=TRUE)
  ymin<-min(c(down,downbb,pred,predbb,data),na.rm=TRUE)
  plot(year_axis[(cT-yrs_bck):cT],data,type='l',lwd=4,lty=3,ylim=c(ymin,ymax),col="green",main=" ",xlab='Year',ylab='E (GtC/Yr)')
  lines(year_axis[(cT-yrs_bck):cT],predbb,lwd=4,lty=1,col="black")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(upbb, rev(downbb)),col=adjustcolor("black",alpha.f=.1),border=NA)
  lines(year_axis[(cT-yrs_bck):cT],pred,lwd=4,lty=1,col="blue")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(up, rev(down)),col=adjustcolor("blue",alpha.f=.1),border=NA)
  legend("bottomleft",c("Data","full model, 90% conf.int.","simplified model, 90% conf.int."),col=c("green","blue","black"),lty=c(3,1,1),lwd=c(3,3,3),bty='n')
}

if (PLOT){
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/forecast_E_logdiff_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  ymax<-max(c(up,upbb,pred,predbb,data),na.rm=TRUE)
  ymin<-min(c(down,downbb,pred,predbb,data),na.rm=TRUE)
  plot(year_axis[(cT-yrs_bck):cT],data,type='l',lwd=4,lty=3,ylim=c(ymin,ymax),col="green",main=" ",xlab='Year',ylab='E (GtC/Yr)')
  lines(year_axis[(cT-yrs_bck):cT],predbb,lwd=4,lty=1,col="black")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(upbb, rev(downbb)),col=adjustcolor("black",alpha.f=.1),border=NA)
  lines(year_axis[(cT-yrs_bck):cT],pred,lwd=4,lty=1,col="blue")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(up, rev(down)),col=adjustcolor("blue",alpha.f=.1),border=NA)
  legend("bottomleft",c("Data","full model, 90% conf.int.","simplified model, 90% conf.int."),col=c("green","blue","black"),lty=c(3,1,1),lwd=c(3,3,3),bty='n')
  #dev.off()
}


# S_LND
data<-as.vector(gcb_data$S_LND[(cT-yrs_bck):cT])
pred<-c(matrix(NA,yrs_bck+1-validation_period,1),mdl.kfs$m[(cT-validation_period+1):cT,3])
up<-c(matrix(NA,yrs_bck+1-validation_period,1),pred[(yrs_bck+2-validation_period):(yrs_bck+1)]+critval*sqrt(mdl.kfs$F[3,(cT-validation_period+1):cT]))
down<-c(matrix(NA,yrs_bck+1-validation_period,1),pred[(yrs_bck+2-validation_period):(yrs_bck+1)]-critval*sqrt(mdl.kfs$F[3,(cT-validation_period+1):cT]))
predbb<-c(matrix(NA,yrs_bck+1-validation_period,1),mdl.kfsbb$m[(cT-validation_period+1):cT,3])
upbb<-c(matrix(NA,yrs_bck+1-validation_period,1),predbb[(yrs_bck+2-validation_period):(yrs_bck+1)]+critval*sqrt(mdl.kfsbb$F[3,(cT-validation_period+1):cT]))
downbb<-c(matrix(NA,yrs_bck+1-validation_period,1),predbb[(yrs_bck+2-validation_period):(yrs_bck+1)]-critval*sqrt(mdl.kfsbb$F[3,(cT-validation_period+1):cT]))

dfFcModel2$S_LND[1]<-pred[yrs_bck+1-2]
dfFcModel2$S_LND[2]<-sqrt(mdl.kfs$F[3,(cT-2)])
dfFcModel2$S_LND[3]<-pred[yrs_bck+1-1]
dfFcModel2$S_LND[4]<-sqrt(mdl.kfs$F[3,(cT-1)])
dfFcModel2$S_LND[5]<-pred[yrs_bck+1]
dfFcModel2$S_LND[6]<-sqrt(mdl.kfs$F[3,(cT)])
dfFcModel1$S_LND[1]<-predbb[yrs_bck+1-2]
dfFcModel1$S_LND[2]<-sqrt(mdl.kfsbb$F[3,(cT-2)])
dfFcModel1$S_LND[3]<-predbb[yrs_bck+1-1]
dfFcModel1$S_LND[4]<-sqrt(mdl.kfsbb$F[3,(cT-1)])
dfFcModel1$S_LND[5]<-predbb[yrs_bck+1]
dfFcModel1$S_LND[6]<-sqrt(mdl.kfsbb$F[3,(cT)])

if (SHOW){
  ymax<-max(c(up,upbb,pred,predbb,data),na.rm=TRUE)
  ymin<-min(c(down,downbb,pred,predbb,data),na.rm=TRUE)
  plot(year_axis[(cT-yrs_bck):cT],data,type='l',lwd=4,lty=3,ylim=c(ymin,ymax),col="green",main=" ",xlab='Year',ylab='S_LND (GtC/Yr)')
  lines(year_axis[(cT-yrs_bck):cT],predbb,lwd=4,lty=1,col="black")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(upbb, rev(downbb)),col=adjustcolor("black",alpha.f=.1),border=NA)
  lines(year_axis[(cT-yrs_bck):cT],pred,lwd=4,lty=1,col="blue")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(up, rev(down)),col=adjustcolor("blue",alpha.f=.1),border=NA)
  legend("topleft",c("Data","full model, 90% conf.int.","simplified model, 90% conf.int."),col=c("green","blue","black"),lty=c(3,1,1),lwd=c(3,3,3),bty='n')
}

if (PLOT){
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/forecast_S_LND_logdiff_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  ymax<-max(c(up,upbb,pred,predbb,data),na.rm=TRUE)
  ymin<-min(c(down,downbb,pred,predbb,data),na.rm=TRUE)
  plot(year_axis[(cT-yrs_bck):cT],data,type='l',lwd=4,lty=3,ylim=c(ymin,ymax),col="green",main=" ",xlab='Year',ylab='S_LND (GtC/Yr)')
  lines(year_axis[(cT-yrs_bck):cT],predbb,lwd=4,lty=1,col="black")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(upbb, rev(downbb)),col=adjustcolor("black",alpha.f=.1),border=NA)
  lines(year_axis[(cT-yrs_bck):cT],pred,lwd=4,lty=1,col="blue")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(up, rev(down)),col=adjustcolor("blue",alpha.f=.1),border=NA)
  legend("topleft",c("Data","full model, 90% conf.int.","simplified model, 90% conf.int."),col=c("green","blue","black"),lty=c(3,1,1),lwd=c(3,3,3),bty='n')
  #dev.off()
}

# S_OCN
data<-as.vector(gcb_data$S_OCN[(cT-yrs_bck):cT])
pred<-c(matrix(NA,yrs_bck+1-validation_period,1),mdl.kfs$m[(cT-validation_period+1):cT,4])
up<-c(matrix(NA,yrs_bck+1-validation_period,1),pred[(yrs_bck+2-validation_period):(yrs_bck+1)]+critval*sqrt(mdl.kfs$F[4,(cT-validation_period+1):cT]))
down<-c(matrix(NA,yrs_bck+1-validation_period,1),pred[(yrs_bck+2-validation_period):(yrs_bck+1)]-critval*sqrt(mdl.kfs$F[4,(cT-validation_period+1):cT]))
predbb<-c(matrix(NA,yrs_bck+1-validation_period,1),mdl.kfsbb$m[(cT-validation_period+1):cT,4])
upbb<-c(matrix(NA,yrs_bck+1-validation_period,1),predbb[(yrs_bck+2-validation_period):(yrs_bck+1)]+critval*sqrt(mdl.kfsbb$F[4,(cT-validation_period+1):cT]))
downbb<-c(matrix(NA,yrs_bck+1-validation_period,1),predbb[(yrs_bck+2-validation_period):(yrs_bck+1)]-critval*sqrt(mdl.kfsbb$F[4,(cT-validation_period+1):cT]))

dfFcModel2$S_OCN[1]<-pred[yrs_bck+1-2]
dfFcModel2$S_OCN[2]<-sqrt(mdl.kfs$F[4,(cT-2)])
dfFcModel2$S_OCN[3]<-pred[yrs_bck+1-1]
dfFcModel2$S_OCN[4]<-sqrt(mdl.kfs$F[4,(cT-1)])
dfFcModel2$S_OCN[5]<-pred[yrs_bck+1]
dfFcModel2$S_OCN[6]<-sqrt(mdl.kfs$F[4,(cT)])
dfFcModel1$S_OCN[1]<-predbb[yrs_bck+1-2]
dfFcModel1$S_OCN[2]<-sqrt(mdl.kfsbb$F[4,(cT-2)])
dfFcModel1$S_OCN[3]<-predbb[yrs_bck+1-1]
dfFcModel1$S_OCN[4]<-sqrt(mdl.kfsbb$F[4,(cT-1)])
dfFcModel1$S_OCN[5]<-predbb[yrs_bck+1]
dfFcModel1$S_OCN[6]<-sqrt(mdl.kfsbb$F[4,(cT)])

if (SHOW){
  ymax<-max(c(up,upbb,pred,predbb,data),na.rm=TRUE)
  ymin<-min(c(down,downbb,pred,predbb,data),na.rm=TRUE)
  plot(year_axis[(cT-yrs_bck):cT],data,type='l',lwd=4,lty=3,ylim=c(ymin,ymax),col="green",main=" ",xlab='Year',ylab='S_OCN (GtC/Yr)')
  lines(year_axis[(cT-yrs_bck):cT],predbb,lwd=4,lty=1,col="black")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(upbb, rev(downbb)),col=adjustcolor("black",alpha.f=.1),border=NA)
  lines(year_axis[(cT-yrs_bck):cT],pred,lwd=4,lty=1,col="blue")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(up, rev(down)),col=adjustcolor("blue",alpha.f=.1),border=NA)
  legend("topleft",c("Data","full model, 90% conf.int.","simplified model, 90% conf.int."),col=c("green","blue","black"),lty=c(3,1,1),lwd=c(3,3,3),bty='n')
}

if (PLOT){
  #jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures/forecast_S_OCN_logdiff_2021.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
  ymax<-max(c(up,upbb,pred,predbb,data),na.rm=TRUE)
  ymin<-min(c(down,downbb,pred,predbb,data),na.rm=TRUE)
  plot(year_axis[(cT-yrs_bck):cT],data,type='l',lwd=4,lty=3,ylim=c(ymin,ymax),col="green",main=" ",xlab='Year',ylab='S_OCN (GtC/Yr)')
  lines(year_axis[(cT-yrs_bck):cT],predbb,lwd=4,lty=1,col="black")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(upbb, rev(downbb)),col=adjustcolor("black",alpha.f=.1),border=NA)
  lines(year_axis[(cT-yrs_bck):cT],pred,lwd=4,lty=1,col="blue")
  polygon(c(year_axis[(cT-yrs_bck):cT],rev(year_axis[(cT-yrs_bck):cT])),c(up, rev(down)),col=adjustcolor("blue",alpha.f=.1),border=NA)
  legend("topleft",c("Data","full model, 90% conf.int.","simplified model, 90% conf.int."),col=c("green","blue","black"),lty=c(3,1,1),lwd=c(3,3,3),bty='n')
  #dev.off()
}


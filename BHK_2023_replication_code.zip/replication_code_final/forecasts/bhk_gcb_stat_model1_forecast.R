# This estimates model 1 on the sample and forecasts cP=3 periods into the future.
# The result is stored in the file 'GCB_model1_results_forecast.rda', which is
# read by 'bhk_gcb_stat_model2_forecast.R'.  


rm(list=ls())
cat("\014")

library(forecast)
library(zoo)
library(KFAS)
library(MASS)

setwd('~/Dropbox/EMCC/papers/bhk_gcb_model/replication_code_final/forecasts')

gcb_data<-read.csv("../GCB_model_global_2021.csv")
cR<-length(gcb_data$Year)
cP<-3
cT<-cR+cP
E_FF<-zooreg(gcb_data$E_FF,frequency=1,start=1959)
E_LUC<-zooreg(gcb_data$E_LUC,frequency=1,start=1959)
E<-zooreg(gcb_data$E_FF+gcb_data$E_LUC,frequency=1,start=1959)
mX1<-zooreg(gcb_data[,c('S_LND','S_OCN','G_ATM','DGDP')],frequency=1,start=1959)  # this is different from not Jan_21 version
mX<-cbind(E,mX1)
cN<-4
cr<-12
axTime<-(1:cR)
cGtC1959<-2.127*315.39
cGtC1750<-2.127*279
vCreg<-(cGtC1959+cumsum(mX[,4]))
vCreg0<-vCreg/cGtC1750
BIM<-mX[,1]-mX[,2]-mX[,3]-mX[,4]

validation_period<-cP
endyear<-gcb_data$Year[cT-validation_period]+validation_period
year_axis<-(gcb_data$Year[1]:endyear)

# Definition of SSM

va1<-matrix(0,cr,1)
PinitX4<-3
# Big K initialization
mP1<-1000000*diag(1,cr)
mP1[5,5]<-1.5
mP1[6,6]<-0.50
mP1[7,7]<-0.02
mP1[8,8]<-PinitX4
mP1inf<-diag(0,cr)

mObs<-matrix(NA,cT,4)
mObs[1:(cT-validation_period),]<-cbind(vCreg,E,mX[,2],mX[,3])
mdl<-SSModel(as.matrix(mObs) ~ -1 + SSMcustom(Z=matrix(NA,cN,cr),T=matrix(NA,cr,cr),R=matrix(NA,cr,cr),Q=matrix(NA,cr,cr),a1=va1,P1=mP1,P1inf=mP1inf),H=matrix(0,cN,cN))

objf <- function(pars,model,estimate=TRUE){
  beta1<-10*exp(-pars[1])/((1+exp(-pars[1]))*cGtC1750)
  beta2<-10*exp(-pars[2])/((1+exp(-pars[2]))*cGtC1750)
  mZ<-matrix(0,cN,cr)
  mZ[1,1]<-mZ[1,5]<-mZ[2,9]<-mZ[3,3]<-mZ[3,6]<-mZ[4,4]<-mZ[4,7]<-1
  model$Z[, ,1]<-mZ
  cInv<-1/(1+beta1+beta2)
  mT<-matrix(0,cr,cr)
  mT[1,1]<-mT[1,8]<-mT[1,9]<-mT[1,12]<-cInv
  mT[1,10]<-mT[1,11]<- -cInv
  mT[2,1]<- -(beta1+beta2)*cInv
  mT[2,8]<-mT[2,9]<-mT[2,12]<-cInv
  mT[2,10]<-mT[2,11]<- -cInv
  mT[3,1]<-mT[3,8]<-mT[3,9]<-mT[3,12]<-beta1*cInv
  mT[3,10]<-(1+beta2)*cInv
  mT[3,11]<- -beta1*cInv
  mT[4,1]<-mT[4,8]<-mT[4,9]<-mT[4,12]<-beta2*cInv
  mT[4,10]<- -beta2*cInv
  mT[4,11]<-(1+beta1)*cInv
  mT[5,5]<-exp(-pars[3])/(1+exp(-pars[3]))
  mT[7,7]<-exp(-pars[4])/(1+exp(-pars[4]))
  mT[8,8]<-exp(-pars[5])/(1+exp(-pars[5]))
  mT[9,8]<-mT[9,9]<-mT[9,12]<-mT[10,10]<-mT[11,11]<-mT[12,12]<-1
  model$T[, ,1]<-mT
  mQ<-matrix(0,cr,cr)
  mQ[5,5]<-exp(pars[6]) # var X1
  mQ[6,6]<-exp(pars[7]) # var X2
  mQ[7,7]<-exp(pars[8]) # var X3
  mQ[8,8]<-exp(pars[9]) # var X4
  r12<-(1-exp(-pars[10]))/(1+exp(-pars[10]))
  r13<-(1-exp(-pars[11]))/(1+exp(-pars[11]))
  mQ[5,6]<-mQ[6,5]<-r12*sqrt(mQ[5,5])*sqrt(mQ[6,6])
  mQ[5,7]<-mQ[7,5]<-r13*sqrt(mQ[5,5])*sqrt(mQ[7,7])
  model$Q[, ,1]<-mQ
  mR<-matrix(0,cr,cr)
  mR[5:8,5:8]<-diag(4)      # Note that R is incompletely populated:
  # There are also non-zero entries in cols 1-4 and 9.
  # However, the entries 1-4 and 9 of the state error vector 
  # are zero, and therefore, this doesn't matter.
  model$R[, ,1]<-mR
  if (estimate){
    -logLik(model)
  } else {
    model
  }
}

load(file="parameters_model1_forecast.rda")
mdl.opt<-optim(vPi,fn=objf,model=mdl,method="Nelder-Mead",control=list(trace=4,maxit=10000),hessian=TRUE)
vPi<-mdl.opt$par
save(vPi,file="parameters_model1_forecast.rda")

mdl.fit<-objf(vPi, mdl, estimate = FALSE)
mdl.kfs<-KFS(mdl.fit,filtering=c('state','signal','disturbance'),smoothing=c('state','signal','disturbance'),simplify=FALSE)

beta1_est<-10*exp(-vPi[1])/(1+exp(-vPi[1]))
beta2_est<-10*exp(-vPi[2])/(1+exp(-vPi[2]))
c_est<-1+(beta1_est+beta2_est)/cGtC1750
phi1_est<-exp(-vPi[3])/(1+exp(-vPi[3]))
phi3_est<-exp(-vPi[4])/(1+exp(-vPi[4]))
phiE_est<-exp(-vPi[5])/(1+exp(-vPi[5]))
sigma2_eta1_est<-exp(vPi[6])
sigma2_eta2_est<-exp(vPi[7])
sigma2_eta3_est<-exp(vPi[8])
sigma2_etaE_est<-exp(vPi[9])
r12_est<-(1-exp(-vPi[10]))/(1+exp(-vPi[10]))
r13_est<-(1-exp(-vPi[11]))/(1+exp(-vPi[11]))

c1_filt<-mdl.kfs$alphahat[1,10]
c1_filt_se<-sqrt(mdl.kfs$V[10,10,cT])
c2_filt<-mdl.kfs$alphahat[1,11]
c2_filt_se<-sqrt(mdl.kfs$V[11,11,cT])
d_filt<-mdl.kfs$alphahat[1,12]
d_filt_se<-sqrt(mdl.kfs$V[12,12,cT])

# standard errors by delta method
mJ<-diag(11)  # Jacobian
mJ[1:2,1:2]<-diag(-10*exp(-vPi[1:2])/(1+exp(-vPi[1:2]))^2)
mJ[3:5,3:5]<-diag(-exp(-vPi[3:5])/(1+exp(-vPi[3:5]))^2)
mJ[6:9,6:9]<-diag(exp(vPi[6:9]))
mJ[10,10]<- -2*exp(-vPi[10])/(1+exp(-vPi[10]))^2
mJ[11,11]<- -2*exp(-vPi[11])/(1+exp(-vPi[11]))^2
H_<-ginv(mdl.opt$hessian) # Moore-Penrose inverse from MASS package
vSe<-sqrt(diag(mJ%*%H_%*%mJ))

dfResults<-data.frame(
  label=c("beta1","beta2","phi1","phi3","phiE","sigma2_eta1","sigma2_eta2","sigma2_eta3","sigma2_eta4","r12","r13","c1","c2","d"),
  stringsAsFactors = FALSE,
  coefficients=c(beta1_est,beta2_est,phi1_est,phi3_est,phiE_est,sigma2_eta1_est,sigma2_eta2_est,sigma2_eta3_est,sigma2_etaE_est,r12_est,r13_est,c1_filt,c2_filt,d_filt),
  standarderrors=c(vSe[1],vSe[2],vSe[3],vSe[4],vSe[5],vSe[6],vSe[7],vSe[8],vSe[9],vSe[10],vSe[11],c1_filt_se,c2_filt_se,d_filt_se)
)

save(mdl.kfs,dfResults,
     file='GCB_model1_results_forecast.rda')


# Baseline GDP scenario with historical mean

rm(list=ls())
cat("\014")

library(forecast)
library(zoo)
library(KFAS)
library(MASS)

setwd('~/Dropbox/EMCC/papers/bhk_gcb_model/replication_code_final/estimation')

# Data
gcb_data<-read.csv("../GCB_model_global_2020.csv")
soi_data<-read.csv("../SOI_1866_2019.csv")
SOI<-soi_data$mean[94:154]  # 1959-2019: 94-154
#en34_data<-read.csv("en34.csv",header=FALSE)
#EN34<-zooreg(en34_data$v16[90:149],frequency=1,start=1959) # 1959-2018: 90-149
E_FF<-gcb_data$E_FF
E_LUC<-gcb_data$E_LUC
E<-gcb_data$E_FF+gcb_data$E_LUC
S_LND<-gcb_data$S_LND
S_OCN<-gcb_data$S_OCN
G_ATM<-gcb_data$G_ATM
DGDP<-gcb_data$DGDP
BIM<-E-S_LND-S_OCN-G_ATM
cGtC1959<-2.127*315.39
cGtC1750<-2.127*279
DE<-diff(E)
DE_FF<-diff(E_FF)
DE_LUC<-diff(E_LUC)

# Housekeeping
cN<-5
cr<-17

endYearScen<-2050
endIdx<-length(gcb_data$Year)
endYearData<-gcb_data$Year[endIdx]
H<-endYearScen-endYearData
axTime<-(gcb_data$Year[1]:endYearScen)
cT<-endIdx+H

GGDP_scen<-c(.01,mean(gcb_data$GGDP[3:60]),.05)
Piketty_scen<-c(.034,.03,.015)  # Scenario in Piketty, Capital of the 21st Century, p. 101
# through 2030: 3.4%, 2030-2050: 3%, 2050-2100: 1.5%

# beta5 scenario
beta5_endpoint<-0.1119403
beta5_period<-30
beta5_slope<-beta5_endpoint/beta5_period
beta5_scen<-c(beta5_endpoint-beta5_slope*(1:beta5_period),matrix(0,H-beta5_period,1))

# E scenario
E_period<-30
E_slope<-E[endIdx]/E_period
E_scen<-c(E[endIdx]-E_slope*(1:E_period),matrix(0,H-E_period,1))




# Define extended data matrix
mX<-cbind(E,S_LND,S_OCN,G_ATM,DGDP)
mX<-rbind(mX,matrix(NA,H,5))
mX<-cbind(mX,matrix(0,cT,2))
mX[(endIdx+1):cT,6]<-beta5_scen
mX[(endIdx+1):cT,1]<-E_scen
mX<-zooreg(mX,frequency=1,start=1959)
vCreg<-(cGtC1959+cumsum(mX[,4]))
vCreg0<-vCreg/cGtC1750

# SOI is not projected and set to zero
SOI<-c(SOI,matrix(0,H,1))
SOI<-zooreg(SOI,frequency=1,start=1959)

Forecasts<-array(NA,c(H,5,length(GGDP_scen)+1))
Forecasts_Var<-array(NA,c(H,5,length(GGDP_scen)+1))
# Organization: C, G_ATM, S_LND, S_OCN, E
States<-array(NA,c(cT,6,length(GGDP_scen)+1))
States_Var<-array(NA,c(cT,6,length(GGDP_scen)+1))
# Organization: C*, G_ATM*, S_LND*, S_OCN*, E*


# Big K initialization
va1<-matrix(0,cr,1)

PinitXE<-3
mP1<-1000000*diag(1,cr)
mP1[5,5]<-1.5
mP1[6,6]<-0.50
mP1[7,7]<-0.02
mP1[8,8]<-PinitXE
mP1[16,16]<-0
mP1inf<-diag(0,cr)

vGDP<-matrix(NA,H+1,4)
vDGDP<-matrix(NA,H,4)

mObs<-cbind(vCreg,mX[,1],mX[,2],mX[,3],mX[,6])

for (scen_index in 1:4){
  
  if (scen_index < 4){
    vGDP[1,scen_index]<-gcb_data$GDP[endIdx]
    for (j in 2:(H+1)){
      vGDP[j,scen_index]<-vGDP[j-1,scen_index]*(1+GGDP_scen[scen_index])
    }
  } else {
    vGDP[1,scen_index]<-gcb_data$GDP[endIdx]
    for (j in 2:11){
      vGDP[j,scen_index]<-vGDP[j-1,scen_index]*(1+Piketty_scen[1])
    }
    for (j in 12:31){
      vGDP[j,scen_index]<-vGDP[j-1,scen_index]*(1+Piketty_scen[2])
    }
    for (j in 32:(H+1)){
      vGDP[j,scen_index]<-vGDP[j-1,scen_index]*(1+Piketty_scen[3])
    }
  }
  vDGDP[,scen_index]<-diff(vGDP[,scen_index])/10^12
  mX[(endIdx+1):cT,5]<-vDGDP[,scen_index]
  
  mdl<-SSModel(as.matrix(mObs) ~ -1 + SSMcustom(Z=array(NA,c(cN,cr,cT)),T=array(NA,c(cr,cr,cT)),R=array(NA,c(cr,cr,cT)),Q=matrix(NA,cr,cr),a1=va1,P1=mP1,P1inf=mP1inf),H=matrix(0,cN,cN))
  
  objf <- function(pars,model,estimate=TRUE){
    beta1<-10*exp(-pars[1])/((1+exp(-pars[1]))*cGtC1750)
    beta2<-10*exp(-pars[2])/((1+exp(-pars[2]))*cGtC1750)
    mZ<-matrix(0,cN,cr)
    mZ[1,1]<-mZ[1,5]<-mZ[2,9]<-mZ[3,3]<-mZ[3,6]<-mZ[4,4]<-mZ[4,7]<-1
    mZ1<-array(0,c(cN,cr,cT))
    mZ1[, ,]<-mZ
    mZ1[2,15,39]<-1 # 1997 in E equation  
    # scenario for beta_5
    mZ1[5,14,(endIdx+1):cT]<-1
    model$Z<-mZ1
    cInv<-1/(1+beta1+beta2)
    mT<-matrix(0,cr,cr)
    mT[1,1]<-mT[1,8]<-mT[1,9]<-cInv
    mT[1,10]<-mT[1,11]<- -cInv
    mT[2,1]<- -(beta1+beta2)*cInv
    mT[2,8]<-mT[2,9]<-cInv
    mT[2,10]<-mT[2,11]<- -cInv
    mT[3,1]<-mT[3,8]<-mT[3,9]<-beta1*cInv
    mT[3,10]<-(1+beta2)*cInv
    mT[3,11]<- -beta1*cInv
    mT[4,1]<-mT[4,8]<-mT[4,9]<-beta2*cInv
    mT[4,10]<- -beta2*cInv
    mT[4,11]<-(1+beta1)*cInv
    mT[5,5]<-exp(-pars[3])/(1+exp(-pars[3]))
    mT[7,7]<-exp(-pars[4])/(1+exp(-pars[4]))
    mT[8,8]<-exp(-pars[5])/(1+exp(-pars[5]))
    mT[9,8]<-mT[9,9]<-mT[10,10]<-mT[11,11]<-mT[12,12]<-mT[13,13]<-mT[14,14]<-mT[15,15]<-mT[16,16]<-mT[17,17]<-1
    mT1<-array(0,c(cr,cr,cT))
    mT1[, ,]<-mT
    # GDP
    mT1[1,14,1:(cT-1)]<-mT1[2,14,1:(cT-1)]<-mX[2:cT,5]*cInv
    mT1[3,14,1:(cT-1)]<-beta1*mX[2:cT,5]*cInv
    mT1[4,14,1:(cT-1)]<-beta2*mX[2:cT,5]*cInv
    mT1[9,14,1:(cT-1)]<-mX[2:cT,5]
    # SOI
    mT1[1,12,1:(cT-1)]<- -SOI[2:cT]*cInv
    mT1[1,13,1:(cT-1)]<- -SOI[2:cT]*cInv
    mT1[2,12,1:(cT-1)]<- -SOI[2:cT]*cInv
    mT1[2,13,1:(cT-1)]<- -SOI[2:cT]*cInv
    mT1[3,12,1:(cT-1)]<-(1+beta2)*SOI[2:cT]*cInv
    mT1[3,13,1:(cT-1)]<- -beta1*SOI[2:cT]*cInv
    mT1[4,12,1:(cT-1)]<- -beta2*SOI[2:cT]*cInv
    mT1[4,13,1:(cT-1)]<-(1+beta1)*SOI[2:cT]*cInv
    # I1991 in G_ATM*
    mT1[1,16,33]<-cInv
    mT1[2,16,33]<-cInv
    mT1[3,16,33]<-beta1*cInv
    mT1[4,16,33]<-beta2*cInv
    # # I1991 in C*
    # mT1[1,16,33]<-cInv                   # to put the 1991 dummy in C or in G_ATM is equivalent,
    # mT1[2,16,33]<- -cInv*(beta1+beta2)   # this is just a matter of how one wants to define G_ATM  
    # mT1[3,16,33]<-beta1*cInv             # (shall the spike from the 1991 dummy show in the smoothed process).
    # mT1[4,16,33]<-beta2*cInv
    # I1991 in E*
    mT1[1,17,33]<-mT1[2,17,33]<-cInv
    mT1[3,17,33]<-beta1*cInv
    mT1[4,17,33]<-beta2*cInv
    mT1[9,17,33]<-1
    model$T<-mT1
    mQ<-matrix(0,cr,cr)
    mQ[5,5]<-exp(pars[6]) # var X1
    mQ[6,6]<-exp(pars[7]) # var X2
    mQ[7,7]<-exp(pars[8]) # var X3
    mQ[8,8]<-exp(pars[9]) # var XE
    r12<-(1-exp(-pars[10]))/(1+exp(-pars[10]))
    r13<-(1-exp(-pars[11]))/(1+exp(-pars[11]))
    mQ[5,6]<-mQ[6,5]<-r12*sqrt(mQ[5,5])*sqrt(mQ[6,6])
    mQ[5,7]<-mQ[7,5]<-r13*sqrt(mQ[5,5])*sqrt(mQ[7,7])
    mQ[14,14]<-1
    model$Q[, ,1]<-mQ
    s_E<-7*exp(-pars[12])/(1+exp(-pars[12]))
    mR<-matrix(0,cr,cr)
    mR[5:8,5:8]<-diag(4)      # Note that R is incompletely populated:
    mRpar<-mR                 # There are also non-zero entries in cols 1-4 and 9.
    mRpar[8,8]<-s_E           # However, the entries 1-4 and 9 of the state error vector 
    mR1<-array(0,c(cr,cr,cT)) # are zero, and therefore, this doesn't matter.
    # 1959-1995
    mR1[, , 1:37]<-mR
    # 1996-2019
    mR1[, , 38:cT]<-mRpar
    mR1[14,14,(endIdx+1):cT]<-1
    model$R<-mR1
    if (estimate){
      -logLik(model)
    } else {
      model
    }
  }
  
  # load parameter vector for state space model
  load(file="parameters_model2.rda")
  

  mdl.fit<-objf(vPi, mdl, estimate = FALSE)
  mdl.kfs<-KFS(mdl.fit,filtering=c('state','signal','disturbance'),smoothing=c('state','signal','disturbance'))

  
  # # Organization: C, G_ATM, S_LND, S_OCN, E
  
  C_hat<-zooreg(mdl.kfs$m[(endIdx+1):(endIdx+H),1],frequency=1,start=(endYearData+1))
  C_hat_var<-zooreg(mdl.kfs$F[1,(endIdx+1):(endIdx+H)],frequency=1,start=(endYearData+1))
  G_ATM_hat<-zooreg(mdl.kfs$a[(endIdx+1):(endIdx+H),2],frequency=1,start=(endYearData+1))
  G_ATM_hat_var<-zooreg(mdl.kfs$P[2,2,(endIdx+1):(endIdx+H)],frequency=1,start=(endYearData+1))
  S_LND_hat<-zooreg(mdl.kfs$m[(endIdx+1):(endIdx+H),3],frequency=1,start=(endYearData+1))
  S_LND_hat_var<-zooreg(mdl.kfs$F[3,(endIdx+1):(endIdx+H)],frequency=1,start=(endYearData+1))
  S_OCN_hat<-zooreg(mdl.kfs$m[(endIdx+1):(endIdx+H),4],frequency=1,start=(endYearData+1))
  S_OCN_hat_var<-zooreg(mdl.kfs$F[4,(endIdx+1):(endIdx+H)],frequency=1,start=(endYearData+1))
  E_hat<-zooreg(mdl.kfs$m[(endIdx+1):(endIdx+H),2],frequency=1,start=(endYearData+1))
  E_hat_var<-zooreg(mdl.kfs$F[2,(endIdx+1):(endIdx+H)],frequency=1,start=(endYearData+1))
  
  Forecasts[,1,scen_index]<-C_hat
  Forecasts_Var[,1,scen_index]<-C_hat_var*(C_hat_var>0)
  Forecasts[,2,scen_index]<-G_ATM_hat
  Forecasts_Var[,2,scen_index]<-G_ATM_hat_var*(G_ATM_hat_var>0)
  Forecasts[,3,scen_index]<-S_LND_hat
  Forecasts_Var[,3,scen_index]<-S_LND_hat_var*(S_LND_hat_var>0)
  Forecasts[,4,scen_index]<-S_OCN_hat
  Forecasts_Var[,4,scen_index]<-S_OCN_hat_var*(S_OCN_hat_var>0)
  Forecasts[,5,scen_index]<-E_hat
  Forecasts_Var[,5,scen_index]<-E_hat_var*(E_hat_var>0)
  
  C_star<-zooreg(mdl.kfs$alphahat[,1],frequency=1,start=1959)
  C_star_var<-zooreg(mdl.kfs$V[1,1,],frequency=1,start=1959)
  G_ATM_star<-zooreg(mdl.kfs$alphahat[,2],frequency=1,start=1959)
  G_ATM_star_var<-zooreg(mdl.kfs$V[2,2,],frequency=1,start=1959)
  S_LND_star<-zooreg(mdl.kfs$alphahat[,3],frequency=1,start=1959)
  S_LND_star_var<-zooreg(mdl.kfs$V[3,3,],frequency=1,start=1959)
  S_OCN_star<-zooreg(mdl.kfs$alphahat[,4],frequency=1,start=1959)
  S_OCN_star_var<-zooreg(mdl.kfs$V[4,4,],frequency=1,start=1959)
  E_star<-zooreg(mdl.kfs$alphahat[,9],frequency=1,start=1959)
  E_star_var<-zooreg(mdl.kfs$V[9,9,],frequency=1,start=1959)
  X_E<-zooreg(mdl.kfs$alphahat[,8],frequency=1,start=1959)
  X_E_var<-zooreg(mdl.kfs$V[8,8,],frequency=1,start=1959)
  
  States[,1,scen_index]<-C_star
  States_Var[,1,scen_index]<-C_star_var*(C_star_var>0)
  States[,2,scen_index]<-G_ATM_star
  States_Var[,2,scen_index]<-G_ATM_star_var*(G_ATM_star_var>0)
  States_Var[1,2,scen_index]<-mean(G_ATM_star_var[2:cT])
  States[,3,scen_index]<-S_LND_star
  States_Var[,3,scen_index]<-S_LND_star_var*(S_LND_star_var>0)
  States[,4,scen_index]<-S_OCN_star
  States_Var[,4,scen_index]<-S_OCN_star_var*(S_OCN_star_var>0)
  States[,5,scen_index]<-E_star
  States_Var[,5,scen_index]<-E_star_var*(E_star_var>0)
  States[,6,scen_index]<-X_E
  States_Var[,6,scen_index]<-X_E_var*(X_E_var>0)

}

crit<-1.64
qual<-100
wd<-15
ht<-15
uts<-"cm"
resn<-300

# C_star
#jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures2020/bhk_stat_gcb_model2_scenarioE_C_star.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
mean1<-States[,1,1]
std1<-sqrt(States_Var[,1,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[,1,2]
std2<-sqrt(States_Var[,1,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
mean3<-States[,1,3]
std3<-sqrt(States_Var[,1,3])
CIup3<-mean3+crit*std3
CIdown3<-mean3-crit*std3
mean4<-States[,1,4]
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymax3<-max(CIup3)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymin3<-min(CIdown3)
ymax<-max(ymax1,ymax2,ymax3)
ymin<-min(ymin1,ymin2,ymin3)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='C* (GtC)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,mean4,type='l',lty=2,lwd=3,col='blue')
lines(axTime,mean3,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup3, rev(CIdown3)),col=adjustcolor("red",alpha.f=0.5),border=NA)
lines(axTime,CIup3,type='l',lwd=1,lty=3,col='red')
lines(axTime,CIdown3,type='l',lwd=1,lty=3,col='red')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2018,lty=3,lwd=1,col='black')
legend("topleft",c("0.01 GDP growth","0.034 GDP growth","0.05 GDP growth","Piketty"),col=c("green","grey","red","blue"),lty=c(1,1,1,3),lwd=c(5,5,5,5),bty='n')
#dev.off()

# G_ATM_star
#jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures2020/bhk_stat_gcb_model2_scenarioE_G_ATM_star.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
mean1<-States[,2,1]
std1<-sqrt(States_Var[,2,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[,2,2]
std2<-sqrt(States_Var[,2,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
mean3<-States[,2,3]
std3<-sqrt(States_Var[,2,3])
CIup3<-mean3+crit*std3
CIdown3<-mean3-crit*std3
mean4<-States[,2,4]
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymax3<-max(CIup3)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymin3<-min(CIdown3)
ymax<-max(ymax1,ymax2,ymax3)
ymin<-min(ymin1,ymin2,ymin3)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='G_ATM* (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,mean4,type='l',lty=2,lwd=3,col='blue')
lines(axTime,mean3,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup3, rev(CIdown3)),col=adjustcolor("red",alpha.f=0.5),border=NA)
lines(axTime,CIup3,type='l',lwd=1,lty=3,col='red')
lines(axTime,CIdown3,type='l',lwd=1,lty=3,col='red')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2018,lty=3,lwd=1,col='black')
legend("topleft",c("0.01 GDP growth","0.034 GDP growth","0.05 GDP growth","Piketty"),col=c("green","grey","red","blue"),lty=c(1,1,1,3),lwd=c(5,5,5,5),bty='n')
#dev.off()


# S_LND_star
#jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures2020/bhk_stat_gcb_model2_scenarioE_S_LND_star.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
mean1<-States[,3,1]
std1<-sqrt(States_Var[,3,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[,3,2]
std2<-sqrt(States_Var[,3,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
mean3<-States[,3,3]
std3<-sqrt(States_Var[,3,3])
CIup3<-mean3+crit*std3
CIdown3<-mean3-crit*std3
mean4<-States[,3,4]
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymax3<-max(CIup3)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymin3<-min(CIdown3)
ymax<-max(ymax1,ymax2,ymax3)
ymin<-min(ymin1,ymin2,ymin3)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='S_LND* (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,mean4,type='l',lty=2,lwd=3,col='blue')
lines(axTime,mean3,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup3, rev(CIdown3)),col=adjustcolor("red",alpha.f=0.5),border=NA)
lines(axTime,CIup3,type='l',lwd=1,lty=3,col='red')
lines(axTime,CIdown3,type='l',lwd=1,lty=3,col='red')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2018,lty=3,lwd=1,col='black')
legend("topleft",c("0.01 GDP growth","0.034 GDP growth","0.05 GDP growth","Piketty"),col=c("green","grey","red","blue"),lty=c(1,1,1,3),lwd=c(5,5,5,5),bty='n')
#dev.off()

# S_OCN_star
#jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures2020/bhk_stat_gcb_model2_scenarioE_S_OCN_star.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
mean1<-States[,4,1]
std1<-sqrt(States_Var[,4,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[,4,2]
std2<-sqrt(States_Var[,4,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
mean3<-States[,4,3]
std3<-sqrt(States_Var[,4,3])
CIup3<-mean3+crit*std3
CIdown3<-mean3-crit*std3
mean4<-States[,4,4]
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymax3<-max(CIup3)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymin3<-min(CIdown3)
ymax<-max(ymax1,ymax2,ymax3)
ymin<-min(ymin1,ymin2,ymin3)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='S_OCN* (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,mean4,type='l',lty=2,lwd=3,col='blue')
lines(axTime,mean3,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup3, rev(CIdown3)),col=adjustcolor("red",alpha.f=0.5),border=NA)
lines(axTime,CIup3,type='l',lwd=1,lty=3,col='red')
lines(axTime,CIdown3,type='l',lwd=1,lty=3,col='red')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2018,lty=3,lwd=1,col='black')
legend("topleft",c("0.01 GDP growth","0.034 GDP growth","0.05 GDP growth","Piketty"),col=c("green","grey","red","blue"),lty=c(1,1,1,3),lwd=c(5,5,5,5),bty='n')
#dev.off()

# E_star
#jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures2020/bhk_stat_gcb_model2_scenarioE_E_star.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
mean1<-States[,5,1]
std1<-sqrt(States_Var[,5,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[,5,2]
std2<-sqrt(States_Var[,5,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
mean3<-States[,5,3]
std3<-sqrt(States_Var[,5,3])
CIup3<-mean3+crit*std3
CIdown3<-mean3-crit*std3
mean4<-States[,5,4]
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymax3<-max(CIup3)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymin3<-min(CIdown3)
ymax<-max(ymax1,ymax2,ymax3)
ymin<-min(ymin1,ymin2,ymin3)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='E* (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,mean4,type='l',lty=2,lwd=3,col='blue')
lines(axTime,mean3,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup3, rev(CIdown3)),col=adjustcolor("red",alpha.f=0.5),border=NA)
lines(axTime,CIup3,type='l',lwd=1,lty=3,col='red')
lines(axTime,CIdown3,type='l',lwd=1,lty=3,col='red')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2018,lty=3,lwd=1,col='black')
legend("topleft",c("0.01 GDP growth","0.034 GDP growth","0.05 GDP growth","Piketty"),col=c("green","grey","red","blue"),lty=c(1,1,1,3),lwd=c(5,5,5,5),bty='n')
#dev.off()

# X_E
#jpeg(file="~/Dropbox/EMCC/papers/bhk_gcb_model/figures2020/bhk_stat_gcb_model2_scenarioE_X_E.jpg",quality=qual,width=wd,height=ht,units=uts,res=resn)
mean1<-c(matrix(NA,endIdx,1),States[(endIdx+1):cT,6,1])
std1<-c(matrix(NA,endIdx,1),sqrt(States_Var[(endIdx+1):(cT-2),6,1]),matrix(0,2,1))
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-c(matrix(NA,endIdx,1),States[(endIdx+1):cT,6,2])
std2<-c(matrix(NA,endIdx,1),sqrt(States_Var[(endIdx+1):(cT-2),6,2]),matrix(0,2,1))
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
mean3<-c(matrix(NA,endIdx,1),States[(endIdx+1):cT,6,3])
std3<-c(matrix(NA,endIdx,1),sqrt(States_Var[(endIdx+1):(cT-2),6,3]),matrix(0,2,1))
CIup3<-mean3+crit*std3
CIdown3<-mean3-crit*std3
mean4<-c(matrix(NA,endIdx,1),States[(endIdx+1):cT,6,4])
ymax1<-max(CIup1, na.rm=TRUE)
ymax2<-max(CIup2, na.rm=TRUE)
ymax3<-max(CIup3, na.rm=TRUE)
ymin1<-min(CIdown1, na.rm=TRUE)
ymin2<-min(CIdown2, na.rm=TRUE)
ymin3<-min(CIdown3, na.rm=TRUE)
ymax<-max(ymax1,ymax2,ymax3, na.rm=TRUE)
ymin<-min(ymin1,ymin2,ymin3, na.rm=TRUE)
plot(axTime,mean1,type='l',lwd=3,col='green',xlab='Year',ylab='E Reductions (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='grey')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,mean4,type='l',lty=2,lwd=3,col='blue')
lines(axTime,mean3,type='l',lwd=3,col='red')
polygon(c(axTime,rev(axTime)),c(CIup3, rev(CIdown3)),col=adjustcolor("red",alpha.f=0.5),border=NA)
lines(axTime,CIup3,type='l',lwd=1,lty=3,col='red')
lines(axTime,CIdown3,type='l',lwd=1,lty=3,col='red')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='green')
abline(v=2018,lty=3,lwd=1,col='black')
legend("topleft",c("0.01 GDP growth","0.034 GDP growth","0.05 GDP growth","Piketty"),col=c("green","grey","red","blue"),lty=c(1,1,1,3),lwd=c(5,5,5,5),bty='n')
#dev.off()

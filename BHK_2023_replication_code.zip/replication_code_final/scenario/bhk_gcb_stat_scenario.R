# This program produces the projections to 2100 reported in the paper.
# To switch between 1.5 and <2 degree scenarios, use the switch E_scen in
# lines 71 and 72.

rm(list=ls())
cat("\014")

library(forecast)
library(zoo)
library(KFAS)
library(MASS)

setwd('~/Dropbox/EMCC/papers/bhk_gcb_model/replication_code_final/scenario')

# Data
gcb_data<-read.csv("../GCB_model_global_2020.csv")
soi_data<-read.csv("../SOI_1866_2019.csv")
SOI<-soi_data$mean[94:154]  # 1959-2019: 94-154
#en34_data<-read.csv("en34.csv",header=FALSE)
#EN34<-zooreg(en34_data$v16[90:149],frequency=1,start=1959) # 1959-2018: 90-149
E_FF<-gcb_data$E_FF
E_LUC<-gcb_data$E_LUC
E<-gcb_data$E_FF+gcb_data$E_LUC
S_LND<-gcb_data$S_LND
S_OCN<-gcb_data$S_OCN
G_ATM<-gcb_data$G_ATM
DGDP<-gcb_data$DGDP
BIM<-E-S_LND-S_OCN-G_ATM
cGtC1959<-2.127*315.39
cGtC1750<-2.127*279
DE<-diff(E)
DE_FF<-diff(E_FF)
DE_LUC<-diff(E_LUC)

# Housekeeping
cN<-5
cr<-18
endYearScen<-2100
endIdx<-length(gcb_data$Year)
endYearData<-gcb_data$Year[endIdx]
H<-endYearScen-endYearData
axTime<-(gcb_data$Year[1]:endYearScen)
cT<-endIdx+H

# Big K initialization
va1<-matrix(0,cr,1)
PinitXE<-3
mP1<-1000000*diag(1,cr)
mP1[5,5]<-1.5
mP1[6,6]<-0.50
mP1[7,7]<-0.02
mP1[8,8]<-PinitXE
mP1[16,16]<-0
mP1inf<-diag(0,cr)

# Define extended data matrix
mX<-cbind(E,S_LND,S_OCN,G_ATM,DGDP)
mX<-rbind(mX,matrix(NA,H,5))
mX<-zooreg(mX,frequency=1,start=1959)
vCreg<-(cGtC1959+cumsum(mX[,4]))
vCreg0<-vCreg/cGtC1750

# Emission scenario
# 2010-Level E=10.04 (this is both E_FF and E_LUC, we ignore this for the scenarios)
# 2030-Level: 45% reduction of 2010-level for 1.5 degrees warming
#             25% reduction of 2010-level for <2 degrees warming
# 2050-Level: zero for 1.5 degrees
# 2070-Level: zero for <2 degrees warming
# https://unfccc.int/process-and-meetings/the-paris-agreement/nationally-determined-contributions-ndcs/nationally-determined-contributions-ndcs/ndc-synthesis-report#eq-5

#E_scen<-1.5   # 1.5 degrees 
E_scen<-2     # 2 degrees
set_E<-1      # linear decrease in emissions between 2020 and 2050, with slope change in 2030
#set_E<-0     # only one data point on E in 2030 and zero after 2050, otherwise NA 

if (E_scen==1.5){ 
  c2030<-E[51]*0.55  # 1.5 degree scenario
  if (set_E==1){
    cSlope1<-(c2030-E[51])/10
    mX[(endIdx+1):(endIdx+10),1]<-E[61]+cSlope1*(1:10)
    cSlope2<- as.numeric(-mX[endIdx+10,1])/21
    mX[(endIdx+11):(endIdx+30),1]<-as.numeric(mX[endIdx+10,1])+cSlope2*(1:20)
  } else if (set_E==0) {
    mX[(endIdx+1):(endIdx+9),1]<-NA
    mX[endIdx+10,1]<-c2030
    mX[(endIdx+11):(endIdx+30),1]<-NA
  }
    mX[(endIdx+31):cT,1]<-0
} else if (E_scen==2){
  c2030<-E[51]*.75  # <2 degree scenario
  if (set_E==1){
    cSlope1<-(c2030-E[51])/10
    mX[(endIdx+1):(endIdx+10),1]<-E[61]+cSlope1*(1:10)
    cSlope2<- as.numeric(-mX[endIdx+10,1])/41
    mX[(endIdx+11):(endIdx+50),1]<-as.numeric(mX[endIdx+10,1])+cSlope2*(1:40)
  } else if (set_E==0){
    mX[(endIdx+1):(endIdx+9),1]<-NA
    mX[endIdx+10,1]<-c2030
    mX[(endIdx+11):(endIdx+50),1]<-NA
  }
  mX[(endIdx+51):cT,1]<-0
} else if (E_scen==99){
  mX[(endIdx+1):cT,1]<-NA
}

# load Model 2 results with time-varying beta_5 from bhk_gcb_stat_model2_beta5t.R
load(file='GCB_model2_results_beta5t.rda')

# Scenario for time-varying coefficient of Delta GDP in E-equation (beta_5)
beta5_endpoint<-0.07883710  # value of time-varying coefficient estimated for 2019 on sample period
beta5_endpoint<-mdl.kfs$alphahat[endIdx,14]  # value of time-varying coefficient estimated for 2019 on sample period
beta5_scen<-matrix(NA,cT,1)
if (E_scen==1.5){
  cSlope_beta5<- -beta5_endpoint/31  
  beta5_scen[(endIdx+1):(endIdx+30)]<-beta5_endpoint + cSlope_beta5*(1:30)
  beta5_scen[(endIdx+31):cT]<-0
} else if (E_scen==2){
  cSlope_beta5<- -beta5_endpoint/51   
  beta5_scen[(endIdx+1):(endIdx+50)]<-beta5_endpoint + cSlope_beta5*(1:50)
  beta5_scen[(endIdx+51):cT]<-0
} else if (E_scen==99){
  beta5_filt<-mdl.kfs$att[21:endIdx,14]
  time_ax_regression<-((1:(endIdx-20)))
  beta5_filt.lm<-lm(beta5_filt~time_ax_regression)
  beta5_slope1<-beta5_filt.lm$coefficients[2]
  year_to_zero1<-beta5_endpoint/(-beta5_slope1)
  beta5_smooth<-mdl.kfs$alphahat[38:endIdx,14]
  time_ax_regression<-((1:(endIdx-37)))
  beta5_smooth.lm<-lm(beta5_smooth~time_ax_regression)
  beta5_slope2<-beta5_smooth.lm$coefficients[2]
  year_to_zero2<-beta5_endpoint/(-beta5_slope2)
  beta5_slope<-(beta5_slope1+beta5_slope2)/2
  year_to_zero<-floor((year_to_zero1+year_to_zero2)/2)
  if (year_to_zero<(cT-endIdx)){
    beta5_scen[(endIdx+1):(endIdx+year_to_zero)]<-beta5_endpoint+beta5_slope*(1:year_to_zero)
    beta5_scen[(endIdx+year_to_zero+1):cT]<-0
  }
  else beta5_scen[(endIdx+1):cT]<-beta5_endpoint+beta5_slope*(1:(cT-endIdx))
}
mX<-cbind(mX,beta5_scen)
colnames(mX)[6]<-"beta5_scen"

# SOI is not projected and set to zero
SOI<-c(SOI,matrix(0,H,1))
SOI<-zooreg(SOI,frequency=1,start=1959)

# objective function of the state space model
objf <- function(pars,model,estimate=TRUE){
  beta1<-10*exp(-pars[1])/((1+exp(-pars[1]))*cGtC1750)
  beta2<-10*exp(-pars[2])/((1+exp(-pars[2]))*cGtC1750)
  mZ<-matrix(0,cN,cr)
  mZ[1,1]<-mZ[1,5]<-mZ[2,9]<-mZ[3,3]<-mZ[3,6]<-mZ[4,4]<-mZ[4,7]<-1
  mZ1<-array(0,c(cN,cr,cT))
  mZ1[, ,]<-mZ
  mZ1[2,15,39]<-1 # 1997 in E equation
  # scenario for beta_5
  mZ1[5,14,(endIdx+1):cT]<-1
  model$Z<-mZ1
  cInv<-1/(1+beta1+beta2)
  mT<-matrix(0,cr,cr)
  mT[1,1]<-mT[1,8]<-mT[1,9]<-mT[1,16]<-cInv
  mT[1,10]<-mT[1,11]<- -cInv
  mT[2,1]<- -(beta1+beta2)*cInv
  mT[2,8]<-mT[2,9]<-mT[2,16]<-cInv
  mT[2,10]<-mT[2,11]<- -cInv
  mT[3,1]<-mT[3,8]<-mT[3,9]<-mT[3,16]<-beta1*cInv
  mT[3,10]<-(1+beta2)*cInv
  mT[3,11]<- -beta1*cInv
  mT[4,1]<-mT[4,8]<-mT[4,9]<-mT[4,16]<-beta2*cInv
  mT[4,10]<- -beta2*cInv
  mT[4,11]<-(1+beta1)*cInv
  mT[5,5]<-exp(-pars[3])/(1+exp(-pars[3]))
  mT[7,7]<-exp(-pars[4])/(1+exp(-pars[4]))
  mT[8,8]<-exp(-pars[5])/(1+exp(-pars[5]))
  mT[9,8]<-mT[9,9]<-mT[9,16]<-mT[10,10]<-mT[11,11]<-mT[12,12]<-mT[13,13]<-mT[14,14]<-mT[15,15]<-mT[16,16]<-mT[17,17]<-mT[18,18]<-1
  mT1<-array(0,c(cr,cr,cT))
  mT1[, ,]<-mT
  # GDP
  mT1[1,14,1:(cT-1)]<-mT1[2,14,1:(cT-1)]<-mX[2:cT,5]*cInv
  mT1[3,14,1:(cT-1)]<-beta1*mX[2:cT,5]*cInv
  mT1[4,14,1:(cT-1)]<-beta2*mX[2:cT,5]*cInv
  mT1[9,14,1:(cT-1)]<-mX[2:cT,5]
  # SOI
  mT1[1,12,1:(cT-1)]<- -SOI[2:cT]*cInv
  mT1[1,13,1:(cT-1)]<- -SOI[2:cT]*cInv
  mT1[2,12,1:(cT-1)]<- -SOI[2:cT]*cInv
  mT1[2,13,1:(cT-1)]<- -SOI[2:cT]*cInv
  mT1[3,12,1:(cT-1)]<-(1+beta2)*SOI[2:cT]*cInv
  mT1[3,13,1:(cT-1)]<- -beta1*SOI[2:cT]*cInv
  mT1[4,12,1:(cT-1)]<- -beta2*SOI[2:cT]*cInv
  mT1[4,13,1:(cT-1)]<-(1+beta1)*SOI[2:cT]*cInv
  # I1991 in G_ATM*
  mT1[1,17,33]<-cInv
  mT1[2,17,33]<-cInv
  mT1[3,17,33]<-beta1*cInv
  mT1[4,17,33]<-beta2*cInv
  # # I1991 in C*
  # mT1[1,17,33]<-cInv                   # to put the 1991 dummy in C or in G_ATM is equivalent,
  # mT1[2,17,33]<- -cInv*(beta1+beta2)   # this is just a matter of how one wants to define G_ATM
  # mT1[3,17,33]<-beta1*cInv             # (shall the spike from the 1991 dummy show in the smoothed process).
  # mT1[4,17,33]<-beta2*cInv
  # I1991 in E*
  mT1[1,18,33]<-mT1[2,18,33]<-cInv
  mT1[3,18,33]<-beta1*cInv
  mT1[4,18,33]<-beta2*cInv
  mT1[9,18,33]<-1
  model$T<-mT1
  mQ<-matrix(0,cr,cr)
  mQ[5,5]<-exp(pars[6]) # var X1
  mQ[6,6]<-exp(pars[7]) # var X2
  mQ[7,7]<-exp(pars[8]) # var X3
  mQ[8,8]<-exp(pars[9]) # var XE
  r12<-(1-exp(-pars[10]))/(1+exp(-pars[10]))
  r13<-(1-exp(-pars[11]))/(1+exp(-pars[11]))
  mQ[5,6]<-mQ[6,5]<-r12*sqrt(mQ[5,5])*sqrt(mQ[6,6])
  mQ[5,7]<-mQ[7,5]<-r13*sqrt(mQ[5,5])*sqrt(mQ[7,7])
  mQ[14,14]<-exp(pars[13]) # var beta_{5,t} on DGDP in E
  mQ[16,16]<-5             # var beta_{9,t} intercept in E
  if (E_scen==99){mQ[16,16]<-0} # in business-as-usual scenario, intercept is turned off
  model$Q[, ,1]<-mQ
  s_E<-7*exp(-pars[12])/(1+exp(-pars[12]))
  mR<-matrix(0,cr,cr)
  mR[5:8,5:8]<-diag(4)      # Note that R is incompletely populated:
  mRpar<-mR                 # There are also non-zero entries in cols 1-4 and 9.
  mRpar[8,8]<-s_E           # However, the entries 1-4 and 9 of the state error vector
  mRpar[14,14]<-1           # are zero, and therefore, this doesn't matter.
  mR1<-array(0,c(cr,cr,cT))
  # 1959-1995
  mR1[, , 1:37]<-mR
  # 1996-2019
  mR1[, , 38:cT]<-mRpar
  # Variance of intercept process in E-equation on 2020-2100
  mR1[16,16,(endIdx+1):cT]<-1
  model$R<-mR1
  if (estimate){
    -logLik(model)
  } else {
    model
  }
}

# GDP scenarios
GGDP_scen<-c(.01,mean(gcb_data$GGDP[3:endIdx]),.05)
Piketty_scen<-c(.034,.03,.015)  # Scenario in Piketty, Capital of the 21st Century, p. 101
# through 2030: 3.4%, 2030-2050: 3%, 2050-2100: 1.5%

# Init objects for forecasts
Forecasts<-array(NA,c(H,5,length(GGDP_scen)+1))
Forecasts_Var<-array(NA,c(H,5,length(GGDP_scen)+1))
# Organization: C, G_ATM, S_LND, S_OCN, E
States<-array(NA,c(cT,6,length(GGDP_scen)+1))
States_Var<-array(NA,c(cT,6,length(GGDP_scen)+1))
# Organization: C*, G_ATM*, S_LND*, S_OCN*, E*

# load parameter vector from Model 2 with time-varying beta5
load(file="parameters_model2_beta5t.rda")

# Loop over GDP scenarios
for (scen_index in 1:2){
  
  mObs<-cbind(vCreg,mX[,1],mX[,2],mX[,3],mX[,6])
  vGDP<-matrix(NA,H+1,1)
  if (scen_index < 4){
    vGDP[1]<-gcb_data$GDP[endIdx]
    for (j in 2:(H+1)){
      vGDP[j]<-vGDP[j-1]*(1+GGDP_scen[scen_index])
    }
  } else {
    vGDP[1]<-gcb_data$GDP[endIdx]
    for (j in 2:11){
      vGDP[j]<-vGDP[j-1]*(1+Piketty_scen[1])
    }
    for (j in 12:31){
      vGDP[j]<-vGDP[j-1]*(1+Piketty_scen[2])
    }
    for (j in 32:(H+1)){
      vGDP[j]<-vGDP[j-1]*(1+Piketty_scen[3])
    }
  }
  vDGDP<-diff(vGDP)/10^12
  mX[(endIdx+1):cT,5]<-vDGDP
  mdl<-SSModel(as.matrix(mObs) ~ -1 + SSMcustom(Z=array(NA,c(cN,cr,cT)),T=array(NA,c(cr,cr,cT)),R=array(NA,c(cr,cr,cT)),Q=matrix(NA,cr,cr),a1=va1,P1=mP1,P1inf=mP1inf),H=matrix(0,cN,cN))

  # run Kalman filter and smoother
  mdl.fit<-objf(vPi, mdl, estimate = FALSE)
  mdl.kfs<-KFS(mdl.fit,filtering=c('state','signal','disturbance'),smoothing=c('state','signal','disturbance'),simplify=FALSE)
  
  C_hat<-zooreg(mdl.kfs$m[(endIdx+1):(endIdx+H),1],frequency=1,start=(endYearData+1))
  C_hat_var<-zooreg(mdl.kfs$F[1,(endIdx+1):(endIdx+H)],frequency=1,start=(endYearData+1))
  G_ATM_hat<-zooreg(mdl.kfs$a[(endIdx+1):(endIdx+H),2],frequency=1,start=(endYearData+1))
  G_ATM_hat_var<-zooreg(mdl.kfs$P[2,2,(endIdx+1):(endIdx+H)],frequency=1,start=(endYearData+1))
  S_LND_hat<-zooreg(mdl.kfs$m[(endIdx+1):(endIdx+H),3],frequency=1,start=(endYearData+1))
  S_LND_hat_var<-zooreg(mdl.kfs$F[3,(endIdx+1):(endIdx+H)],frequency=1,start=(endYearData+1))
  S_OCN_hat<-zooreg(mdl.kfs$m[(endIdx+1):(endIdx+H),4],frequency=1,start=(endYearData+1))
  S_OCN_hat_var<-zooreg(mdl.kfs$F[4,(endIdx+1):(endIdx+H)],frequency=1,start=(endYearData+1))
  E_hat<-zooreg(mdl.kfs$m[(endIdx+1):(endIdx+H),2],frequency=1,start=(endYearData+1))
  E_hat_var<-zooreg(mdl.kfs$F[2,(endIdx+1):(endIdx+H)],frequency=1,start=(endYearData+1))
  
  Forecasts[,1,scen_index]<-C_hat
  Forecasts_Var[,1,scen_index]<-C_hat_var*(C_hat_var>0)
  Forecasts[,2,scen_index]<-G_ATM_hat
  Forecasts_Var[,2,scen_index]<-G_ATM_hat_var*(G_ATM_hat_var>0)
  Forecasts[,3,scen_index]<-S_LND_hat
  Forecasts_Var[,3,scen_index]<-S_LND_hat_var*(S_LND_hat_var>0)
  Forecasts[,4,scen_index]<-S_OCN_hat
  Forecasts_Var[,4,scen_index]<-S_OCN_hat_var*(S_OCN_hat_var>0)
  Forecasts[,5,scen_index]<-E_hat
  Forecasts_Var[,5,scen_index]<-E_hat_var*(E_hat_var>0)
  
  C_star<-zooreg(mdl.kfs$alphahat[,1],frequency=1,start=1959)
  C_star_var<-zooreg(mdl.kfs$V[1,1,],frequency=1,start=1959)
  G_ATM_star<-zooreg(mdl.kfs$alphahat[,2],frequency=1,start=1959)
  G_ATM_star_var<-zooreg(mdl.kfs$V[2,2,],frequency=1,start=1959)
  S_LND_star<-zooreg(mdl.kfs$alphahat[,3],frequency=1,start=1959)
  S_LND_star_var<-zooreg(mdl.kfs$V[3,3,],frequency=1,start=1959)
  S_OCN_star<-zooreg(mdl.kfs$alphahat[,4],frequency=1,start=1959)
  S_OCN_star_var<-zooreg(mdl.kfs$V[4,4,],frequency=1,start=1959)
  E_star<-zooreg(mdl.kfs$alphahat[,9],frequency=1,start=1959)
  E_star_var<-zooreg(mdl.kfs$V[9,9,],frequency=1,start=1959)
  beta9<-zooreg(mdl.kfs$alphahat[,16],frequency=1,start=1959)
  beta9_var<-zooreg(mdl.kfs$V[16,16,],frequency=1,start=1959)
  beta9_var[cT]<-beta9_var[cT-1]
  
  States[,1,scen_index]<-C_star
  States_Var[,1,scen_index]<-C_star_var*(C_star_var>0)
  States[,2,scen_index]<-G_ATM_star
  States_Var[,2,scen_index]<-G_ATM_star_var*(G_ATM_star_var>0)
  States_Var[1,2,scen_index]<-mean(G_ATM_star_var[2:cT])
  States[,3,scen_index]<-S_LND_star
  States_Var[,3,scen_index]<-S_LND_star_var*(S_LND_star_var>0)
  States[,4,scen_index]<-S_OCN_star
  States_Var[,4,scen_index]<-S_OCN_star_var*(S_OCN_star_var>0)
  States[,5,scen_index]<-E_star
  States_Var[,5,scen_index]<-E_star_var*(E_star_var>0)
  States[,6,scen_index]<-beta9
  States_Var[,6,scen_index]<-beta9_var*(beta9_var>0)

}

crit<-1.64
init_offset<-1
axTime<-axTime[(init_offset+1):cT]

# C_star
mean1<-States[(init_offset+1):cT,1,1]
std1<-sqrt(States_Var[(init_offset+1):cT,1,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[(init_offset+1):cT,1,2]
std2<-sqrt(States_Var[(init_offset+1):cT,1,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymax<-max(ymax1,ymax2)
ymin<-min(ymin1,ymin2)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='C* (GtC)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2019,lty=3,lwd=1,col='black')
legend("topleft",c("0.01 GDP growth","0.034 GDP growth"),col=c("green","grey"),lty=c(1,1),lwd=c(5,5),bty='n')

# G_ATM_star
mean1<-States[(init_offset+1):cT,2,1]
std1<-sqrt(States_Var[(init_offset+1):cT,2,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[(init_offset+1):cT,2,2]
std2<-sqrt(States_Var[(init_offset+1):cT,2,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymax<-max(ymax1,ymax2)
ymin<-min(ymin1,ymin2)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='G_ATM* (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2019,lty=3,lwd=1,col='black')
legend("topright",c("0.01 GDP growth","0.034 GDP growth"),col=c("green","grey"),lty=c(1,1),lwd=c(5,5),bty='n')

# S_LND_star
mean1<-States[(init_offset+1):cT,3,1]
std1<-sqrt(States_Var[(init_offset+1):cT,3,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[(init_offset+1):cT,3,2]
std2<-sqrt(States_Var[(init_offset+1):cT,3,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymax<-max(ymax1,ymax2)
ymin<-min(ymin1,ymin2)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='S_LND* (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2019,lty=3,lwd=1,col='black')
legend("topright",c("0.01 GDP growth","0.034 GDP growth"),col=c("green","grey"),lty=c(1,1),lwd=c(5,5),bty='n')

# S_OCN_star
mean1<-States[(init_offset+1):cT,4,1]
std1<-sqrt(States_Var[(init_offset+1):cT,4,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[(init_offset+1):cT,4,2]
std2<-sqrt(States_Var[(init_offset+1):cT,4,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymax<-max(ymax1,ymax2)
ymin<-min(ymin1,ymin2)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='S_OCN* (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2019,lty=3,lwd=1,col='black')
legend("topleft",c("0.01 GDP growth","0.034 GDP growth"),col=c("green","grey"),lty=c(1,1),lwd=c(5,5),bty='n')

# E_star
mean1<-States[(init_offset+1):cT,5,1]
std1<-sqrt(States_Var[(init_offset+1):cT,5,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[(init_offset+1):cT,5,2]
std2<-sqrt(States_Var[(init_offset+1):cT,5,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymax<-max(ymax1,ymax2)
ymin<-min(ymin1,ymin2)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='E* (GtC/Yr)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.5),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.5),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2019,lty=3,lwd=1,col='black')
legend("topright",c("0.01 GDP growth","0.034 GDP growth"),col=c("green","grey"),lty=c(1,1),lwd=c(5,5),bty='n')

# beta_{9,t}
mean1<-States[(init_offset+1):cT,6,1]
std1<-sqrt(States_Var[(init_offset+1):cT,6,1])
CIup1<-mean1+crit*std1
CIdown1<-mean1-crit*std1
mean2<-States[(init_offset+1):cT,6,2]
std2<-sqrt(States_Var[(init_offset+1):cT,6,2])
CIup2<-mean2+crit*std2
CIdown2<-mean2-crit*std2
ymax1<-max(CIup1)
ymax2<-max(CIup2)
ymin1<-min(CIdown1)
ymin2<-min(CIdown2)
ymax<-max(ymax1,ymax2)
ymin<-min(ymin1,ymin2)
plot(axTime,mean1,type='l',lwd=3,col='black',xlab='Year',ylab='beta_9 (GtC)',ylim=c(ymin,ymax))
polygon(c(axTime,rev(axTime)),c(CIup1, rev(CIdown1)),col=adjustcolor("green",alpha.f=0.3),border=NA)
lines(axTime,CIup1,type='l',lwd=1,lty=3,col='green')
lines(axTime,CIdown1,type='l',lwd=1,lty=3,col='green')
lines(axTime,mean2,type='l',lwd=3,col='black')
polygon(c(axTime,rev(axTime)),c(CIup2, rev(CIdown2)),col=adjustcolor("grey",alpha.f=0.3),border=NA)
lines(axTime,CIup2,type='l',lwd=1,lty=3,col='grey')
lines(axTime,CIdown2,type='l',lwd=1,lty=3,col='grey')
lines(axTime[1:endIdx],mean1[1:endIdx],type='l',lwd=3,lty=1,col='black')
abline(v=2019,lty=3,lwd=1,col='black')
legend("topleft",c("0.01 GDP growth","0.034 GDP growth"),col=c("green","grey"),lty=c(1,1),lwd=c(5,5),bty='n')




function L = erv_likelihood(theta,erv)

%parameters
erv.theta=theta;
[betar,gamma,betav,phi,psi,matheta,d,sigmav]=erv_retrieve_pars(erv);

%restrictions
M=1e20;
if (d<=-0.5)||(d>=0.5)
    L=M;
    return;
end
if abs(phi)>=1
    L=M;
    return;
end
if strcmp(erv.nonlin,'g_logistic_regime')
    if (gamma(end-1)<=0)
        L=M;
    end
end
%if strcmp(erv.nonlin,'g_logistic_change')
%    if (gamma(end)<0)||(gamma(end)>1)
%        L=M;
%    end
%end

%data
v=erv.v;
r=erv.r;
X=erv.X;
Z=erv.Z;

%settings and initializations
T=erv.T;
trunc=100;  %fractional difference truncation lag
u=zeros(T,1); 
w=zeros(T,1); %=v_t-Z\beta_v-\Psi(L) g(z_{t-1}) = (1-L)^{-d}\Theta(L) u_t
w1=v-Z*betav;
g=erv.nonlin;
o=size(psi,1);
p=size(phi,1);
q=size(matheta,1); % only MA(1) is implemented
m=max([(o+1) p q]);
fract_part=zeros(T,1);
ar_part=zeros(T,1);
w(1:m)=w1(1:m);

%(1) BACK OUT ERROR z(t)
if erv.kinmean>0
    z=(r-X*betar-gamma(1)*sqrt(exp(v)))./sqrt(exp(v)); 
else
    z=(r-X*betar)./sqrt(exp(v));
end

%evaluate non-linear function
if erv.kinmean>0
    gz=feval(g,z,gamma(2:erv.kgamma),erv);
else
    gz=feval(g,z,gamma,erv);
end

%(2) BACK OUT ERROR u(t)
for t=m+1:trunc
    w(t)=w1(t)-[1;psi]'*flipud(gz(t-o-1:t-1));
    tvec=(1:t)';
    factvec=factorial(tvec-1);
    pvec=[1;d-(tvec(1:t-1)-1)];
    alt=(-1).^(tvec-1);
    fdcoeff=alt.*cumprod(pvec)./factvec;
    fract_part(t)=fdcoeff'*flipud(w(1:t));
    ar_part(t)=[1;-phi]'*flipud(fract_part(t-p:t));
    if ~isempty(matheta)
        mavec=(-matheta).^(tvec-1);
        u(t)=mavec'*flipud(ar_part(1:t));
    end
end
tvec=(1:trunc)';
factvec=factorial(tvec-1);
pvec=[1;d-(tvec(1:trunc-1)-1)];
alt=(-1).^(tvec-1);
fdcoeff=alt.*cumprod(pvec)./factvec;
for t=trunc+1:T
    w(t)=w1(t)-[1;psi]'*flipud(gz(t-o-1:t-1));
    fract_part(t)=fdcoeff'*flipud(w(t-trunc+1:t));
    ar_part(t)=[1;-phi]'*flipud(fract_part(t-p:t));
    if ~isempty(matheta)
        mavec=(-matheta).^(0:t-1)';
        u(t)=mavec'*flipud(ar_part(1:t));
    end
end
if isempty(matheta)
    u=ar_part;
end

%calculate normal likelihood
L=-log(2*pi)-1/2*log(sigmav^2)-1/2*(sum((z.^2))+sum(u.^2/sigmav^2))/T;
L=-L;

%safeguarding
if isnan(L) | isinf(L) | ~isreal(L)
   L=M;
end
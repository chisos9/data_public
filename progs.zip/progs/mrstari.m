function output = mrstari(y,q,p,output_linear,options)

options_optim = optimset('Display','off','Jacobian','on','MaxFunEvals',1e10,...
    'LargeScale','off','MaxIter',4000,'TolFun',1e-8,...
    'DerivativeCheck','on','LevenbergMarquardt','on','FunValCheck', 'off',...
    'LineSearchType','cubicpoly','TolX',1e-8,'GradObj','on','Hessian','fin-diff-grads',...
    'Algorithm','interior-point','Diagnostics','off','FinDiffType','central',...
    'UseParallel','always','SubproblemAlgorithm','cg');

func='msecostnl';

pnew = p + options.const;

[T,nQ] = size(q);

switch options.grow_crit
    case 1
        [increase,output.pvalue_lt] = testnonlinear(output_linear.V,q,e,...
            output_linear.V,options.rob,options.const,options.index,options.sig);
        
        output.isLinear = 1 - increase;
        if increase == 1
            output.gamma = [];
            output.c     = [];
            output.d     = [];
        end

        m = 0; % number of nonlinear terms in the model.
        while increase==1 && m<options.size
            m = m + 1;

            [output.gamma,output.c,output.d] = ...
                startvalfi(y,q,m,output.gamma,output.c,T,p,...
                           options.const,options.trunc);
            psi = setparfi(output.d,output.gamma,output.c);
            lb  = [-0.5;zeros(m,1);prctile(q,5)*ones(m,1)];
            ub  = [0.5;20*ones(m,1);prctile(q,95)*ones(m,1)];
            [psi,~,~,output.exitflag_nlsq,output.optimization] = ...
                fmincon(func,psi,[],[],[],[],lb,ub,options_optim,y,q,p,m,T,nQ,options.const,options.trunc);
                
            [output.d,output.gamma,output.c] = getparfi(psi,m,nQ);

            V = zeros(T-p,pnew*(m+1));
            Y = zeros(T-p,pnew*(m+1));
            if options.const == 1
                V(:,1) = ones(T-p,1);
                Y(:,1) = ones(T-p,1);
            end
            for i=1:p
                V(:,i + const) = v(p-i+1:T-i);
                Y(:,i + const) = y(p-i+1:T-i);
            end
            v = v(p+1:end);
            y = y(p+1:end);

            output.fX = zeros(T,m);
            for i = 1:m
                output.fX(:,i)           = siglog(output.gamma(:,i)'*q-output.c(i));
                V(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*V(:,1:pnew);
                Y(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*y(:,1:pnew);
            end
            theta = (V'*V)\(V'*v);
            output.phi   = reshape(theta,pnew,m+1);
            output.vhat  = V(:,1:pnew)*output.phi(:,1) + V(:,pnew+1:end)*vec(output.phi(:,2:end));
            
            z = y - Y(:,1:pnew)*output.phi(:,1) + Y(:,pnew+1:end)*vec(output.phi(:,2:end));
            output.error = v - output.vhat;
            
            dfX  = dsiglog(output.fX);
                     
            [output.G,output.B] = gradgnonlinear(z);
            
            G = [output.G.alpha output.G.beta output.G.lambda output.G.gamma output.G.c];
                                   
            [increase,output.pvalue(m)] = testnonlinear(G);
            
            output.regimes = m+1;
        end
    case 2
        gamma = [];
        c     = [];
        d     = [];
        psi_IC = cell(options.size,1);
        exitflag_nlsq = cell(options.size,1);
        optimization  = cell(options.size,1);
        for m=1:options.size
            [gamma,c,d] = startvalfi(y,q,m,output.gamma,output.c,T,output.p,...
                           options.const,options.trunc);
            psi         = setparfi(d,gamma,c);
            [psi,~,~,exitflag_nlsq{m},optimization{m}] = fmincon();
            psi_IC{m} = psi;
            
            [d,gamma,c] = getparfi(psi,m);

            V = zeros(T-p,pnew*(m+1));
            if options.const == 1
                V(:,1) = ones(T-p,1);
            end
            for i=1:p
                V(:,i + const) = v(p-i+1:T-i);
                Y(:,i + const) = y(p-i+1:T-i);
            end
            v = v(p+1:end);
            
            fX = zeros(T,m);
            for i = 1:m
                fX(:,i)                  = siglog(gamma(i)*(q-c(i)));
                V(:,i*pnew+1:(i+1)*pnew) = repmat(fX(:,i),1,pnew).*V(:,1:pnew);
                Y(:,i*pnew+1:(i+1)*pnew) = repmat(fX(:,i),1,pnew).*y(:,1:pnew);
            end
            theta = (V'*V)\(V'*v);
            phi   = reshape(theta,pnew,m+1);
            vhat  = V(:,1:pnew)*phi(:,1) + V(:,pnew+1:end)*vec(phi(:,2:end));
            ehat  = v - vhat;
                      
            loglkh = log((ehat'*ehat)/T);
            numpar = length(theta)+length(psi);
                      
            output.AIC(m)  = loglkh + numpar*(2/T);
            output.BIC(m)  = loglkh + numpar*(log(T)/T);
            output.HQIC(m) = loglkh + numpar*(2*log(log(T))/T);
        end      
        
        %------------------------------------------------------------------
        % Linear model estimation
        %------------------------------------------------------------------
        output.AIC_linear  = output_linear.AIC;
        output.BIC_linear  = output_linear.BIC;
        output.HQIC_linear = output_linear.HQIC;
        
        %------------------------------------------------------------------
        % Select the best specification
        %------------------------------------------------------------------
        if options.IC==1
            if min(output.AIC)>output.AIC_linear
                m = 0;
            else
                m = find(output.AIC == min(output.AIC));
            end
        elseif options.IC==2
            if min(output.BIC)>output.BIC_linear
                m = 0;
            else
                m = find(output.BIC == min(output.BIC));
            end
        else
            if min(output.HQIC)>output.HQIC_linear
                m = 0;
            else
                m = find(output.HQIC == min(output.HQIC));
            end
        end
        if m>0                  
            psi = psi_IC{m};
            output.exitflag_nlsq = exitflag_nlsq{m};
            output.optimization  = optimization{m};
        
            [output.d,output.gamma,output.c] = getparfi(psi,m);

            V = zeros(T-p,pnew*(m+1));
            Y = zeros(T-p,pnew*(m+1));
            if options.const == 1
                V(:,1) = ones(T-p,1);
                Y(:,1) = ones(T-p,1);
            end
            for i=1:p
                V(:,i + const) = v(p-i+1:T-i);
                Y(:,i + const) = y(p-i+1:T-i);
            end
            v = v(p+1:end);
            y = y(p+1:end);

            output.fX = zeros(T,m);
            for i = 1:m
                output.fX(:,i)           = siglog(output.gamma(i)*(q-output.c(i)));
                V(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*V(:,1:pnew);
                Y(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*y(:,1:pnew);
            end
            theta = (V'*V)\(V'*v);
            output.phi   = reshape(theta,pnew,m+1);
            output.vhat  = V(:,1:pnew)*output.phi(:,1) ...
                + V(:,pnew+1:end)*vec(output.phi(:,2:end));
            z            = y - Y(:,1:pnew)*output.phi(:,1) ...
                + Y(:,pnew+1:end)*vec(output.phi(:,2:end));
            output.error = v - vhat;
            
            [output.G,output.B] = gradg(x,w,q,z,output.error,output.lambda,...
                output.gamma,output.c,dfX,m,n,nX,T);
                                            
            output.regimes = m+1;
        end
    case 3
        gamma = [];
        c     = [];
        for m=1:options.size
            [output.gamma,output.c] = startval(y,x,w,q,m,gamma,c,n,nX,T);
            output.psi = setpar(output.gamma,output.c);
            [output.psi,~,~,output.exitflag_nlsq,output.optimization] = lsqnonlin(func,output.psi,[],[],options_lsq,y,x,w,q,m,n,nX,T);
            
            [output.gamma,output.c] = getpar(output.psi,m);

            output.fX = zeros(T,m);
            z         = zeros(T,n+nX*m);
            z(:,1:n)  = [x w];
            for i=1:m
                output.fX(:,i)           = siglog(output.gamma(i)*(q-output.c(i)));
                z(:,n+(i-1)*nX+1:n+i*nX) = repmat(output.fX(:,i),1,nX).*x;
            end
            dfX  = dsiglog(output.fX);
            
            theta  = (z'*z)\(z'*y);
            output.alpha  = theta(1:nX);
            if isempty(w)==1
                output.lambda = reshape(theta(nX+1:end),nX,m);
                output.yhat   = x*output.alpha + sum((output.fX*output.lambda').*x,2);
            else
                output.beta   = theta(nX+1:n);
                output.lambda = reshape(theta(n+1:end),nX,m);
                output.yhat   = x*output.alpha + w*output.beta + sum((output.fX*output.lambda').*x,2); 
            end
            output.error = y - output.yhat;
        end
        
        
        [output.G,output.B] = gradg(x,w,q,z,output.error,output.lambda,...
                output.gamma,output.c,dfX,m,n,nX,T);    
            
        output.regimes = m+1;
end


if m>0
    %----------------------------------------------------------------------
    % Impose restrictions on parameter c (ordering)
    %----------------------------------------------------------------------
    q = q*stdq;
    output.gamma = output.gamma/stdq;
    output.c     = output.c*stdq;
    [~,index] = sortrows([output.gamma output.c],2);
    output.gamma=output.gamma(index);
    output.c=output.c(index);
      
    output.fX = zeros(T,m); 
    z  = zeros(T,n+nX*m);
    z(:,1:n)  = [x w];
    for i=1:m
        output.fX(:,i)           = siglog(output.gamma(i)*(q-output.c(i)));
        z(:,n+(i-1)*nX+1:n+i*nX) = repmat(output.fX(:,i),1,nX).*x;
    end
    theta  = (z'*z)\(z'*y);
    output.alpha  = theta(1:nX);
    if isempty(w)==1
        output.beta   = [];
        output.lambda = reshape(theta(nX+1:end),nX,m);
        output.yhat   = x*output.alpha + sum((output.fX*output.lambda').*x,2);
    else
        output.beta   = theta(nX+1:n);
        output.lambda = reshape(theta(n+1:end),nX,m);
        output.yhat   = x*output.alpha + w*output.beta + sum((output.fX*output.lambda').*x,2);
    end
    output.error = y - output.yhat;

    [output.G,output.B] = gradg(x,w,q,z,output.error,output.lambda,...
        output.gamma,output.c,dfX,m,n,nX,T);

    % -------------------------------------------------------------------------
    % Compute standard errors & diagnostic statistics
    % -------------------------------------------------------------------------
    if options.se==1
        % Compute the Hessian and the Sandwich Estimator
        [output.H,output.A] = calch(x,w,q,z(:,n+1:end),output.error,...
            output.G.gamma,output.G.c,output.lambda,output.gamma,...
            output.c,output.fX,dfX,m,nX,T);

        output.Sigma = ((output.A\output.B)/output.A);
    else
        % Compute the Outer Product of the Gradient
        output.Sigma = output.B;
    end
    
    % Standard errors
    se = sqrt(diag(output.Sigma));

    output.alpha_se = se(1:nX);
    output.alpha_t  = output.alpha/output.alpha_se;
    if isempty(w)==1
        output.beta_se = [];
        output.beta_t  = [];
    else
        output.beta_se = se(nX+1:n);
        output.beta_se = output.beta/output.beta_se;
    end
    output.lambda_se = reshape(se(n+1:n+m*nX),nX,m);
    output.lambda_t  = output.lambda/output.lambda_se;
    output.gamma_se  = se(n+m*nX+1:n+m*(nX+1));
    output.gamma_t   = output.gamma/output.gamma_se;
    output.c_se      = se(n+m*(nX+1)+1:end);
    output.c_t       = output.c/output.c_se;

    output.y = y;    % Actual dependent variable
    output.x = x;    % Regressors with time-varying coefficients
    output.w = w;    % Regressors with fixed coefficients
    output.q = q;    % Transition variable
    
    % Compute diagnostic statistics
    if options.diagnostics==1
        output.mean     = mean(output.error);       % residual mean
        output.std      = std(output.error);        % residual standard deviation
        output.median   = median(output.error);     % residual median
        output.max      = max(output.error);        % max residual
        output.min      = min(output.error);        % min residual
        output.kurtosis = kurtosis(output.error);   % residual kurtosis
        output.skewness = skewness(output.error);   % residual skewness
        output.R2       = 1 - ...                   % R-squared
            (output.error'*output.error)/((y-mean(y))'*(y-mean(y)));

        [~,output.pvalue_jb,output.stat_jb] = ...   % Jarque-Bera test
            jbtest(output.error);   
        [~,output.pvalue_lillie,output.stat_lillie] = ...   % Lilliefors test
            lillietest(output.error); 
    end
else
    output = [];
end
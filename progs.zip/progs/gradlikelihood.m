function G = gradlikelihood(V,u,q,fX,d,phi,gamma,c,m,p,T,const)

if const==1
    aux = zeros(T-p-99,1);
else
    aux = zeros(T-p-100,1);
end

dldphi0 = -V(:,1:p);

if m>0
    if const==1
        dldgammam = zeros(T-p+1,m);
        dldcm     = zeros(T-p+1,m);
    else
        dldgammam = zeros(T-p,m);
        dldcm     = zeros(T-p,m);
    end
    dldphim   = -V(:,p+1:end);

    for i = 1:m  
        dldgammam(:,i)= -(V(:,1:p)*phi(:,i+1)).*fX(:,i).*(1-fX(:,i)).*(q-c(i));
        dldcm(:,i)     = gamma(i)*(V(:,1:p)*phi(:,i+1)).*fX(:,i).*(1-fX(:,i));
    end
end

trunc = 100;
if const==1
    for j=1:trunc
        i=0:j-1;
        aux(:,j) = ((((-1)^j)/factorial(j))*sum(1./(d-i))*prod(d-i)).*u(trunc-j+1:T-p+1-j);
    end
else
    for j=1:trunc
        i=0:j-1;
        aux(:,j) = ((((-1)^j)/factorial(j))*sum(1./(d-i))*prod(d-i)).*u(trunc-j+1:T-p-j);
    end
end
dldd = [zeros(trunc,1);sum(aux,2)];

if d>0
    if m>0
        G = [dldd dldphi0 dldphim dldgammam dldcm];
    else
        G = [dldd dldphi0];
    end
else
    if m>0
        G = [dldphi0 dldphim dldgammam dldcm];
    else
        G = dldphi0;
    end
end
%--------------------------------------------------------------------------
% Settings
%--------------------------------------------------------------------------
options_linear.pmax        = 5;
options_linear.const       = 0;
options_linear.trunc       = 100;
options_linear.index       = 1;
options_linear.nonlinear   = 1;
options_linear.diagnostics = 0;
options_linear.IC          = 3;

options_nonlinear.pmax        = 5;
options_nonlinear.const       = 0;
options_nonlinear.trunc       = 100;
options_nonlinear.index       = 1;
options_nonlinear.rob         = 1;
options_nonlinear.sig         = 0.95;
options_nonlinear.size        = 4;
options_nonlinear.Nstart      = 100;
options_nonlinear.C           = 2;
options_nonlinear.diagnostics = 0;
options_nonlinear.grow_crit   = 1;
options_nonlinear.IC          = 3;

%--------------------------------------------------------------------------
% data
%--------------------------------------------------------------------------
names = strvcat('AA','AXP','BA','BAC','CAT','CSCO','CVX','DD','DIS','GE','HD','HPQ','IBM','INTC','JNJ','JPM','KFT','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','T','UTX','VZ','WMT','XOM');

N = length(names);
K = 10;

yhat_linear      = cell(N,5);
yhat_nonlinear   = cell(N,5);   
output_linear    = cell(N,1,5);
output_nonlinear = cell(N,1,5);
    
      
for flag_vol = 1:5
    flag_vol
    
    for n = 1:N
        data = load(strcat('..\data\',names(n,:),'.txt'));
        
        date = data(:,1);
        if n==7
            aux  = find(date==20011010);
        elseif n==17
            aux  = find(date==20010613);
        else
            aux  = find(date==20000103);
        end
        data = data(aux:end,:);
        date = data(:,1);
        
        r      = 100*data(:,end);
        y      = data(:,flag_vol+2);
        logy   = log(y);
        stdret = r./sqrt(y);
        
        T0 = find(date==20051230);       
        T  = size(y,1); 
       
        %------------------------------------------------------------------
        % Estimation
        %------------------------------------------------------------------
        j = 0;
        for t = T0:T-K
            l = t-T0+1;
            trend = (l+1:t);
            trend = trend';
            if rem(l,50)==0 || l==1
                j = j+1;
                [output_linear{n,j,flag_vol},output_nonlinear{n,j,flag_vol}] = estimation_arfi(logy(l+1:t),trend,[],options_linear,options_nonlinear);
            end
  
            aux = logy(2+output_linear{n,j,flag_vol}.p:t+1)- output_linear{n,j,flag_vol}.ybar;
            v   = fracfilter(aux,output_linear{n,j,flag_vol}.d,options_linear.trunc);
        
            yhat_linear{n,flag_vol}(l,:) =  output_linear{n,j,flag_vol}.ybar + mrstarfiprev(aux(2:end),v(1:end-1),[],[],[],...
                                                                                   output_linear{n,j,flag_vol}.phi,...
                                                                                   output_linear{n,j,flag_vol}.d,...
                                                                                   [],[],[],...
                                                                                   output_linear{n,j,flag_vol}.p,0,...
                                                                                   options_linear.const,...
                                                                                   options_linear.trunc,K,[]);                                                    
            if output_nonlinear{n,j,flag_vol}.regimes>1
                aux = logy(2+output_nonlinear{n,j,flag_vol}.p:t)- output_linear{n,j,flag_vol}.ybar;
                v   = fracfilter(aux,output_nonlinear{n,j,flag_vol}.d,options_nonlinear.trunc);
             
                yhat_nonlinear{n,flag_vol}(l,:) = output_linear{n,j,flag_vol}.ybar + mrstarfiprev(aux,v,(t+1),stdret(2:t),output_linear{n,j,flag_vol}.error,...
                                                                                output_nonlinear{n,j,flag_vol}.phi,...
                                                                                output_nonlinear{n,j,flag_vol}.d,...
                                                                                output_nonlinear{n,j,flag_vol}.c,output_nonlinear{n,j,flag_vol}.gamma,output_nonlinear{n,j,flag_vol}.omega,...
                                                                                output_nonlinear{n,j,flag_vol}.p,output_nonlinear{n,j,flag_vol}.regimes-1,...
                                                                                options_nonlinear.const,...
                                                                                options_nonlinear.trunc,K,0);
            else
                yhat_nonlinear{n,flag_vol}(l,:)=yhat_linear{n,flag_vol}(l,:);
            end
        end
    end
end
save results_arfima_break
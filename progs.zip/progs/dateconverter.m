T=size(A,1);
dates=num2str(A(:,1));
mdates=zeros(T,1);
for t=1:T
    datestring=[dates(t,1:4) '/' dates(t,5:6) '/' dates(t,7:8)];
    mdates(t)=datenum(datestring);
end
B=[mdates A(:,2:end)];
A=B;
clear B mdates datestring t dates T

%plot(A(:,1), log(A(:,3)))
%datetick('x','yyyy')
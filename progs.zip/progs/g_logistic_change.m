function gz = g_logistic_change(z,gamma,erv)

T=erv.T;
t=(1:T)';
k=floor(T/2);
gz=abs(mean(erv.v))./(1+exp(-gamma*(t-k)));
function erv=run_erv_realdata()

addpath('C:\Program Files\MATLAB\R2006a\eric\papers\erv\series');
load AA        %1
%load AIG       %0
%load BA        %1
%load CAT       %1
%load GE        %0
%load GM        %(1) delete outlier, then linear function
%load HP        %1
%load IBM       %0
%load INTC      %0      
%load JNJ       %0
%load KO        %0
%load MRK       %0
%load MSFT      %0
%load PFE       %0
%load WMT       %0
%load XON       %0

%setup problem structure
T=length(lv);
X=ones(T,1);
Z=ones(T,1);
kphi=0;
kpsi=0;
kmatheta=0;
kinmean=0;
g='g_nelson';
erv = erv_setup(lv,ret,X,Z,kphi,kpsi,kmatheta,kinmean,g);

%call solver
erv=erv_matlab(erv);
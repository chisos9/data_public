function [alpha,lambda,gamma,c,e,G]=parestlm(y,z,x,T,p)

x=x';
z=z';

func='msecost';
goal=0;

[alpha,lambda,gamma,c,bestcost]=startval(x,y,z,T,p);
X=setX(gamma,c);

options = optimset('Display','off','Jacobian','on','MaxFunEvals',1e10,'LargeScale','off','MaxIter',3000,'TolFun',0,'DerivativeCheck','off','LevenbergMarquardt','on','LineSearchType','cubicpoly','TolX',0);

[X,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(func,X,[],[],options,x,y,z,p,T);

[gamma,c]=getX(X);

if gamma<0
    gamma=-gamma;
end

fX=siglog(gamma*(x-c));
dfX=dsiglog(fX);
%------------------------------------------------------
Z=[z' (repmat(fX,p,1)'.*z')];
theta=pinv(Z'*Z)*Z'*y;
alpha=theta(1:p);
lambda=theta(p+1:2*p);

y_hat=alpha'*z+lambda'*(repmat(fX,p,1).*z);

e=y-y_hat';

X=setX(gamma,c);

[ggamma,gc]=gradG(X,x,z,lambda,dfX);

galpha=z;
glambda=(repmat(fX,p,1).*z);

G=[ggamma',gc',galpha',glambda'];

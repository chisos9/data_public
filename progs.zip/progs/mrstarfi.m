function output = mrstarfi(y,q,p,output_linear,options)

options_optim = optimset('Display','off','Jacobian','on','MaxFunEvals',1e10,...
    'LargeScale','off','MaxIter',2000,'TolFun',1e-10,...
    'DerivativeCheck','off','FunValCheck', 'off',...
    'TolX',1e-10,'GradObj','on',...
    'Algorithm','interior-point','Diagnostics','off','FinDiffType','central',...
    'UseParallel','always','SubproblemAlgorithm','cg','GradConstr','on');

func      = 'msecostnl';
cons_func = 'consarfi';

pnew = p + options.const;

min_d = 0;

[T,nQ] = size(q);

%--------------------------------------------------------------------------
% Standardize transition variable
%--------------------------------------------------------------------------
if nQ == 1
    stdq = std(q);
    q    = q./stdq;
end

switch options.grow_crit
    case 1
        [increase,output.pvalue_lt] = testnonlinear(output_linear.V,q(p+1:end,:),output_linear.error,...
            [output_linear.G.phi, output_linear.G.d],options.rob,options.const,options.index,options.sig);
        output.isLinear = 1 - increase;
        if increase == 1
            output.gamma = [];
            output.omega = [];
            output.c     = [];
        end

        m = 0; % number of nonlinear terms in the model.
        while increase==1 && m<options.size
            m = m + 1;

            % Choose starting values for d, c, gamma.
            [output.d,output.c,output.gamma,output.omega] = ...
                startvalfi(y,q,m,output.c,output.gamma,output.omega,...
                T,p,nQ,options.const,options.trunc,options.Nstart);
            psi = setparfi(output.d,output.c,output.gamma,output.omega);
            
            % bounds for d, gamma, and c.
            lb_gamma      = zeros(m,1);
            ub_gamma      = 20*ones(m,1);
            if nQ>1
                lb  = [min_d;-inf*ones(m,1);lb_gamma;-inf*ones(m*nQ,1)];
                ub  = [0.49;inf*ones(m,1);ub_gamma;inf*ones(m*nQ,1)];
                [psi,~,~,output.exitflag_nlsq,output.optimization] = ...
                    fmincon(func,psi,[],[],[],[],lb,ub,cons_func,options_optim,y,q,p,m,T,nQ,options.const,options.trunc);
            else
                lb  = [min_d;repmat(prctile(q,5),m,1);lb_gamma];
                ub  = [0.49;repmat(prctile(q,95),m,1);ub_gamma];
                [psi,~,~,output.exitflag_nlsq,output.optimization] = ...
                    fmincon(func,psi,[],[],[],[],lb,ub,[],options_optim,y,q,p,m,T,nQ,options.const,options.trunc);
            end             
            [output.d,output.c,output.gamma,output.omega] = getparfi(psi,m,nQ);
            
            output.v = fracfilter(y,output.d,options.trunc);
                        
            output.V = zeros(T-p,pnew*(m+1));
            output.Y = zeros(T-p,pnew*(m+1));
            if options.const == 1
                output.V(:,1) = ones(T-p,1);
                output.Y(:,1) = ones(T-p,1);
            end
            for i=1:p
                output.V(:,i + options.const) = output.v(p-i+1:T-i);
                output.Y(:,i + options.const) = y(p-i+1:T-i);
            end
            output.v = output.v(p+1:end);
            output.y = y(p+1:end);
            output.q = q(p+1:end,:);
            
            output.transition = zeros(T-p,m);
            output.fX = zeros(T-p,m);
            for i = 1:m
                output.transition(:,i) = output.gamma(i)*(output.q*output.omega(:,i)-output.c(i)); 
                output.fX(:,i)         = siglog(output.transition(:,i));
                output.V(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*output.V(:,1:pnew);
                output.Y(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*output.Y(:,1:pnew);
            end
            theta = (output.V'*output.V)\(output.V'*output.v);
            output.phi   = reshape(theta,pnew,m+1);
            output.vhat  = output.V(:,1:pnew)*output.phi(:,1) + output.V(:,pnew+1:end)*vec(output.phi(:,2:end));
            
            output.z = output.y - output.Y(:,1:pnew)*output.phi(:,1) - output.Y(:,pnew+1:end)*vec(output.phi(:,2:end));
            output.error = output.v - output.vhat;
            
            dfX  = dsiglog(output.fX);
                     
            [output.Grad,output.B] = gradgnonlinear(output.V,output.error,output.z,...
                output.q,p,m,nQ,output.phi,output.d,output.c,output.gamma,output.omega,...
                dfX,T,options.trunc,options.const);
            
            output.G = [output.Grad.phi output.Grad.d output.Grad.c output.Grad.gamma output.Grad.omega];
                                   
            [increase,output.pvalue(m)] = testnonlinear(output.V,output.q,output.error,output.G,options.rob,options.const,options.index,1-(1-options.sig)/(options.C^m));
            
            output.regimes = m+1;
        end
    case 2
        gamma = [];
        omega = [];
        c     = [];
        psi_IC = cell(options.size,1);
        exitflag_nlsq = cell(options.size,1);
        optimization  = cell(options.size,1);
        for m = 1:options.size
            % Choose starting values for d, c, gamma.
            [d,c,gamma,omega] = startvalfi(y,q,m,c,gamma,omega,...
                T,p,nQ,options.const,options.trunc,options.Nstart);
            
            psi = setparfi(d,c,gamma,omega);
            
            % bounds for d, gamma, and c.
            lb_gamma      = zeros(m,1);
            ub_gamma      = 20*ones(m,1);
            if nQ>1
                lb  = [min_d;-inf*ones(m,1);lb_gamma;-inf*ones(m*nQ,1)];
                ub  = [0.49;inf*ones(m,1);ub_gamma;inf*ones(m*nQ,1)];
                [psi_IC{m},~,~,output.exitflag_nlsq,output.optimization] = ...
                    fmincon(func,psi,[],[],[],[],lb,ub,cons_func,options_optim,y,q,p,m,T,nQ,options.const,options.trunc);
            else
                lb  = [min_d;repmat(prctile(q,5),m,1);lb_gamma];
                ub  = [0.49;repmat(prctile(q,95),m,1);ub_gamma];
                [psi_IC{m},~,~,output.exitflag_nlsq,output.optimization] = ...
                    fmincon(func,psi,[],[],[],[],lb,ub,[],options_optim,y,q,p,m,T,nQ,options.const,options.trunc);
            end
                
            [d,c,gamma,omega] = getparfi(psi_IC{m},m,nQ);
            
            v = fracfilter(y,d,options.trunc);

            V = zeros(T-p,pnew*(m+1));
            Y = zeros(T-p,pnew*(m+1));
            if options.const == 1
                V(:,1) = ones(T-p,1);
                Y(:,1) = ones(T-p,1);
            end
            for i=1:p
                V(:,i + options.const) = v(p-i+1:T-i);
                Y(:,i + options.const) = y(p-i+1:T-i);
            end
            v = v(p+1:end);
            
            transition = zeros(T-p,m);
            fX = zeros(T-p,m);
            for i = 1:m
                transition(:,i) = gamma(i)*(q(p+1:end,:)*omega(:,i)-c(i)); 
                fX(:,i)         = siglog(transition(:,i));
                V(:,i*pnew+1:(i+1)*pnew) = repmat(fX(:,i),1,pnew).*V(:,1:pnew);
                Y(:,i*pnew+1:(i+1)*pnew) = repmat(fX(:,i),1,pnew).*Y(:,1:pnew);
            end
            theta = (V'*V)\(V'*v);
            phi   = reshape(theta,pnew,m+1);
            vhat  = V(:,1:pnew)*phi(:,1) + V(:,pnew+1:end)*vec(phi(:,2:end));
            
            ehat = v - vhat;
                                
            loglkh = log((ehat'*ehat)/T);
            numpar = length(theta)+length(psi);
                      
            output.AIC(m)  = loglkh + numpar*(2/T);
            output.BIC(m)  = loglkh + numpar*(log(T)/T);
            output.HQIC(m) = loglkh + numpar*(2*log(log(T))/T);
        end      
        
        %------------------------------------------------------------------
        % Linear model estimation
        %------------------------------------------------------------------
        output.AIC_linear  = output_linear.AIC;
        output.BIC_linear  = output_linear.BIC;
        output.HQIC_linear = output_linear.HQIC;
        
        %------------------------------------------------------------------
        % Select the best specification
        %------------------------------------------------------------------
        if options.IC==1
            if min(output.AIC)>output.AIC_linear
                m = 0;
            else
                m = find(output.AIC == min(output.AIC));
            end
        elseif options.IC==2
            if min(output.BIC)>output.BIC_linear
                m = 0;
            else
                m = find(output.BIC == min(output.BIC));
            end
        else
            if min(output.HQIC)>output.HQIC_linear
                m = 0;
            else
                m = find(output.HQIC == min(output.HQIC));
            end
        end
        if m>0                  
            psi = psi_IC{m};
            output.exitflag_nlsq = exitflag_nlsq{m};
            output.optimization  = optimization{m};
        
            [output.d,output.c,output.gamma,output.omega] = getparfi(psi,m,nQ);
            
            output.v = fracfilter(y,output.d,options.trunc);

            output.V = zeros(T-p,pnew*(m+1));
            output.Y = zeros(T-p,pnew*(m+1));
            if options.const == 1
                output.V(:,1) = ones(T-p,1);
                output.Y(:,1) = ones(T-p,1);
            end
            for i=1:p
                output.V(:,i + options.const) = output.v(p-i+1:T-i);
                output.Y(:,i + options.const) = y(p-i+1:T-i);
            end
            output.v = output.v(p+1:end);
            output.y = y(p+1:end);
            output.q = q(p+1:end,:);
            
            output.transition = zeros(T-p,m);
            output.fX = zeros(T-p,m);
            for i = 1:m
                output.transition(:,i) = output.gamma(i)*(output.q*output.omega(:,i)-output.c(i)); 
                output.fX(:,i)         = siglog(output.transition(:,i));
                output.V(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*output.V(:,1:pnew);
                output.Y(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*output.Y(:,1:pnew);
            end
            theta = (output.V'*output.V)\(output.V'*output.v);
            output.phi   = reshape(theta,pnew,m+1);
            output.vhat  = output.V(:,1:pnew)*output.phi(:,1) + output.V(:,pnew+1:end)*vec(output.phi(:,2:end));
            
            output.z = output.y - output.Y(:,1:pnew)*output.phi(:,1) - output.Y(:,pnew+1:end)*vec(output.phi(:,2:end));
            output.error = output.v - output.vhat;
                                                      
            output.regimes = m+1;
        end
    case 3
        output.gamma = [];
        output.omega = [];
        output.c     = [];
        for m=1:options.size
            % Choose starting values for d, c, gamma.
            [output.d,output.c,output.gamma,output.omega] = ...
                startvalfi(y,q,m,output.c,output.gamma,output.omega,...
                T,p,nQ,options.const,options.trunc,options.Nstart);
            
            psi = setparfi(output.d,output.c,output.gamma,output.omega);
            
            % bounds for d, gamma, and c.
            lb_gamma      = zeros(m,1);
            ub_gamma      = 20*ones(m,1);
            if nQ>1
                lb  = [min_d;-inf*ones(m,1);lb_gamma;-inf*ones(m*nQ,1)];
                ub  = [0.49;inf*ones(m,1);ub_gamma;inf*ones(m*nQ,1)];
                [psi,~,~,output.exitflag_nlsq,output.optimization] = ...
                    fmincon(func,psi,[],[],[],[],lb,ub,cons_func,options_optim,y,q,p,m,T,nQ,options.const,options.trunc);
            else
                lb  = [min_d;repmat(prctile(q,5),m,1);lb_gamma];
                ub  = [0.49;repmat(prctile(q,95),m,1);ub_gamma];
                [psi,~,~,output.exitflag_nlsq,output.optimization] = ...
                    fmincon(func,psi,[],[],[],[],lb,ub,[],options_optim,y,q,p,m,T,nQ,options.const,options.trunc);
            end
                
            [output.d,output.c,output.gamma,output.omega] = getparfi(psi,m,nQ);
            
            output.v = fracfilter(y,output.d,options.trunc);

            output.V = zeros(T-p,pnew*(m+1));
            output.Y = zeros(T-p,pnew*(m+1));
            if options.const == 1
                output.V(:,1) = ones(T-p,1);
                output.Y(:,1) = ones(T-p,1);
            end
            for i=1:p
                output.V(:,i + options.const) = output.v(p-i+1:T-i);
                output.Y(:,i + options.const) = y(p-i+1:T-i);
            end
            output.v = output.v(p+1:end);
            output.y = y(p+1:end);
            output.q = q(p+1:end,:);
            
            output.transition = zeros(T-p,m);
            output.fX = zeros(T-p,m);
            for i = 1:m
                output.transition(:,i) = output.gamma(i)*(output.q*output.omega(:,i)-output.c(i)); 
                output.fX(:,i)         = siglog(output.transition(:,i));
                output.V(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*output.V(:,1:pnew);
                output.Y(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*output.Y(:,1:pnew);
            end
            theta = (output.V'*output.V)\(output.V'*output.v);
            output.phi   = reshape(theta,pnew,m+1);
            output.vhat  = output.V(:,1:pnew)*output.phi(:,1) + output.V(:,pnew+1:end)*vec(output.phi(:,2:end));
            
            output.z = output.y - output.Y(:,1:pnew)*output.phi(:,1) - output.Y(:,pnew+1:end)*vec(output.phi(:,2:end));
            output.error = output.v - output.vhat;
                                    
            output.regimes = m+1;
        end
            
        output.regimes = m+1;
end

output.p = p;
if m>0
    %----------------------------------------------------------------------
    % Impose restrictions on parameter c (ordering)
    %----------------------------------------------------------------------
    if nQ == 1
        output.q = output.q.*stdq;
        output.gamma = output.gamma/stdq;
        output.c     = output.c*stdq;
    end
    [~,index]    = sortrows(output.c);
    output.gamma = output.gamma(index);
    if nQ > 1
        output.omega = output.omega(:,index);
    else
        output.omega = ones(1,m);
    end
    output.c     = output.c(index);
    
    % -------------------------------------------------------------------------
    % Compute standard errors & diagnostic statistics
    % -------------------------------------------------------------------------
    for i = 1:m
        output.transition(:,i) = output.gamma(i)*(output.q*output.omega(:,i)-output.c(i)); 
        output.fX(:,i)         = siglog(output.transition(:,i));
        output.V(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*output.V(:,1:pnew);
        output.Y(:,i*pnew+1:(i+1)*pnew) = repmat(output.fX(:,i),1,pnew).*output.Y(:,1:pnew);
    end
    theta = (output.V'*output.V)\(output.V'*output.v);
    output.phi   = reshape(theta,pnew,m+1);
    output.vhat  = output.V(:,1:pnew)*output.phi(:,1) + output.V(:,pnew+1:end)*vec(output.phi(:,2:end));
           
    output.z = output.y - output.Y(:,1:pnew)*output.phi(:,1) - output.Y(:,pnew+1:end)*vec(output.phi(:,2:end));
    output.error = output.v - output.vhat;
            
    dfX  = dsiglog(output.fX);
                     
    [output.Grad,output.B] = gradgnonlinear(output.V,output.error,output.z,...
        output.q,p,m,nQ,output.phi,output.d,output.c,output.gamma,output.omega,...
        dfX,T,options.trunc,options.const);
            
    output.G     = [output.Grad.phi output.Grad.d output.Grad.c output.Grad.gamma output.Grad.omega];
    
    GG = output.G'*output.G;
    if rank(GG) == size(GG,2)
        output.Sigma = inv(output.G'*output.G);
    else
        output.Sigma = pinv(output.G'*output.G);
    end
    
    % Standard errors
    se = diag(output.Sigma);
    output.phi_se   = reshape(se(1:pnew*(m+1)),pnew,m+1);
    output.d_se     = se(pnew*(m+1)+1);
    output.c_se     = se(pnew*(m+1)+2:pnew*(m+1)+1+m);
    output.gamma_se = se(pnew*(m+1)+2+m:pnew*(m+1)+1+2*m);
    if nQ>1
        output.omega_se = reshape(se(pnew*(m+1)+2+2*m:end),nQ,m);
    end    
          
    % Compute diagnostic statistics
    output.mean     = mean(output.error);       % residual mean
    output.std      = std(output.error);        % residual standard deviation
    output.median   = median(output.error);     % residual median
    output.max      = max(output.error);        % max residual
    output.min      = min(output.error);        % min residual
    output.kurtosis = kurtosis(output.error);   % residual kurtosis
    output.skewness = skewness(output.error);   % residual skewness
    output.R2       = 1 - ...                   % R-squared
        (output.error'*output.error)/((y-mean(y))'*(y-mean(y)));
    
    loglkh = log((output.error'*output.error)/T);
    numpar = length(theta)+length(psi);

    output.AIC  = loglkh + numpar*(2/T);
    output.BIC  = loglkh + numpar*(log(T)/T); 
    output.HQIC = loglkh + numpar*(2*log(log(T))/T);
    
    if options.diagnostics==1
        [~,output.pvalue_jb,output.stat_jb] = ...   % Jarque-Bera test
            jbtest(output.error);   
        [~,output.pvalue_lillie,output.stat_lillie] = ...   % Lilliefors test
            lillietest(output.error); 
        [~,output.pvalue_ad,output.stat_ad] = ...   % AD test
            adtest(output.error); 
        [~,output.pvalue_lb,output.stat_lb] = ...   % lb test
            lbqtest(output.error); 
        [~,output.pvalue_arch,output.stat_arch] = ...   % arch test
            archtest(output.error); 
    end
else
    output.regimes = 1;
end
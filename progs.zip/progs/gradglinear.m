function [G,B] = gradglinear(V,u,z,d,p,T,const,trunc)

aux  = zeros(T-p-trunc,1);
aux2 = zeros(trunc,trunc-1);

G.phi = V;

if (d > 0) 
    for j=1:trunc
        i=0:j-1;
        aux(:,j) = ((((-1)^j)/factorial(j))*sum(1./(d-i))*prod(d-i))*z(trunc-j+1:T-p-j);
        if j > 1
            trunc2 = j-1;
            for k=1:trunc2
                l=0:k-1;
                aux2(j,k) = ((((-1)^k)/factorial(k))*sum(1./(d-l))*prod(d-l))*z(j-k);
            end
        end
    end   
    G.d = [sum(aux2,2);sum(aux,2)];
else
    G.d = zeros(size(u));
end

numpar = p + const + 1; 
aux    = 2.*repmat(u,1,numpar).*[G.phi G.d];

B = aux'*aux/T;
%--------------------------------------------------------------------------
% Estimation of linear AutoRegressive Fractionally Integrated (ARFI) models
%--------------------------------------------------------------------------

% Inputs:
% ------
% y: vector with T observations of the dependent variable
% p: autogressive order
% options: estimation options


function [output_linear, output_nonlinear] = estimation_arfi(y,q,p,options_linear,options_nonlinear)

func = 'msecost';

options_optim = optimset('Display','off','Jacobian','on','MaxFunEvals',1e10,...
    'LargeScale','off','MaxIter',4000,'TolFun',1e-10,...
    'DerivativeCheck','off','FunValCheck', 'off',...
    'TolX',1e-10,'GradObj','on','Hessian','fin-diff-grads',...
    'Algorithm','interior-point','Diagnostics','off','FinDiffType','central',...
    'UseParallel','always','SubproblemAlgorithm','cg');


%--------------------------------------------------------------------------
% Compute the number of observations
%--------------------------------------------------------------------------
T = size(y,1);

%--------------------------------------------------------------------------
% Remove the unconditional mean
%--------------------------------------------------------------------------
ybar = nanmean(y);
if ybar~=0
    y = y - ybar;
end

%--------------------------------------------------------------------------
% Linear Estimation
%--------------------------------------------------------------------------

% Determine the autoregressive order
if isempty(p)==1
    p = pestimation(y,[],T,options_linear.pmax,[],options_linear.const,options_linear.trunc,options_linear.IC);
end

% Grid search over the fractional difference parameter
d_set   = 0.01:0.01:0.489;
d_set   = [0,d_set];
Nd      = length(d_set);
SSE     = zeros(Nd,1);

for j=1:Nd
    v = fracfilter(y,d_set(j),options_linear.trunc);
    if options_linear.const == 1
        V      = zeros(T-p,p+1);
        V(:,1) = ones(T-p,1);
    else
        V = zeros(T-p,p);
    end
    for i=1:p
        V(:,i+options_linear.const) = v(p-i+1:T-i);
    end
    v = v(p+1:end);

    output_linear.phi = (V'*V)\(V'*v);
    output_linear.error = v - V*output_linear.phi;
    
    SSE(j,1) = output_linear.error'*output_linear.error; 
end

% Choose the value for d which minimized the sum of squared errors and use 
% it as initial value for the nonlinear optimization procedure.
j = SSE == min(SSE);

[d, feval]= fmincon(func,d_set(j),[],[],[],[],0,0.49,[],...
        options_optim,y,p,T,options_linear.const,options_linear.trunc);

% Check if the nonlinear estimation procedure has improved over the initial 
% condition.
if feval>SSE(j)/T
    output_linear.d = d_set(j);
else
    output_linear.d = d;
end

% construct filtered series
output_linear.v = fracfilter(y,output_linear.d,options_linear.trunc);

% construct lagged series
if options_linear.const == 1
    output_linear.V      = zeros(T-p,p+1);
    output_linear.Y      = zeros(T-p,p+1);
    output_linear.V(:,1) = ones(T-p,1);
    output_linear.Y(:,1) = ones(T-p,1);
else
    output_linear.V = zeros(T-p,p);
    output_linear.Y = zeros(T-p,p);
end
for i = 1:p
    output_linear.V(:,i+options_linear.const) = output_linear.v(p-i+1:T-i);
    output_linear.Y(:,i+options_linear.const) = y(p-i+1:T-i);
end
output_linear.v = output_linear.v(p+1:end);
output_linear.y = y(p+1:end);

% Linear results
output_linear.phi = (output_linear.V'*output_linear.V)\(output_linear.V'*output_linear.v);
output_linear.vhat  = output_linear.V*output_linear.phi;
output_linear.error = output_linear.v - output_linear.vhat;
output_linear.yhat  = prevfracfilter(output_linear.y,...
    output_linear.d,options_linear.trunc) + output_linear.vhat + ybar;
output_linear.p     = p;

% Compute the gradient
output_linear.z = output_linear.y - output_linear.Y*output_linear.phi;
[output_linear.G,output_linear.B] = gradglinear(output_linear.V,output_linear.error,output_linear.z,...
    output_linear.d,output_linear.p,T,options_linear.const,options_linear.trunc); 
           
% Covariance matrix of the estimated parameters
output_linear.Sigma = inv(output_linear.B)/T;
          
% Standard errors and t-values
output_linear.d_se = sqrt(output_linear.Sigma(1));
output_linear.d_t  = output_linear.d./output_linear.d_se;

aux = diag(output_linear.Sigma);
output_linear.phi_se = sqrt(aux(2:end));
output_linear.phi_t  = output_linear.phi./output_linear.phi_se;

output_linear.ybar = ybar;

% Diagnostics
output_linear.mean     = mean(output_linear.error);
output_linear.std      = std(output_linear.error);
output_linear.median   = median(output_linear.error);
output_linear.max      = max(output_linear.error);
output_linear.min      = min(output_linear.error);
output_linear.kurtosis = kurtosis(output_linear.error);
output_linear.skewness = skewness(output_linear.error);
output_linear.R2       = 1 - (output_linear.error'*output_linear.error)/...
                           ((output_linear.y-mean(output_linear.y))'*(output_linear.y-mean(output_linear.y)));

if options_linear.diagnostics==1
    [~,output_linear.pvalue_jb,output_linear.stat_jb] = ...   % Jarque-Bera test
        jbtest(output_linear.error);   
    [~,output_linear.pvalue_lillie,output_linear.stat_lillie] = ...   % Lilliefors test
        lillietest(output_linear.error); 
    [~,output_linear.pvalue_ad,output_linear.stat_ad] = ...   % AD test
        adtest(output_linear.error); 
    [~,output_linear.pvalue_lb,output_linear.stat_lb] = ...   % lb test
        lbqtest(output_linear.error); 
    [~,output_linear.pvalue_arch,output_linear.stat_arch] = ...   % arch test
        archtest(output_linear.error); 
end 

  
loglkh = log((output_linear.error'*output_linear.error)/T);
numpar = p+1;
            
output_linear.AIC  = loglkh + numpar*(2/T);
output_linear.BIC  = loglkh + numpar*(log(T)/T);
output_linear.HQIC = loglkh + numpar*(2*log(log(T))/T);

output_linear.p = p;
%--------------------------------------------------------------------------
% Nonlinear Estimation
%--------------------------------------------------------------------------
if options_linear.nonlinear==1
    if isempty(p)==1
        p = pestimation(y,q,T,options_nonlinear.pmax,options_nonlinear.index,options_nonlinear.const,options_nonlinear.trunc,options_nonlinear.IC);
    end
    output_nonlinear = mrstarfi(y,q,p,output_linear,options_nonlinear);
else
    output_nonlinear.regimes = 1;
end
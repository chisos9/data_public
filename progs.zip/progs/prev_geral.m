function [prev, resid,fi] = prev_geral(AR,MA,dLM,dGLM,cicloGLM,serie,paf,NumResid);

% Faz previsao "paf" passos `a frente de "serie" segundo um modelo de Gegenbauer,
% onde "AR" e "MA" sao polinomios autorregressivo e medias moveis, respectivamente
% (formato filter), "dLM" e� o grau de diferenciacao (fracionaria), e "dGLM" e� o
% parametro d da memoria longa generalizada (sazonal), com periodo "cicloGLM".

% "prev" e� um vetor com as previsoes e "resid" um vetor de tamanho NumResid
% com os residuos do ajuste.

% Leonardo Rocha Souza   20 - 02 - 2003

[a,b] = size(serie);
if a>b
    serie = serie';
end

media = mean(serie); %media = 0;
serie = serie - media;

NumLags = 150; % N�mero de lags a truncar o AR infinito 
if NumLags > (length(serie) - NumResid)
   NumLags = length(serie) - NumResid;
end;

% fractional difference
fiLM = 1;
if dLM ~= 0
   if dLM < 0
       NumLagsLM = 50;
   else
       NumLagsLM = NumLags;
   end;
   ind=1:NumLagsLM;
   fi=-gamma(NumLagsLM+1)./gamma(NumLagsLM+1-dLM).*gamma(ind-dLM)./gamma(-dLM)./gamma(ind+1).*gamma(NumLagsLM+1-dLM-ind)./gamma(NumLagsLM+1-ind);
   fiLM = [fiLM -fi]; clear fi;
end

% generalized long memory
fiGLM = 1;
if dGLM ~= 0
   freq = 2*pi/cicloGLM;
   eta = cos(freq);
   fi0 = 1; fi(1) = -2*dGLM*eta; fi(2) = -2*dGLM*(-dGLM+1)*eta^2 + dGLM;
   for i = 3:2*cicloGLM
       fi(i) = 2*eta*((-dGLM-1)/i + 1)*fi(i-1) - (2*(-dGLM-1)/i + 1)*fi(i-2);
   end;
   fiGLM = [fiGLM fi]; clear fi;
end;

% MA
q = length(MA)-1;
MA0 = 1;
if q>0
   raizes = roots(MA);
   for i = 1:q
       MA_aux = 1;
       for j = 1:NumLags
           MA_aux = [MA_aux raizes(i)^j];
       end;
       MA0 = real(conv(MA0,MA_aux));
   end;
end;


fi0 = conv(fiLM,fiGLM);
fi1 = conv(AR,MA0);
fi = conv(fi0,fi1);
Tamfi = length(fi);
Tam = length(serie);
fi = fi(2:min(Tam,Tamfi));
fi=-fi;
NumLags = length(fi);
for i = 1:paf
   auxserie = rot90(rot90(serie));
   auxserie = auxserie(1:NumLags);
   serie(Tam+i) = fi*auxserie';
end;
prev = serie(Tam+1:end) + media;

for i = 1:NumResid
   if length(fi) > Tam-NumResid+i-1
      fi0 = fi(1:Tam-NumResid+i-1);
   else
      fi0 = fi;
   end
   NumLags = length(fi0); 
   auxserie = serie(1:Tam-NumResid+i-1);
   auxserie = rot90(rot90(auxserie));
   auxserie = auxserie(1:NumLags);
   prev_in(Tam-NumResid+i) = fi0*auxserie';
end;
if NumResid > 0
   resid = serie(Tam-NumResid+1:Tam) - prev_in(Tam-NumResid+1:Tam);
else
   resid = [];
end;
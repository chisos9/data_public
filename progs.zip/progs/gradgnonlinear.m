function [G,B] = gradgnonlinear(V,u,z,q,p,m,nQ,phi,d,c,gamma,omega,dfX,T,trunc,const)

pnew = p + const;

aux = zeros(T-p-trunc,1);
aux2 = zeros(trunc,trunc-1);

for j=1:trunc
    i=0:j-1;
    aux(:,j) = ((((-1)^j)/factorial(j))*sum(1./(d-i))*prod(d-i))*z(trunc-j+1:T-p-j);
    if j > 1
        trunc2 = j-1;
        for k=1:trunc2
            l=0:k-1;
            aux2(j,k) = ((((-1)^k)/factorial(k))*sum(1./(d-l))*prod(d-l))*z(j-k);
        end
    end
end

G.d = [sum(aux2,2);sum(aux,2)];

if nQ>1
    G.omega = ones(T-p,m*nQ);
    for i=1:nQ
        G.omega(:,(i-1)*m+1:i*m) = (V(:,1:pnew)*phi(:,2:end)).*...
            (repmat(q(:,i),1,m).*dfX).*repmat(gamma',T-p,1);
    end
else
    G.omega = [];
end

G.c     =  -(V(:,1:pnew)*phi(:,2:end)).*dfX.*repmat(gamma',T-p,1)/T;
G.gamma =  (V(:,1:pnew)*phi(:,2:end)).*dfX.*(q*omega-repmat(c',T-p,1));

G.phi = V;

if nQ>1
    numpar = pnew + (pnew + 2 + nQ)*m + 1;
else
    numpar = pnew + (pnew + 2)*m + 1;
end
aux    = 2.*repmat(u,1,numpar).*[G.phi G.d G.c G.gamma G.omega];

B = aux'*aux/T;
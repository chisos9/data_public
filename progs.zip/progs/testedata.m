
names = strvcat('AA','AXP','BA','BAC','CAT','CSCO','CVX','DD','DIS','GE','HD','HPQ','IBM','INTC','JNJ','JPM','KFT','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','T','UTX','VZ','WMT','XOM');

N = length(names);

for n = 1:N
    data = load(strcat('..\data\',names(n,:),'.txt'));
        
    date = data(:,1);
    if n==7
        aux  = find(date==20011010);
    elseif n==17
        aux  = find(date==20010613);
    else
        aux  = find(date==20000103);
    end
    data = data(aux:end,:);
    date = data(:,1);
        
    r      = 100*data(:,end);
    y      = data(:,1+2);
    logy   = log(y);
        stdret = r./sqrt(y);
        
    T0 = find(date==20051230);       
    T  = size(y,1);
    
    names(n,:)
    [aux T0 T]
end
function [r,h] = gen_arfima(AR,d,MA,sigma,T)

h = exp(arfima(AR,d,MA,sigma,T)');  % conditional variance
e = randn(T,1);                     % conditional errors
r = sqrt(h).*e;                     % returns
function y = invfracfilter(x,d,trunc)

T = size(x,1);

j   = (1:trunc-1)';
psi = [1;gamma(j+d)./(gamma(d)*gamma(j+1))];

z = zeros(T-trunc,trunc);
w = zeros(trunc,trunc);
t0 = trunc+1;
for i=0:trunc-1,
    z(:,i+1) = x(t0-i:T-i);
    w(trunc-i,1:trunc-i) = x(trunc-i:-1:1);
end
y = [w;z]*psi;

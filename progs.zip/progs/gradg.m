function [G,B] = gradg(V,u,q,fX,d,phi,gamma,c,m,p,T,const)

if const == 1
    p = p + 1;
end
aux = zeros(T-p-100,1);

G.phi = V;

G.gamma = ones(T-p,m);
G.c     = ones(T-p,m);
for i=1:m
    G.gamma(:,i) = (x*lambda(:,i)).*(dfX(:,i).*(q-c(i)));
    G.c(:,i)     = -(x*lambda(:,i)).*(gamma(i)*dfX(:,i));
end

trunc = 100;
if const==1
    for j=1:trunc
        i=0:j-1;
        aux(:,j) = ((((-1)^j)/factorial(j))*sum(1./(d-i))*prod(d-i)).*u(trunc-j+1:T-p+1-j);
    end
else
    for j=1:trunc
        i=0:j-1;
        aux(:,j) = ((((-1)^j)/factorial(j))*sum(1./(d-i))*prod(d-i)).*u(trunc-j+1:T-p-j);
    end
end
G.d = [zeros(trunc,1);sum(aux,2)];

numpar = ; 
aux = 2.*repmat(u,1,numpar).*G;

B = aux'*aux/T;
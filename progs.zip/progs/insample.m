options_linear.pmax        = 5;
options_linear.const       = 0;
options_linear.trunc       = 100;
options_linear.index       = 1;
options_linear.nonlinear   = 1;
options_linear.diagnostics = 1;

options_nonlinear.pmax        = 5;
options_nonlinear.const       = 0;
options_nonlinear.trunc       = 100;
options_nonlinear.index       = 1;
options_nonlinear.rob         = 1;
options_nonlinear.sig         = 0.95;
options_nonlinear.size        = 5;
options_nonlinear.Nstart      = 100;
options_nonlinear.C           = 2;
options_nonlinear.diagnostics = 1;

names = char('AA','AXP','BA','BAC','CAT','CSCO','CVX','DD','DIS','GE','HD','HPQ','IBM','INTC','JNJ','JPM','KFT','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','T','UTX','VZ','WMT','XOM');


for n = 1:30;
    disp(n)
    for i=1:5
        data = load(strcat('..\data\',names(n,:),'.txt'));
        date = data(:,1);   
        if n==7
            aux  = find(date==20011010);
        elseif n==17
            aux  = find(date==20010613);
        else
            aux  = find(date==20000103);
        end
        data = data(aux:end,:);
        date = data(:,1);
            
        r      = 100*data(:,end);
        y      = data(:,i+2);
        logy   = log(y);
        stdret = r./sqrt(y);
        T = size(logy,1);
        trend = (2:T)/T;
        trend = trend';
        
        options_linear.IC = 2;
        options_nonlinear.rob = 1;
        options_nonlinear.grow_crit = 1;
        options_nonlinear.IC = 2;
        [output_linear_LM_robust{n,i,1},output_nonlinear_LM_robust{n,i,1}] = estimation_arfi(logy(2:end),r(1:end-1),[],options_linear,options_nonlinear);
        [output_linear_LM_robust{n,i,2},output_nonlinear_LM_robust{n,i,2}] = estimation_arfi(logy(2:end),trend,[],options_linear,options_nonlinear);
        [output_linear_LM_robust{n,i,2},output_nonlinear_LM_robust{n,i,3}] = estimation_arfi(logy(2:end),[trend r(1:end-1)],[],options_linear,options_nonlinear);

        options_nonlinear.rob = 0;
        [output_linear_LM{n,i,1},output_nonlinear_LM{n,i,1}] = estimation_arfi(logy(2:end),r(1:end-1),[],options_linear,options_nonlinear);
        [output_linear_LM{n,i,2},output_nonlinear_LM{n,i,2}] = estimation_arfi(logy(2:end),trend,[],options_linear,options_nonlinear);
        [output_linear_LM{n,i,2},output_nonlinear_LM{n,i,3}] = estimation_arfi(logy(2:end),[trend r(1:end-1)],[],options_linear,options_nonlinear);
        
        options_linear.IC = 2;
        options_nonlinear.grow_crit = 2;
        options_nonlinear.IC = 2;
        [output_linear_BIC{n,i,1},output_nonlinear_BIC{n,i,1}] = estimation_arfi(logy(2:end),r(1:end-1),[],options_linear,options_nonlinear);
        [output_linear_BIC{n,i,2},output_nonlinear_BIC{n,i,2}] = estimation_arfi(logy(2:end),trend,[],options_linear,options_nonlinear);
        [output_linear_BIC{n,i,2},output_nonlinear_BIC{n,i,3}] = estimation_arfi(logy(2:end),[trend r(1:end-1)],[],options_linear,options_nonlinear);

        options_linear.IC = 3;
        options_nonlinear.grow_crit = 2;
        options_nonlinear.IC = 3;
        [output_linear_HQIC{n,i,1},output_nonlinear_LM_HQIC{n,i,1}] = estimation_arfi(logy(2:end),r(1:end-1),[],options_linear,options_nonlinear);
        [output_linear_HQIC{n,i,2},output_nonlinear_LM_HQIC{n,i,2}] = estimation_arfi(logy(2:end),trend,[],options_linear,options_nonlinear);
        [output_linear_HQIC{n,i,2},output_nonlinear_LM_HQIC{n,i,3}] = estimation_arfi(logy(2:end),[trend r(1:end-1)],[],options_linear,options_nonlinear);
    end
end
save results_insample_131119
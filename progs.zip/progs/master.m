%--------------------------------------------------------------------------
% Models with Leverage
%--------------------------------------------------------------------------
MC = 50;

options_linearLM.pmax        = 5;
options_linearLM.const       = 0;
options_linearLM.trunc       = 100;
options_linearLM.index       = 1;
options_linearLM.nonlinear   = 1;
options_linearLM.diagnostics = 0;

options_nonlinearLM.pmax        = 5;
options_nonlinearLM.const       = 0;
options_nonlinearLM.trunc       = 100;
options_nonlinearLM.index       = 1;
options_nonlinearLM.rob         = 1;
options_nonlinearLM.sig         = 0.95;
options_nonlinearLM.size        = 4;
options_nonlinearLM.Nstart      = 100;
options_nonlinearLM.C           = 2;
options_nonlinearLM.diagnostics = 0;
options_nonlinearLM.grow_crit     = 1;

options_linearBIC              = options_linearLM;
options_nonlinearBIC           = options_nonlinearLM;
options_linearBIC.IC           = 2;
options_nonlinearBIC.grow_crit = 2;
options_nonlinearBIC.IC        = 2;

options_linearHQIC              = options_linearLM;
options_nonlinearHQIC           = options_nonlinearLM;
options_linearHQIC.IC           = 3;
options_nonlinearHQIC.grow_crit = 2;
options_nonlinearHQIC.IC        = 3;

p = [];

%matlabpool open 3
p_1_LM_500  = zeros(MC,1);
M_1_LM_500  = zeros(MC,1);
p_2_LM_500  = zeros(MC,1);
M_2_LM_500  = zeros(MC,1);
p_3_LM_500  = zeros(MC,1);
M_3_LM_500  = zeros(MC,1);
p_4_LM_500  = zeros(MC,1);
M_4_LM_500  = zeros(MC,1);
p_5_LM_500  = zeros(MC,1);
M_5_LM_500  = zeros(MC,1);
p_6_LM_500  = zeros(MC,1);
M_6_LM_500  = zeros(MC,1);
p_7_LM_500  = zeros(MC,1);
M_7_LM_500  = zeros(MC,1);
p_8_LM_500  = zeros(MC,1);
M_8_LM_500  = zeros(MC,1);
p_9_LM_500  = zeros(MC,1);
M_9_LM_500  = zeros(MC,1);
p_10_LM_500 = zeros(MC,1);
M_10_LM_500 = zeros(MC,1);
p_11_LM_500 = zeros(MC,1);
M_11_LM_500 = zeros(MC,1);
p_12_LM_500 = zeros(MC,1);
M_12_LM_500 = zeros(MC,1);
p_13_LM_500 = zeros(MC,1);
M_13_LM_500 = zeros(MC,1);
p_14_LM_500 = zeros(MC,1);
M_14_LM_500 = zeros(MC,1);
p_15_LM_500 = zeros(MC,1);
M_15_LM_500 = zeros(MC,1);
p_16_LM_500 = zeros(MC,1);
M_16_LM_500 = zeros(MC,1);
p_17_LM_500 = zeros(MC,1);
M_17_LM_500 = zeros(MC,1);
p_18_LM_500 = zeros(MC,1);
M_18_LM_500 = zeros(MC,1);

p_1_BIC_500  = zeros(MC,1);
M_1_BIC_500  = zeros(MC,1);
p_2_BIC_500  = zeros(MC,1);
M_2_BIC_500  = zeros(MC,1);
p_3_BIC_500  = zeros(MC,1);
M_3_BIC_500  = zeros(MC,1);
p_4_BIC_500  = zeros(MC,1);
M_4_BIC_500  = zeros(MC,1);
p_5_BIC_500  = zeros(MC,1);
M_5_BIC_500  = zeros(MC,1);
p_6_BIC_500  = zeros(MC,1);
M_6_BIC_500  = zeros(MC,1);
p_7_BIC_500  = zeros(MC,1);
M_7_BIC_500  = zeros(MC,1);
p_8_BIC_500  = zeros(MC,1);
M_8_BIC_500  = zeros(MC,1);
p_9_BIC_500  = zeros(MC,1);
M_9_BIC_500  = zeros(MC,1);
p_10_BIC_500 = zeros(MC,1);
M_10_BIC_500 = zeros(MC,1);
p_11_BIC_500 = zeros(MC,1);
M_11_BIC_500 = zeros(MC,1);
p_12_BIC_500 = zeros(MC,1);
M_12_BIC_500 = zeros(MC,1);
p_13_BIC_500 = zeros(MC,1);
M_13_BIC_500 = zeros(MC,1);
p_14_BIC_500 = zeros(MC,1);
M_14_BIC_500 = zeros(MC,1);
p_15_BIC_500 = zeros(MC,1);
M_15_BIC_500 = zeros(MC,1);
p_16_BIC_500 = zeros(MC,1);
M_16_BIC_500 = zeros(MC,1);
p_17_BIC_500 = zeros(MC,1);
M_17_BIC_500 = zeros(MC,1);
p_18_BIC_500 = zeros(MC,1);
M_18_BIC_500 = zeros(MC,1);

p_1_HQIC_500  = zeros(MC,1);
M_1_HQIC_500  = zeros(MC,1);
p_2_HQIC_500  = zeros(MC,1);
M_2_HQIC_500  = zeros(MC,1);
p_3_HQIC_500  = zeros(MC,1);
M_3_HQIC_500  = zeros(MC,1);
p_4_HQIC_500  = zeros(MC,1);
M_4_HQIC_500  = zeros(MC,1);
p_5_HQIC_500  = zeros(MC,1);
M_5_HQIC_500  = zeros(MC,1);
p_6_HQIC_500  = zeros(MC,1);
M_6_HQIC_500  = zeros(MC,1);
p_7_HQIC_500  = zeros(MC,1);
M_7_HQIC_500  = zeros(MC,1);
p_8_HQIC_500  = zeros(MC,1);
M_8_HQIC_500  = zeros(MC,1);
p_9_HQIC_500  = zeros(MC,1);
M_9_HQIC_500  = zeros(MC,1);
p_10_HQIC_500 = zeros(MC,1);
M_10_HQIC_500 = zeros(MC,1);
p_11_HQIC_500 = zeros(MC,1);
M_11_HQIC_500 = zeros(MC,1);
p_12_HQIC_500 = zeros(MC,1);
M_12_HQIC_500 = zeros(MC,1);
p_13_HQIC_500 = zeros(MC,1);
M_13_HQIC_500 = zeros(MC,1);
p_14_HQIC_500 = zeros(MC,1);
M_14_HQIC_500 = zeros(MC,1);
p_15_HQIC_500 = zeros(MC,1);
M_15_HQIC_500 = zeros(MC,1);
p_16_HQIC_500 = zeros(MC,1);
M_16_HQIC_500 = zeros(MC,1);
p_17_HQIC_500 = zeros(MC,1);
M_17_HQIC_500 = zeros(MC,1);
p_18_HQIC_500 = zeros(MC,1);
M_18_HQIC_500 = zeros(MC,1);
 
p_1_LM_1000  = zeros(MC,1);
M_1_LM_1000  = zeros(MC,1);
p_2_LM_1000  = zeros(MC,1);
M_2_LM_1000  = zeros(MC,1);
p_3_LM_1000  = zeros(MC,1);
M_3_LM_1000  = zeros(MC,1);
p_4_LM_1000  = zeros(MC,1);
M_4_LM_1000  = zeros(MC,1);
p_5_LM_1000  = zeros(MC,1);
M_5_LM_1000  = zeros(MC,1);
p_6_LM_1000  = zeros(MC,1);
M_6_LM_1000  = zeros(MC,1);
p_7_LM_1000  = zeros(MC,1);
M_7_LM_1000  = zeros(MC,1);
p_8_LM_1000  = zeros(MC,1);
M_8_LM_1000  = zeros(MC,1);
p_9_LM_1000  = zeros(MC,1);
M_9_LM_1000  = zeros(MC,1);
p_10_LM_1000 = zeros(MC,1);
M_10_LM_1000 = zeros(MC,1);
p_11_LM_1000 = zeros(MC,1);
M_11_LM_1000 = zeros(MC,1);
p_12_LM_1000 = zeros(MC,1);
M_12_LM_1000 = zeros(MC,1);
p_13_LM_1000 = zeros(MC,1);
M_13_LM_1000 = zeros(MC,1);
p_14_LM_1000 = zeros(MC,1);
M_14_LM_1000 = zeros(MC,1);
p_15_LM_1000 = zeros(MC,1);
M_15_LM_1000 = zeros(MC,1);
p_16_LM_1000 = zeros(MC,1);
M_16_LM_1000 = zeros(MC,1);
p_17_LM_1000 = zeros(MC,1);
M_17_LM_1000 = zeros(MC,1);
p_18_LM_1000 = zeros(MC,1);
M_18_LM_1000 = zeros(MC,1);

p_1_BIC_1000  = zeros(MC,1);
M_1_BIC_1000  = zeros(MC,1);
p_2_BIC_1000  = zeros(MC,1);
M_2_BIC_1000  = zeros(MC,1);
p_3_BIC_1000  = zeros(MC,1);
M_3_BIC_1000  = zeros(MC,1);
p_4_BIC_1000  = zeros(MC,1);
M_4_BIC_1000  = zeros(MC,1);
p_5_BIC_1000  = zeros(MC,1);
M_5_BIC_1000  = zeros(MC,1);
p_6_BIC_1000  = zeros(MC,1);
M_6_BIC_1000  = zeros(MC,1);
p_7_BIC_1000  = zeros(MC,1);
M_7_BIC_1000  = zeros(MC,1);
p_8_BIC_1000  = zeros(MC,1);
M_8_BIC_1000  = zeros(MC,1);
p_9_BIC_1000  = zeros(MC,1);
M_9_BIC_1000  = zeros(MC,1);
p_10_BIC_1000 = zeros(MC,1);
M_10_BIC_1000 = zeros(MC,1);
p_11_BIC_1000 = zeros(MC,1);
M_11_BIC_1000 = zeros(MC,1);
p_12_BIC_1000 = zeros(MC,1);
M_12_BIC_1000 = zeros(MC,1);
p_13_BIC_1000 = zeros(MC,1);
M_13_BIC_1000 = zeros(MC,1);
p_14_BIC_1000 = zeros(MC,1);
M_14_BIC_1000 = zeros(MC,1);
p_15_BIC_1000 = zeros(MC,1);
M_15_BIC_1000 = zeros(MC,1);
p_16_BIC_1000 = zeros(MC,1);
M_16_BIC_1000 = zeros(MC,1);
p_17_BIC_1000 = zeros(MC,1);
M_17_BIC_1000 = zeros(MC,1);
p_18_BIC_1000 = zeros(MC,1);
M_18_BIC_1000 = zeros(MC,1);

p_1_HQIC_1000  = zeros(MC,1);
M_1_HQIC_1000  = zeros(MC,1);
p_2_HQIC_1000  = zeros(MC,1);
M_2_HQIC_1000  = zeros(MC,1);
p_3_HQIC_1000  = zeros(MC,1);
M_3_HQIC_1000  = zeros(MC,1);
p_4_HQIC_1000  = zeros(MC,1);
M_4_HQIC_1000  = zeros(MC,1);
p_5_HQIC_1000  = zeros(MC,1);
M_5_HQIC_1000  = zeros(MC,1);
p_6_HQIC_1000  = zeros(MC,1);
M_6_HQIC_1000  = zeros(MC,1);
p_7_HQIC_1000  = zeros(MC,1);
M_7_HQIC_1000  = zeros(MC,1);
p_8_HQIC_1000  = zeros(MC,1);
M_8_HQIC_1000  = zeros(MC,1);
p_9_HQIC_1000  = zeros(MC,1);
M_9_HQIC_1000  = zeros(MC,1);
p_10_HQIC_1000 = zeros(MC,1);
M_10_HQIC_1000 = zeros(MC,1);
p_11_HQIC_1000 = zeros(MC,1);
M_11_HQIC_1000 = zeros(MC,1);
p_12_HQIC_1000 = zeros(MC,1);
M_12_HQIC_1000 = zeros(MC,1);
p_13_HQIC_1000 = zeros(MC,1);
M_13_HQIC_1000 = zeros(MC,1);
p_14_HQIC_1000 = zeros(MC,1);
M_14_HQIC_1000 = zeros(MC,1);
p_15_HQIC_1000 = zeros(MC,1);
M_15_HQIC_1000 = zeros(MC,1);
p_16_HQIC_1000 = zeros(MC,1);
M_16_HQIC_1000 = zeros(MC,1);
p_17_HQIC_1000 = zeros(MC,1);
M_17_HQIC_1000 = zeros(MC,1);
p_18_HQIC_1000 = zeros(MC,1);
M_18_HQIC_1000 = zeros(MC,1);
 
p_1_LM_5000  = zeros(MC,1);
M_1_LM_5000  = zeros(MC,1);
p_2_LM_5000  = zeros(MC,1);
M_2_LM_5000  = zeros(MC,1);
p_3_LM_5000  = zeros(MC,1);
M_3_LM_5000  = zeros(MC,1);
p_4_LM_5000  = zeros(MC,1);
M_4_LM_5000  = zeros(MC,1);
p_5_LM_5000  = zeros(MC,1);
M_5_LM_5000  = zeros(MC,1);
p_6_LM_5000  = zeros(MC,1);
M_6_LM_5000  = zeros(MC,1);
p_7_LM_5000  = zeros(MC,1);
M_7_LM_5000  = zeros(MC,1);
p_8_LM_5000  = zeros(MC,1);
M_8_LM_5000  = zeros(MC,1);
p_9_LM_5000  = zeros(MC,1);
M_9_LM_5000  = zeros(MC,1);
p_10_LM_5000 = zeros(MC,1);
M_10_LM_5000 = zeros(MC,1);
p_11_LM_5000 = zeros(MC,1);
M_11_LM_5000 = zeros(MC,1);
p_12_LM_5000 = zeros(MC,1);
M_12_LM_5000 = zeros(MC,1);
p_13_LM_5000 = zeros(MC,1);
M_13_LM_5000 = zeros(MC,1);
p_14_LM_5000 = zeros(MC,1);
M_14_LM_5000 = zeros(MC,1);
p_15_LM_5000 = zeros(MC,1);
M_15_LM_5000 = zeros(MC,1);
p_16_LM_5000 = zeros(MC,1);
M_16_LM_5000 = zeros(MC,1);
p_17_LM_5000 = zeros(MC,1);
M_17_LM_5000 = zeros(MC,1);
p_18_LM_5000 = zeros(MC,1);
M_18_LM_5000 = zeros(MC,1);

p_1_BIC_5000  = zeros(MC,1);
M_1_BIC_5000  = zeros(MC,1);
p_2_BIC_5000  = zeros(MC,1);
M_2_BIC_5000  = zeros(MC,1);
p_3_BIC_5000  = zeros(MC,1);
M_3_BIC_5000  = zeros(MC,1);
p_4_BIC_5000  = zeros(MC,1);
M_4_BIC_5000  = zeros(MC,1);
p_5_BIC_5000  = zeros(MC,1);
M_5_BIC_5000  = zeros(MC,1);
p_6_BIC_5000  = zeros(MC,1);
M_6_BIC_5000  = zeros(MC,1);
p_7_BIC_5000  = zeros(MC,1);
M_7_BIC_5000  = zeros(MC,1);
p_8_BIC_5000  = zeros(MC,1);
M_8_BIC_5000  = zeros(MC,1);
p_9_BIC_5000  = zeros(MC,1);
M_9_BIC_5000  = zeros(MC,1);
p_10_BIC_5000 = zeros(MC,1);
M_10_BIC_5000 = zeros(MC,1);
p_11_BIC_5000 = zeros(MC,1);
M_11_BIC_5000 = zeros(MC,1);
p_12_BIC_5000 = zeros(MC,1);
M_12_BIC_5000 = zeros(MC,1);
p_13_BIC_5000 = zeros(MC,1);
M_13_BIC_5000 = zeros(MC,1);
p_14_BIC_5000 = zeros(MC,1);
M_14_BIC_5000 = zeros(MC,1);
p_15_BIC_5000 = zeros(MC,1);
M_15_BIC_5000 = zeros(MC,1);
p_16_BIC_5000 = zeros(MC,1);
M_16_BIC_5000 = zeros(MC,1);
p_17_BIC_5000 = zeros(MC,1);
M_17_BIC_5000 = zeros(MC,1);
p_18_BIC_5000 = zeros(MC,1);
M_18_BIC_5000 = zeros(MC,1);

p_1_HQIC_5000  = zeros(MC,1);
M_1_HQIC_5000  = zeros(MC,1);
p_2_HQIC_5000  = zeros(MC,1);
M_2_HQIC_5000  = zeros(MC,1);
p_3_HQIC_5000  = zeros(MC,1);
M_3_HQIC_5000  = zeros(MC,1);
p_4_HQIC_5000  = zeros(MC,1);
M_4_HQIC_5000  = zeros(MC,1);
p_5_HQIC_5000  = zeros(MC,1);
M_5_HQIC_5000  = zeros(MC,1);
p_6_HQIC_5000  = zeros(MC,1);
M_6_HQIC_5000  = zeros(MC,1);
p_7_HQIC_5000  = zeros(MC,1);
M_7_HQIC_5000  = zeros(MC,1);
p_8_HQIC_5000  = zeros(MC,1);
M_8_HQIC_5000  = zeros(MC,1);
p_9_HQIC_5000  = zeros(MC,1);
M_9_HQIC_5000  = zeros(MC,1);
p_10_HQIC_5000 = zeros(MC,1);
M_10_HQIC_5000 = zeros(MC,1);
p_11_HQIC_5000 = zeros(MC,1);
M_11_HQIC_5000 = zeros(MC,1);
p_12_HQIC_5000 = zeros(MC,1);
M_12_HQIC_5000 = zeros(MC,1);
p_13_HQIC_5000 = zeros(MC,1);
M_13_HQIC_5000 = zeros(MC,1);
p_14_HQIC_5000 = zeros(MC,1);
M_14_HQIC_5000 = zeros(MC,1);
p_15_HQIC_5000 = zeros(MC,1);
M_15_HQIC_5000 = zeros(MC,1);
p_16_HQIC_5000 = zeros(MC,1);
M_16_HQIC_5000 = zeros(MC,1);
p_17_HQIC_5000 = zeros(MC,1);
M_17_HQIC_5000 = zeros(MC,1);
p_18_HQIC_5000 = zeros(MC,1);
M_18_HQIC_5000 = zeros(MC,1);

load data_500
T = size(y,1);
trend = (2:T)./T;
trend = trend';
parfor i=1:MC
    % -------------------------
    % Specification by LM tests
    % -------------------------
     
    % short-memory
    [output_linear_1_LM,output_nonlinear_1_LM] = estimation_arfi(y(2:T,i,1),r(1:T-1,i,1),p,options_linearLM,options_nonlinearLM);
    [output_linear_2_LM,output_nonlinear_2_LM] = estimation_arfi(y(2:T,i,2),r(1:T-1,i,2),p,options_linearLM,options_nonlinearLM);
    [output_linear_3_LM,output_nonlinear_3_LM] = estimation_arfi(y(2:T,i,3),r(1:T-1,i,3),p,options_linearLM,options_nonlinearLM);
    [output_linear_4_LM,output_nonlinear_4_LM] = estimation_arfi(y(2:T,i,4),r(1:T-1,i,4),p,options_linearLM,options_nonlinearLM);
    [output_linear_5_LM,output_nonlinear_5_LM] = estimation_arfi(y(2:T,i,5),r(1:T-1,i,5),p,options_linearLM,options_nonlinearLM);
    [output_linear_6_LM,output_nonlinear_6_LM] = estimation_arfi(y(2:T,i,6),r(1:T-1,i,6),p,options_linearLM,options_nonlinearLM);
    [output_linear_7_LM,output_nonlinear_7_LM] = estimation_arfi(y(2:T,i,7),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_8_LM,output_nonlinear_8_LM] = estimation_arfi(y(2:T,i,8),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_9_LM,output_nonlinear_9_LM] = estimation_arfi(y(2:T,i,9),trend,p,options_linearLM,options_nonlinearLM);
    
    [output_linear_1_BIC,output_nonlinear_1_BIC] = estimation_arfi(y(2:T,i,1),r(1:T-1,i,4),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_2_BIC,output_nonlinear_2_BIC] = estimation_arfi(y(2:T,i,2),r(1:T-1,i,5),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_3_BIC,output_nonlinear_3_BIC] = estimation_arfi(y(2:T,i,3),r(1:T-1,i,6),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_4_BIC,output_nonlinear_4_BIC] = estimation_arfi(y(2:T,i,4),r(1:T-1,i,4),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_5_BIC,output_nonlinear_5_BIC] = estimation_arfi(y(2:T,i,5),r(1:T-1,i,5),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_6_BIC,output_nonlinear_6_BIC] = estimation_arfi(y(2:T,i,6),r(1:T-1,i,6),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_7_BIC,output_nonlinear_7_BIC] = estimation_arfi(y(2:T,i,7),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_8_BIC,output_nonlinear_8_BIC] = estimation_arfi(y(2:T,i,8),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_9_BIC,output_nonlinear_9_BIC] = estimation_arfi(y(2:T,i,9),trend,p,options_linearBIC,options_nonlinearBIC);
    
    [output_linear_1_HQIC,output_nonlinear_1_HQIC] = estimation_arfi(y(2:T,i,1),r(1:T-1,i,1),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_2_HQIC,output_nonlinear_2_HQIC] = estimation_arfi(y(2:T,i,2),r(1:T-1,i,2),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_3_HQIC,output_nonlinear_3_HQIC] = estimation_arfi(y(2:T,i,3),r(1:T-1,i,3),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_4_HQIC,output_nonlinear_4_HQIC] = estimation_arfi(y(2:T,i,4),r(1:T-1,i,4),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_5_HQIC,output_nonlinear_5_HQIC] = estimation_arfi(y(2:T,i,5),r(1:T-1,i,5),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_6_HQIC,output_nonlinear_6_HQIC] = estimation_arfi(y(2:T,i,6),r(1:T-1,i,6),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_7_HQIC,output_nonlinear_7_HQIC] = estimation_arfi(y(2:T,i,7),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_8_HQIC,output_nonlinear_8_HQIC] = estimation_arfi(y(2:T,i,8),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_9_HQIC,output_nonlinear_9_HQIC] = estimation_arfi(y(2:T,i,9),trend,p,options_linearHQIC,options_nonlinearHQIC);

    % long-memory
    [output_linear_10_LM,output_nonlinear_10_LM] = estimation_arfi(y(2:T,i,10),r(1:T-1,i,10),p,options_linearLM,options_nonlinearLM);
    [output_linear_11_LM,output_nonlinear_11_LM] = estimation_arfi(y(2:T,i,11),r(1:T-1,i,11),p,options_linearLM,options_nonlinearLM);
    [output_linear_12_LM,output_nonlinear_12_LM] = estimation_arfi(y(2:T,i,12),r(1:T-1,i,12),p,options_linearLM,options_nonlinearLM);
    [output_linear_13_LM,output_nonlinear_13_LM] = estimation_arfi(y(2:T,i,13),r(1:T-1,i,13),p,options_linearLM,options_nonlinearLM);
    [output_linear_14_LM,output_nonlinear_14_LM] = estimation_arfi(y(2:T,i,14),r(1:T-1,i,14),p,options_linearLM,options_nonlinearLM);
    [output_linear_15_LM,output_nonlinear_15_LM] = estimation_arfi(y(2:T,i,15),r(1:T-1,i,15),p,options_linearLM,options_nonlinearLM);
    [output_linear_16_LM,output_nonlinear_16_LM] = estimation_arfi(y(2:T,i,16),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_17_LM,output_nonlinear_17_LM] = estimation_arfi(y(2:T,i,17),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_18_LM,output_nonlinear_18_LM] = estimation_arfi(y(2:T,i,18),trend,p,options_linearLM,options_nonlinearLM);
    
    [output_linear_10_BIC,output_nonlinear_10_BIC] = estimation_arfi(y(2:T,i,10),r(1:T-1,i,10),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_11_BIC,output_nonlinear_11_BIC] = estimation_arfi(y(2:T,i,11),r(1:T-1,i,11),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_12_BIC,output_nonlinear_12_BIC] = estimation_arfi(y(2:T,i,12),r(1:T-1,i,12),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_13_BIC,output_nonlinear_13_BIC] = estimation_arfi(y(2:T,i,13),r(1:T-1,i,13),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_14_BIC,output_nonlinear_14_BIC] = estimation_arfi(y(2:T,i,14),r(1:T-1,i,14),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_15_BIC,output_nonlinear_15_BIC] = estimation_arfi(y(2:T,i,15),r(1:T-1,i,15),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_16_BIC,output_nonlinear_16_BIC] = estimation_arfi(y(2:T,i,16),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_17_BIC,output_nonlinear_17_BIC] = estimation_arfi(y(2:T,i,17),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_18_BIC,output_nonlinear_18_BIC] = estimation_arfi(y(2:T,i,18),trend,p,options_linearBIC,options_nonlinearBIC);
    
    [output_linear_10_HQIC,output_nonlinear_10_HQIC] = estimation_arfi(y(2:T,i,10),r(1:T-1,i,10),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_11_HQIC,output_nonlinear_11_HQIC] = estimation_arfi(y(2:T,i,11),r(1:T-1,i,11),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_12_HQIC,output_nonlinear_12_HQIC] = estimation_arfi(y(2:T,i,12),r(1:T-1,i,12),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_13_HQIC,output_nonlinear_13_HQIC] = estimation_arfi(y(2:T,i,13),r(1:T-1,i,13),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_14_HQIC,output_nonlinear_14_HQIC] = estimation_arfi(y(2:T,i,14),r(1:T-1,i,14),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_15_HQIC,output_nonlinear_15_HQIC] = estimation_arfi(y(2:T,i,15),r(1:T-1,i,15),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_16_HQIC,output_nonlinear_16_HQIC] = estimation_arfi(y(2:T,i,16),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_17_HQIC,output_nonlinear_17_HQIC] = estimation_arfi(y(2:T,i,17),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_18_HQIC,output_nonlinear_18_HQIC] = estimation_arfi(y(2:T,i,18),trend,p,options_linearHQIC,options_nonlinearHQIC);
    
    if output_nonlinear_1_LM.regimes==1
        p_1_LM_500(i,1) = output_linear_1_LM.p;
        M_1_LM_500(i,1) = 1;
    else
        p_1_LM_500(i,1) = output_nonlinear_1_LM.p;
        M_1_LM_500(i,1) = output_nonlinear_1_LM.regimes;
    end
    
    if output_nonlinear_2_LM.regimes==1
        p_2_LM_500(i,1) = output_linear_2_LM.p;
        M_2_LM_500(i,1) = 1;
    else
        p_2_LM_500(i,1) = output_nonlinear_13_LM.p;
        M_2_LM_500(i,1) = output_nonlinear_13_LM.regimes;
    end
    
    if output_nonlinear_3_LM.regimes==1
        p_3_LM_500(i,1) = output_linear_3_LM.p;
        M_3_LM_500(i,1) = 1;
    else
        p_3_LM_500(i,1) = output_nonlinear_3_LM.p;
        M_3_LM_500(i,1) = output_nonlinear_3_LM.regimes;
    end
    
    if output_nonlinear_4_LM.regimes==1
        p_4_LM_500(i,1) = output_linear_4_LM.p;
        M_4_LM_500(i,1) = 1;
    else
        p_4_LM_500(i,1) = output_nonlinear_4_LM.p;
        M_4_LM_500(i,1) = output_nonlinear_4_LM.regimes;
    end
    
    if output_nonlinear_5_LM.regimes==1
        p_5_LM_500(i,1) = output_linear_5_LM.p;
        M_5_LM_500(i,1) = 1;
    else
        p_5_LM_500(i,1) = output_nonlinear_5_LM.p;
        M_5_LM_500(i,1) = output_nonlinear_5_LM.regimes;
    end
    
    if output_nonlinear_6_LM.regimes==1
        p_6_LM_500(i,1) = output_linear_6_LM.p;
        M_6_LM_500(i,1) = 1;
    else
        p_6_LM_500(i,1) = output_nonlinear_6_LM.p;
        M_6_LM_500(i,1) = output_nonlinear_6_LM.regimes;
    end
    
    if output_nonlinear_7_LM.regimes==1
        p_7_LM_500(i,1) = output_linear_7_LM.p;
        M_7_LM_500(i,1) = 1;
    else
        p_7_LM_500(i,1) = output_nonlinear_7_LM.p;
        M_7_LM_500(i,1) = output_nonlinear_7_LM.regimes;
    end
    
    if output_nonlinear_8_LM.regimes==1
        p_8_LM_500(i,1) = output_linear_8_LM.p;
        M_8_LM_500(i,1) = 1;
    else
        p_8_LM_500(i,1) = output_nonlinear_8_LM.p;
        M_8_LM_500(i,1) = output_nonlinear_8_LM.regimes;
    end
    
    if output_nonlinear_9_LM.regimes==1
        p_9_LM_500(i,1) = output_linear_9_LM.p;
        M_9_LM_500(i,1) = 1;
    else
        p_9_LM_500(i,1) = output_nonlinear_9_LM.p;
        M_9_LM_500(i,1) = output_nonlinear_9_LM.regimes;
    end
    
    if output_nonlinear_10_LM.regimes==1
        p_10_LM_500(i,1) = output_linear_10_LM.p;
        M_10_LM_500(i,1) = 1;
    else
        p_10_LM_500(i,1) = output_nonlinear_10_LM.p;
        M_10_LM_500(i,1) = output_nonlinear_10_LM.regimes;
    end

    if output_nonlinear_11_LM.regimes==1
        p_11_LM_500(i,1) = output_linear_11_LM.p;
        M_11_LM_500(i,1) = 1;
    else
        p_11_LM_500(i,1) = output_nonlinear_11_LM.p;
        M_11_LM_500(i,1) = output_nonlinear_11_LM.regimes;
    end
    
    if output_nonlinear_12_LM.regimes==1
        p_12_LM_500(i,1) = output_linear_12_LM.p;
        M_12_LM_500(i,1) = 1;
    else
        p_12_LM_500(i,1) = output_nonlinear_12_LM.p;
        M_12_LM_500(i,1) = output_nonlinear_12_LM.regimes;
    end
    
    if output_nonlinear_13_LM.regimes==1
        p_13_LM_500(i,1) = output_linear_13_LM.p;
        M_13_LM_500(i,1) = 1;
    else
        p_13_LM_500(i,1) = output_nonlinear_13_LM.p;
        M_13_LM_500(i,1) = output_nonlinear_13_LM.regimes;
    end
     
    if output_nonlinear_14_LM.regimes==1
        p_14_LM_500(i,1) = output_linear_14_LM.p;
        M_14_LM_500(i,1) = 1;
    else
        p_14_LM_500(i,1) = output_nonlinear_14_LM.p;
        M_14_LM_500(i,1) = output_nonlinear_14_LM.regimes;
    end
     
    if output_nonlinear_15_LM.regimes==1
        p_15_LM_500(i,1) = output_linear_15_LM.p;
        M_15_LM_500(i,1) = 1;
    else
        p_15_LM_500(i,1) = output_nonlinear_15_LM.p;
        M_15_LM_500(i,1) = output_nonlinear_15_LM.regimes;
    end
    
    if output_nonlinear_16_LM.regimes==1
        p_16_LM_500(i,1) = output_linear_16_LM.p;
        M_16_LM_500(i,1) = 1;
    else
        p_16_LM_500(i,1) = output_nonlinear_16_LM.p;
        M_16_LM_500(i,1) = output_nonlinear_16_LM.regimes;
    end
    
    if output_nonlinear_17_LM.regimes==1
        p_17_LM_500(i,1) = output_linear_17_LM.p;
        M_17_LM_500(i,1) = 1;
    else
        p_17_LM_500(i,1) = output_nonlinear_17_LM.p;
        M_17_LM_500(i,1) = output_nonlinear_17_LM.regimes;
    end
    
    if output_nonlinear_18_LM.regimes==1
        p_18_LM_500(i,1) = output_linear_18_LM.p;
        M_18_LM_500(i,1) = 1;
    else
        p_18_LM_500(i,1) = output_nonlinear_18_LM.p;
        M_18_LM_500(i,1) = output_nonlinear_18_LM.regimes;
    end
    
    if output_nonlinear_1_BIC.regimes==1
        p_1_BIC_500(i,1) = output_linear_1_BIC.p;
        M_1_BIC_500(i,1) = 1;
    else
        p_1_BIC_500(i,1) = output_nonlinear_1_BIC.p;
        M_1_BIC_500(i,1) = output_nonlinear_1_BIC.regimes;
    end
    
    if output_nonlinear_2_BIC.regimes==1
        p_2_BIC_500(i,1) = output_linear_2_BIC.p;
        M_2_BIC_500(i,1) = 1;
    else
        p_2_BIC_500(i,1) = output_nonlinear_13_BIC.p;
        M_2_BIC_500(i,1) = output_nonlinear_13_BIC.regimes;
    end
    
    if output_nonlinear_3_BIC.regimes==1
        p_3_BIC_500(i,1) = output_linear_3_BIC.p;
        M_3_BIC_500(i,1) = 1;
    else
        p_3_BIC_500(i,1) = output_nonlinear_3_BIC.p;
        M_3_BIC_500(i,1) = output_nonlinear_3_BIC.regimes;
    end
    
    if output_nonlinear_4_BIC.regimes==1
        p_4_BIC_500(i,1) = output_linear_4_BIC.p;
        M_4_BIC_500(i,1) = 1;
    else
        p_4_BIC_500(i,1) = output_nonlinear_4_BIC.p;
        M_4_BIC_500(i,1) = output_nonlinear_4_BIC.regimes;
    end
    
    if output_nonlinear_5_BIC.regimes==1
        p_5_BIC_500(i,1) = output_linear_5_BIC.p;
        M_5_BIC_500(i,1) = 1;
    else
        p_5_BIC_500(i,1) = output_nonlinear_5_BIC.p;
        M_5_BIC_500(i,1) = output_nonlinear_5_BIC.regimes;
    end
    
    if output_nonlinear_6_BIC.regimes==1
        p_6_BIC_500(i,1) = output_linear_6_BIC.p;
        M_6_BIC_500(i,1) = 1;
    else
        p_6_BIC_500(i,1) = output_nonlinear_6_BIC.p;
        M_6_BIC_500(i,1) = output_nonlinear_6_BIC.regimes;
    end
    
    if output_nonlinear_7_BIC.regimes==1
        p_7_BIC_500(i,1) = output_linear_7_BIC.p;
        M_7_BIC_500(i,1) = 1;
    else
        p_7_BIC_500(i,1) = output_nonlinear_7_BIC.p;
        M_7_BIC_500(i,1) = output_nonlinear_7_BIC.regimes;
    end
    
    if output_nonlinear_8_BIC.regimes==1
        p_8_BIC_500(i,1) = output_linear_8_BIC.p;
        M_8_BIC_500(i,1) = 1;
    else
        p_8_BIC_500(i,1) = output_nonlinear_8_BIC.p;
        M_8_BIC_500(i,1) = output_nonlinear_8_BIC.regimes;
    end
    
    if output_nonlinear_9_BIC.regimes==1
        p_9_BIC_500(i,1) = output_linear_9_BIC.p;
        M_9_BIC_500(i,1) = 1;
    else
        p_9_BIC_500(i,1) = output_nonlinear_9_BIC.p;
        M_9_BIC_500(i,1) = output_nonlinear_9_BIC.regimes;
    end
    
    if output_nonlinear_10_BIC.regimes==1
        p_10_BIC_500(i,1) = output_linear_10_BIC.p;
        M_10_BIC_500(i,1) = 1;
    else
        p_10_BIC_500(i,1) = output_nonlinear_10_BIC.p;
        M_10_BIC_500(i,1) = output_nonlinear_10_BIC.regimes;
    end

    if output_nonlinear_11_BIC.regimes==1
        p_11_BIC_500(i,1) = output_linear_11_BIC.p;
        M_11_BIC_500(i,1) = 1;
    else
        p_11_BIC_500(i,1) = output_nonlinear_11_BIC.p;
        M_11_BIC_500(i,1) = output_nonlinear_11_BIC.regimes;
    end
    
    if output_nonlinear_12_BIC.regimes==1
        p_12_BIC_500(i,1) = output_linear_12_BIC.p;
        M_12_BIC_500(i,1) = 1;
    else
        p_12_BIC_500(i,1) = output_nonlinear_12_BIC.p;
        M_12_BIC_500(i,1) = output_nonlinear_12_BIC.regimes;
    end
    
    if output_nonlinear_13_BIC.regimes==1
        p_13_BIC_500(i,1) = output_linear_13_BIC.p;
        M_13_BIC_500(i,1) = 1;
    else
        p_13_BIC_500(i,1) = output_nonlinear_13_BIC.p;
        M_13_BIC_500(i,1) = output_nonlinear_13_BIC.regimes;
    end
     
    if output_nonlinear_14_BIC.regimes==1
        p_14_BIC_500(i,1) = output_linear_14_BIC.p;
        M_14_BIC_500(i,1) = 1;
    else
        p_14_BIC_500(i,1) = output_nonlinear_14_BIC.p;
        M_14_BIC_500(i,1) = output_nonlinear_14_BIC.regimes;
    end
     
    if output_nonlinear_15_BIC.regimes==1
        p_15_BIC_500(i,1) = output_linear_15_BIC.p;
        M_15_BIC_500(i,1) = 1;
    else
        p_15_BIC_500(i,1) = output_nonlinear_15_BIC.p;
        M_15_BIC_500(i,1) = output_nonlinear_15_BIC.regimes;
    end
    
    if output_nonlinear_16_BIC.regimes==1
        p_16_BIC_500(i,1) = output_linear_16_BIC.p;
        M_16_BIC_500(i,1) = 1;
    else
        p_16_BIC_500(i,1) = output_nonlinear_16_BIC.p;
        M_16_BIC_500(i,1) = output_nonlinear_16_BIC.regimes;
    end
    
    if output_nonlinear_17_BIC.regimes==1
        p_17_BIC_500(i,1) = output_linear_17_BIC.p;
        M_17_BIC_500(i,1) = 1;
    else
        p_17_BIC_500(i,1) = output_nonlinear_17_BIC.p;
        M_17_BIC_500(i,1) = output_nonlinear_17_BIC.regimes;
    end
    
    if output_nonlinear_18_BIC.regimes==1
        p_18_BIC_500(i,1) = output_linear_18_BIC.p;
        M_18_BIC_500(i,1) = 1;
    else
        p_18_BIC_500(i,1) = output_nonlinear_18_BIC.p;
        M_18_BIC_500(i,1) = output_nonlinear_18_BIC.regimes;
    end
    
    if output_nonlinear_1_HQIC.regimes==1
        p_1_HQIC_500(i,1) = output_linear_1_HQIC.p;
        M_1_HQIC_500(i,1) = 1;
    else
        p_1_HQIC_500(i,1) = output_nonlinear_1_HQIC.p;
        M_1_HQIC_500(i,1) = output_nonlinear_1_HQIC.regimes;
    end
    
    if output_nonlinear_2_HQIC.regimes==1
        p_2_HQIC_500(i,1) = output_linear_2_HQIC.p;
        M_2_HQIC_500(i,1) = 1;
    else
        p_2_HQIC_500(i,1) = output_nonlinear_13_HQIC.p;
        M_2_HQIC_500(i,1) = output_nonlinear_13_HQIC.regimes;
    end
    
    if output_nonlinear_3_HQIC.regimes==1
        p_3_HQIC_500(i,1) = output_linear_3_HQIC.p;
        M_3_HQIC_500(i,1) = 1;
    else
        p_3_HQIC_500(i,1) = output_nonlinear_3_HQIC.p;
        M_3_HQIC_500(i,1) = output_nonlinear_3_HQIC.regimes;
    end
    
    if output_nonlinear_4_HQIC.regimes==1
        p_4_HQIC_500(i,1) = output_linear_4_HQIC.p;
        M_4_HQIC_500(i,1) = 1;
    else
        p_4_HQIC_500(i,1) = output_nonlinear_4_HQIC.p;
        M_4_HQIC_500(i,1) = output_nonlinear_4_HQIC.regimes;
    end
    
    if output_nonlinear_5_HQIC.regimes==1
        p_5_HQIC_500(i,1) = output_linear_5_HQIC.p;
        M_5_HQIC_500(i,1) = 1;
    else
        p_5_HQIC_500(i,1) = output_nonlinear_5_HQIC.p;
        M_5_HQIC_500(i,1) = output_nonlinear_5_HQIC.regimes;
    end
    
    if output_nonlinear_6_HQIC.regimes==1
        p_6_HQIC_500(i,1) = output_linear_6_HQIC.p;
        M_6_HQIC_500(i,1) = 1;
    else
        p_6_HQIC_500(i,1) = output_nonlinear_6_HQIC.p;
        M_6_HQIC_500(i,1) = output_nonlinear_6_HQIC.regimes;
    end
    
    if output_nonlinear_7_HQIC.regimes==1
        p_7_HQIC_500(i,1) = output_linear_7_HQIC.p;
        M_7_HQIC_500(i,1) = 1;
    else
        p_7_HQIC_500(i,1) = output_nonlinear_7_HQIC.p;
        M_7_HQIC_500(i,1) = output_nonlinear_7_HQIC.regimes;
    end
    
    if output_nonlinear_8_HQIC.regimes==1
        p_8_HQIC_500(i,1) = output_linear_8_HQIC.p;
        M_8_HQIC_500(i,1) = 1;
    else
        p_8_HQIC_500(i,1) = output_nonlinear_8_HQIC.p;
        M_8_HQIC_500(i,1) = output_nonlinear_8_HQIC.regimes;
    end
    
    if output_nonlinear_9_HQIC.regimes==1
        p_9_HQIC_500(i,1) = output_linear_9_HQIC.p;
        M_9_HQIC_500(i,1) = 1;
    else
        p_9_HQIC_500(i,1) = output_nonlinear_9_HQIC.p;
        M_9_HQIC_500(i,1) = output_nonlinear_9_HQIC.regimes;
    end
    
    if output_nonlinear_10_HQIC.regimes==1
        p_10_HQIC_500(i,1) = output_linear_10_HQIC.p;
        M_10_HQIC_500(i,1) = 1;
    else
        p_10_HQIC_500(i,1) = output_nonlinear_10_HQIC.p;
        M_10_HQIC_500(i,1) = output_nonlinear_10_HQIC.regimes;
    end

    if output_nonlinear_11_HQIC.regimes==1
        p_11_HQIC_500(i,1) = output_linear_11_HQIC.p;
        M_11_HQIC_500(i,1) = 1;
    else
        p_11_HQIC_500(i,1) = output_nonlinear_11_HQIC.p;
        M_11_HQIC_500(i,1) = output_nonlinear_11_HQIC.regimes;
    end
    
    if output_nonlinear_12_HQIC.regimes==1
        p_12_HQIC_500(i,1) = output_linear_12_HQIC.p;
        M_12_HQIC_500(i,1) = 1;
    else
        p_12_HQIC_500(i,1) = output_nonlinear_12_HQIC.p;
        M_12_HQIC_500(i,1) = output_nonlinear_12_HQIC.regimes;
    end
    
    if output_nonlinear_13_HQIC.regimes==1
        p_13_HQIC_500(i,1) = output_linear_13_HQIC.p;
        M_13_HQIC_500(i,1) = 1;
    else
        p_13_HQIC_500(i,1) = output_nonlinear_13_HQIC.p;
        M_13_HQIC_500(i,1) = output_nonlinear_13_HQIC.regimes;
    end
     
    if output_nonlinear_14_HQIC.regimes==1
        p_14_HQIC_500(i,1) = output_linear_14_HQIC.p;
        M_14_HQIC_500(i,1) = 1;
    else
        p_14_HQIC_500(i,1) = output_nonlinear_14_HQIC.p;
        M_14_HQIC_500(i,1) = output_nonlinear_14_HQIC.regimes;
    end
     
    if output_nonlinear_15_HQIC.regimes==1
        p_15_HQIC_500(i,1) = output_linear_15_HQIC.p;
        M_15_HQIC_500(i,1) = 1;
    else
        p_15_HQIC_500(i,1) = output_nonlinear_15_HQIC.p;
        M_15_HQIC_500(i,1) = output_nonlinear_15_HQIC.regimes;
    end
    
    if output_nonlinear_16_HQIC.regimes==1
        p_16_HQIC_500(i,1) = output_linear_16_HQIC.p;
        M_16_HQIC_500(i,1) = 1;
    else
        p_16_HQIC_500(i,1) = output_nonlinear_16_HQIC.p;
        M_16_HQIC_500(i,1) = output_nonlinear_16_HQIC.regimes;
    end
    
    if output_nonlinear_17_HQIC.regimes==1
        p_17_HQIC_500(i,1) = output_linear_17_HQIC.p;
        M_17_HQIC_500(i,1) = 1;
    else
        p_17_HQIC_500(i,1) = output_nonlinear_17_HQIC.p;
        M_17_HQIC_500(i,1) = output_nonlinear_17_HQIC.regimes;
    end
    
    if output_nonlinear_18_HQIC.regimes==1
        p_18_HQIC_500(i,1) = output_linear_18_HQIC.p;
        M_18_HQIC_500(i,1) = 1;
    else
        p_18_HQIC_500(i,1) = output_nonlinear_18_HQIC.p;
        M_18_HQIC_500(i,1) = output_nonlinear_18_HQIC.regimes;
    end
end
save results_spec_full

%--------------------------------------------------------------------------
% 1000 observations
%--------------------------------------------------------------------------
load data_1000
T = size(y,1);
trend = (2:T)./T';
parfor i=1:MC
    % -------------------------
    % Specification by LM tests
    % -------------------------
     
    % short-memory
    [output_linear_1_LM,output_nonlinear_1_LM] = estimation_arfi(y(2:T,i,1),r(1:T-1,i,1),p,options_linearLM,options_nonlinearLM);
    [output_linear_2_LM,output_nonlinear_2_LM] = estimation_arfi(y(2:T,i,2),r(1:T-1,i,2),p,options_linearLM,options_nonlinearLM);
    [output_linear_3_LM,output_nonlinear_3_LM] = estimation_arfi(y(2:T,i,3),r(1:T-1,i,3),p,options_linearLM,options_nonlinearLM);
    [output_linear_4_LM,output_nonlinear_4_LM] = estimation_arfi(y(2:T,i,4),r(1:T-1,i,4),p,options_linearLM,options_nonlinearLM);
    [output_linear_5_LM,output_nonlinear_5_LM] = estimation_arfi(y(2:T,i,5),r(1:T-1,i,5),p,options_linearLM,options_nonlinearLM);
    [output_linear_6_LM,output_nonlinear_6_LM] = estimation_arfi(y(2:T,i,6),r(1:T-1,i,6),p,options_linearLM,options_nonlinearLM);
    [output_linear_7_LM,output_nonlinear_7_LM] = estimation_arfi(y(2:T,i,7),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_8_LM,output_nonlinear_8_LM] = estimation_arfi(y(2:T,i,8),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_9_LM,output_nonlinear_9_LM] = estimation_arfi(y(2:T,i,9),trend,p,options_linearLM,options_nonlinearLM);
    
    [output_linear_1_BIC,output_nonlinear_1_BIC] = estimation_arfi(y(2:T,i,1),r(1:T-1,i,1),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_2_BIC,output_nonlinear_2_BIC] = estimation_arfi(y(2:T,i,2),r(1:T-1,i,2),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_3_BIC,output_nonlinear_3_BIC] = estimation_arfi(y(2:T,i,3),r(1:T-1,i,3),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_4_BIC,output_nonlinear_4_BIC] = estimation_arfi(y(2:T,i,4),r(1:T-1,i,4),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_5_BIC,output_nonlinear_5_BIC] = estimation_arfi(y(2:T,i,5),r(1:T-1,i,5),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_6_BIC,output_nonlinear_6_BIC] = estimation_arfi(y(2:T,i,6),r(1:T-1,i,6),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_7_BIC,output_nonlinear_7_BIC] = estimation_arfi(y(2:T,i,7),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_8_BIC,output_nonlinear_8_BIC] = estimation_arfi(y(2:T,i,8),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_9_BIC,output_nonlinear_9_BIC] = estimation_arfi(y(2:T,i,9),trend,p,options_linearBIC,options_nonlinearBIC);
    
    [output_linear_1_HQIC,output_nonlinear_1_HQIC] = estimation_arfi(y(2:T,i,1),r(1:T-1,i,1),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_2_HQIC,output_nonlinear_2_HQIC] = estimation_arfi(y(2:T,i,2),r(1:T-1,i,2),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_3_HQIC,output_nonlinear_3_HQIC] = estimation_arfi(y(2:T,i,3),r(1:T-1,i,3),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_4_HQIC,output_nonlinear_4_HQIC] = estimation_arfi(y(2:T,i,4),r(1:T-1,i,4),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_5_HQIC,output_nonlinear_5_HQIC] = estimation_arfi(y(2:T,i,5),r(1:T-1,i,5),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_6_HQIC,output_nonlinear_6_HQIC] = estimation_arfi(y(2:T,i,6),r(1:T-1,i,6),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_7_HQIC,output_nonlinear_7_HQIC] = estimation_arfi(y(2:T,i,7),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_8_HQIC,output_nonlinear_8_HQIC] = estimation_arfi(y(2:T,i,8),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_9_HQIC,output_nonlinear_9_HQIC] = estimation_arfi(y(2:T,i,9),trend,p,options_linearHQIC,options_nonlinearHQIC);

    % long-memory
    [output_linear_10_LM,output_nonlinear_10_LM] = estimation_arfi(y(2:T,i,10),r(1:T-1,i,10),p,options_linearLM,options_nonlinearLM);
    [output_linear_11_LM,output_nonlinear_11_LM] = estimation_arfi(y(2:T,i,11),r(1:T-1,i,11),p,options_linearLM,options_nonlinearLM);
    [output_linear_12_LM,output_nonlinear_12_LM] = estimation_arfi(y(2:T,i,12),r(1:T-1,i,12),p,options_linearLM,options_nonlinearLM);
    [output_linear_13_LM,output_nonlinear_13_LM] = estimation_arfi(y(2:T,i,13),r(1:T-1,i,13),p,options_linearLM,options_nonlinearLM);
    [output_linear_14_LM,output_nonlinear_14_LM] = estimation_arfi(y(2:T,i,14),r(1:T-1,i,14),p,options_linearLM,options_nonlinearLM);
    [output_linear_15_LM,output_nonlinear_15_LM] = estimation_arfi(y(2:T,i,15),r(1:T-1,i,15),p,options_linearLM,options_nonlinearLM);
    [output_linear_16_LM,output_nonlinear_16_LM] = estimation_arfi(y(2:T,i,16),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_17_LM,output_nonlinear_17_LM] = estimation_arfi(y(2:T,i,17),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_18_LM,output_nonlinear_18_LM] = estimation_arfi(y(2:T,i,18),trend,p,options_linearLM,options_nonlinearLM);
    
    [output_linear_10_BIC,output_nonlinear_10_BIC] = estimation_arfi(y(2:T,i,10),r(1:T-1,i,10),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_11_BIC,output_nonlinear_11_BIC] = estimation_arfi(y(2:T,i,11),r(1:T-1,i,11),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_12_BIC,output_nonlinear_12_BIC] = estimation_arfi(y(2:T,i,12),r(1:T-1,i,12),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_13_BIC,output_nonlinear_13_BIC] = estimation_arfi(y(2:T,i,13),r(1:T-1,i,13),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_14_BIC,output_nonlinear_14_BIC] = estimation_arfi(y(2:T,i,14),r(1:T-1,i,14),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_15_BIC,output_nonlinear_15_BIC] = estimation_arfi(y(2:T,i,15),r(1:T-1,i,15),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_16_BIC,output_nonlinear_16_BIC] = estimation_arfi(y(2:T,i,16),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_17_BIC,output_nonlinear_17_BIC] = estimation_arfi(y(2:T,i,17),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_18_BIC,output_nonlinear_18_BIC] = estimation_arfi(y(2:T,i,18),trend,p,options_linearBIC,options_nonlinearBIC);
    
    [output_linear_10_HQIC,output_nonlinear_10_HQIC] = estimation_arfi(y(2:T,i,10),r(1:T-1,i,10),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_11_HQIC,output_nonlinear_11_HQIC] = estimation_arfi(y(2:T,i,11),r(1:T-1,i,11),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_12_HQIC,output_nonlinear_12_HQIC] = estimation_arfi(y(2:T,i,12),r(1:T-1,i,12),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_13_HQIC,output_nonlinear_13_HQIC] = estimation_arfi(y(2:T,i,13),r(1:T-1,i,13),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_14_HQIC,output_nonlinear_14_HQIC] = estimation_arfi(y(2:T,i,14),r(1:T-1,i,14),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_15_HQIC,output_nonlinear_15_HQIC] = estimation_arfi(y(2:T,i,15),r(1:T-1,i,15),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_16_HQIC,output_nonlinear_16_HQIC] = estimation_arfi(y(2:T,i,16),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_17_HQIC,output_nonlinear_17_HQIC] = estimation_arfi(y(2:T,i,17),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_18_HQIC,output_nonlinear_18_HQIC] = estimation_arfi(y(2:T,i,18),trend,p,options_linearHQIC,options_nonlinearHQIC);
    
    if output_nonlinear_1_LM.regimes==1
        p_1_LM_1000(i,1) = output_linear_1_LM.p;
        M_1_LM_1000(i,1) = 1;
    else
        p_1_LM_1000(i,1) = output_nonlinear_1_LM.p;
        M_1_LM_1000(i,1) = output_nonlinear_1_LM.regimes;
    end
    
    if output_nonlinear_2_LM.regimes==1
        p_2_LM_1000(i,1) = output_linear_2_LM.p;
        M_2_LM_1000(i,1) = 1;
    else
        p_2_LM_1000(i,1) = output_nonlinear_13_LM.p;
        M_2_LM_1000(i,1) = output_nonlinear_13_LM.regimes;
    end
    
    if output_nonlinear_3_LM.regimes==1
        p_3_LM_1000(i,1) = output_linear_3_LM.p;
        M_3_LM_1000(i,1) = 1;
    else
        p_3_LM_1000(i,1) = output_nonlinear_3_LM.p;
        M_3_LM_1000(i,1) = output_nonlinear_3_LM.regimes;
    end
    
    if output_nonlinear_4_LM.regimes==1
        p_4_LM_1000(i,1) = output_linear_4_LM.p;
        M_4_LM_1000(i,1) = 1;
    else
        p_4_LM_1000(i,1) = output_nonlinear_4_LM.p;
        M_4_LM_1000(i,1) = output_nonlinear_4_LM.regimes;
    end
    
    if output_nonlinear_5_LM.regimes==1
        p_5_LM_1000(i,1) = output_linear_5_LM.p;
        M_5_LM_1000(i,1) = 1;
    else
        p_5_LM_1000(i,1) = output_nonlinear_5_LM.p;
        M_5_LM_1000(i,1) = output_nonlinear_5_LM.regimes;
    end
    
    if output_nonlinear_6_LM.regimes==1
        p_6_LM_1000(i,1) = output_linear_6_LM.p;
        M_6_LM_1000(i,1) = 1;
    else
        p_6_LM_1000(i,1) = output_nonlinear_6_LM.p;
        M_6_LM_1000(i,1) = output_nonlinear_6_LM.regimes;
    end
    
    if output_nonlinear_7_LM.regimes==1
        p_7_LM_1000(i,1) = output_linear_7_LM.p;
        M_7_LM_1000(i,1) = 1;
    else
        p_7_LM_1000(i,1) = output_nonlinear_7_LM.p;
        M_7_LM_1000(i,1) = output_nonlinear_7_LM.regimes;
    end
    
    if output_nonlinear_8_LM.regimes==1
        p_8_LM_1000(i,1) = output_linear_8_LM.p;
        M_8_LM_1000(i,1) = 1;
    else
        p_8_LM_1000(i,1) = output_nonlinear_8_LM.p;
        M_8_LM_1000(i,1) = output_nonlinear_8_LM.regimes;
    end
    
    if output_nonlinear_9_LM.regimes==1
        p_9_LM_1000(i,1) = output_linear_9_LM.p;
        M_9_LM_1000(i,1) = 1;
    else
        p_9_LM_1000(i,1) = output_nonlinear_9_LM.p;
        M_9_LM_1000(i,1) = output_nonlinear_9_LM.regimes;
    end
    
    if output_nonlinear_10_LM.regimes==1
        p_10_LM_1000(i,1) = output_linear_10_LM.p;
        M_10_LM_1000(i,1) = 1;
    else
        p_10_LM_1000(i,1) = output_nonlinear_10_LM.p;
        M_10_LM_1000(i,1) = output_nonlinear_10_LM.regimes;
    end

    if output_nonlinear_11_LM.regimes==1
        p_11_LM_1000(i,1) = output_linear_11_LM.p;
        M_11_LM_1000(i,1) = 1;
    else
        p_11_LM_1000(i,1) = output_nonlinear_11_LM.p;
        M_11_LM_1000(i,1) = output_nonlinear_11_LM.regimes;
    end
    
    if output_nonlinear_12_LM.regimes==1
        p_12_LM_1000(i,1) = output_linear_12_LM.p;
        M_12_LM_1000(i,1) = 1;
    else
        p_12_LM_1000(i,1) = output_nonlinear_12_LM.p;
        M_12_LM_1000(i,1) = output_nonlinear_12_LM.regimes;
    end
    
    if output_nonlinear_13_LM.regimes==1
        p_13_LM_1000(i,1) = output_linear_13_LM.p;
        M_13_LM_1000(i,1) = 1;
    else
        p_13_LM_1000(i,1) = output_nonlinear_13_LM.p;
        M_13_LM_1000(i,1) = output_nonlinear_13_LM.regimes;
    end
     
    if output_nonlinear_14_LM.regimes==1
        p_14_LM_1000(i,1) = output_linear_14_LM.p;
        M_14_LM_1000(i,1) = 1;
    else
        p_14_LM_1000(i,1) = output_nonlinear_14_LM.p;
        M_14_LM_1000(i,1) = output_nonlinear_14_LM.regimes;
    end
     
    if output_nonlinear_15_LM.regimes==1
        p_15_LM_1000(i,1) = output_linear_15_LM.p;
        M_15_LM_1000(i,1) = 1;
    else
        p_15_LM_1000(i,1) = output_nonlinear_15_LM.p;
        M_15_LM_1000(i,1) = output_nonlinear_15_LM.regimes;
    end
    
    if output_nonlinear_16_LM.regimes==1
        p_16_LM_1000(i,1) = output_linear_16_LM.p;
        M_16_LM_1000(i,1) = 1;
    else
        p_16_LM_1000(i,1) = output_nonlinear_16_LM.p;
        M_16_LM_1000(i,1) = output_nonlinear_16_LM.regimes;
    end
    
    if output_nonlinear_17_LM.regimes==1
        p_17_LM_1000(i,1) = output_linear_17_LM.p;
        M_17_LM_1000(i,1) = 1;
    else
        p_17_LM_1000(i,1) = output_nonlinear_17_LM.p;
        M_17_LM_1000(i,1) = output_nonlinear_17_LM.regimes;
    end
    
    if output_nonlinear_18_LM.regimes==1
        p_18_LM_1000(i,1) = output_linear_18_LM.p;
        M_18_LM_1000(i,1) = 1;
    else
        p_18_LM_1000(i,1) = output_nonlinear_18_LM.p;
        M_18_LM_1000(i,1) = output_nonlinear_18_LM.regimes;
    end
    
    if output_nonlinear_1_BIC.regimes==1
        p_1_BIC_1000(i,1) = output_linear_1_BIC.p;
        M_1_BIC_1000(i,1) = 1;
    else
        p_1_BIC_1000(i,1) = output_nonlinear_1_BIC.p;
        M_1_BIC_1000(i,1) = output_nonlinear_1_BIC.regimes;
    end
    
    if output_nonlinear_2_BIC.regimes==1
        p_2_BIC_1000(i,1) = output_linear_2_BIC.p;
        M_2_BIC_1000(i,1) = 1;
    else
        p_2_BIC_1000(i,1) = output_nonlinear_13_BIC.p;
        M_2_BIC_1000(i,1) = output_nonlinear_13_BIC.regimes;
    end
    
    if output_nonlinear_3_BIC.regimes==1
        p_3_BIC_1000(i,1) = output_linear_3_BIC.p;
        M_3_BIC_1000(i,1) = 1;
    else
        p_3_BIC_1000(i,1) = output_nonlinear_3_BIC.p;
        M_3_BIC_1000(i,1) = output_nonlinear_3_BIC.regimes;
    end
    
    if output_nonlinear_4_BIC.regimes==1
        p_4_BIC_1000(i,1) = output_linear_4_BIC.p;
        M_4_BIC_1000(i,1) = 1;
    else
        p_4_BIC_1000(i,1) = output_nonlinear_4_BIC.p;
        M_4_BIC_1000(i,1) = output_nonlinear_4_BIC.regimes;
    end
    
    if output_nonlinear_5_BIC.regimes==1
        p_5_BIC_1000(i,1) = output_linear_5_BIC.p;
        M_5_BIC_1000(i,1) = 1;
    else
        p_5_BIC_1000(i,1) = output_nonlinear_5_BIC.p;
        M_5_BIC_1000(i,1) = output_nonlinear_5_BIC.regimes;
    end
    
    if output_nonlinear_6_BIC.regimes==1
        p_6_BIC_1000(i,1) = output_linear_6_BIC.p;
        M_6_BIC_1000(i,1) = 1;
    else
        p_6_BIC_1000(i,1) = output_nonlinear_6_BIC.p;
        M_6_BIC_1000(i,1) = output_nonlinear_6_BIC.regimes;
    end
    
    if output_nonlinear_7_BIC.regimes==1
        p_7_BIC_1000(i,1) = output_linear_7_BIC.p;
        M_7_BIC_1000(i,1) = 1;
    else
        p_7_BIC_1000(i,1) = output_nonlinear_7_BIC.p;
        M_7_BIC_1000(i,1) = output_nonlinear_7_BIC.regimes;
    end
    
    if output_nonlinear_8_BIC.regimes==1
        p_8_BIC_1000(i,1) = output_linear_8_BIC.p;
        M_8_BIC_1000(i,1) = 1;
    else
        p_8_BIC_1000(i,1) = output_nonlinear_8_BIC.p;
        M_8_BIC_1000(i,1) = output_nonlinear_8_BIC.regimes;
    end
    
    if output_nonlinear_9_BIC.regimes==1
        p_9_BIC_1000(i,1) = output_linear_9_BIC.p;
        M_9_BIC_1000(i,1) = 1;
    else
        p_9_BIC_1000(i,1) = output_nonlinear_9_BIC.p;
        M_9_BIC_1000(i,1) = output_nonlinear_9_BIC.regimes;
    end
    
    if output_nonlinear_10_BIC.regimes==1
        p_10_BIC_1000(i,1) = output_linear_10_BIC.p;
        M_10_BIC_1000(i,1) = 1;
    else
        p_10_BIC_1000(i,1) = output_nonlinear_10_BIC.p;
        M_10_BIC_1000(i,1) = output_nonlinear_10_BIC.regimes;
    end

    if output_nonlinear_11_BIC.regimes==1
        p_11_BIC_1000(i,1) = output_linear_11_BIC.p;
        M_11_BIC_1000(i,1) = 1;
    else
        p_11_BIC_1000(i,1) = output_nonlinear_11_BIC.p;
        M_11_BIC_1000(i,1) = output_nonlinear_11_BIC.regimes;
    end
    
    if output_nonlinear_12_BIC.regimes==1
        p_12_BIC_1000(i,1) = output_linear_12_BIC.p;
        M_12_BIC_1000(i,1) = 1;
    else
        p_12_BIC_1000(i,1) = output_nonlinear_12_BIC.p;
        M_12_BIC_1000(i,1) = output_nonlinear_12_BIC.regimes;
    end
    
    if output_nonlinear_13_BIC.regimes==1
        p_13_BIC_1000(i,1) = output_linear_13_BIC.p;
        M_13_BIC_1000(i,1) = 1;
    else
        p_13_BIC_1000(i,1) = output_nonlinear_13_BIC.p;
        M_13_BIC_1000(i,1) = output_nonlinear_13_BIC.regimes;
    end
     
    if output_nonlinear_14_BIC.regimes==1
        p_14_BIC_1000(i,1) = output_linear_14_BIC.p;
        M_14_BIC_1000(i,1) = 1;
    else
        p_14_BIC_1000(i,1) = output_nonlinear_14_BIC.p;
        M_14_BIC_1000(i,1) = output_nonlinear_14_BIC.regimes;
    end
     
    if output_nonlinear_15_BIC.regimes==1
        p_15_BIC_1000(i,1) = output_linear_15_BIC.p;
        M_15_BIC_1000(i,1) = 1;
    else
        p_15_BIC_1000(i,1) = output_nonlinear_15_BIC.p;
        M_15_BIC_1000(i,1) = output_nonlinear_15_BIC.regimes;
    end
    
    if output_nonlinear_16_BIC.regimes==1
        p_16_BIC_1000(i,1) = output_linear_16_BIC.p;
        M_16_BIC_1000(i,1) = 1;
    else
        p_16_BIC_1000(i,1) = output_nonlinear_16_BIC.p;
        M_16_BIC_1000(i,1) = output_nonlinear_16_BIC.regimes;
    end
    
    if output_nonlinear_17_BIC.regimes==1
        p_17_BIC_1000(i,1) = output_linear_17_BIC.p;
        M_17_BIC_1000(i,1) = 1;
    else
        p_17_BIC_1000(i,1) = output_nonlinear_17_BIC.p;
        M_17_BIC_1000(i,1) = output_nonlinear_17_BIC.regimes;
    end
    
    if output_nonlinear_18_BIC.regimes==1
        p_18_BIC_1000(i,1) = output_linear_18_BIC.p;
        M_18_BIC_1000(i,1) = 1;
    else
        p_18_BIC_1000(i,1) = output_nonlinear_18_BIC.p;
        M_18_BIC_1000(i,1) = output_nonlinear_18_BIC.regimes;
    end
    
    if output_nonlinear_1_HQIC.regimes==1
        p_1_HQIC_1000(i,1) = output_linear_1_HQIC.p;
        M_1_HQIC_1000(i,1) = 1;
    else
        p_1_HQIC_1000(i,1) = output_nonlinear_1_HQIC.p;
        M_1_HQIC_1000(i,1) = output_nonlinear_1_HQIC.regimes;
    end
    
    if output_nonlinear_2_HQIC.regimes==1
        p_2_HQIC_1000(i,1) = output_linear_2_HQIC.p;
        M_2_HQIC_1000(i,1) = 1;
    else
        p_2_HQIC_1000(i,1) = output_nonlinear_13_HQIC.p;
        M_2_HQIC_1000(i,1) = output_nonlinear_13_HQIC.regimes;
    end
    
    if output_nonlinear_3_HQIC.regimes==1
        p_3_HQIC_1000(i,1) = output_linear_3_HQIC.p;
        M_3_HQIC_1000(i,1) = 1;
    else
        p_3_HQIC_1000(i,1) = output_nonlinear_3_HQIC.p;
        M_3_HQIC_1000(i,1) = output_nonlinear_3_HQIC.regimes;
    end
    
    if output_nonlinear_4_HQIC.regimes==1
        p_4_HQIC_1000(i,1) = output_linear_4_HQIC.p;
        M_4_HQIC_1000(i,1) = 1;
    else
        p_4_HQIC_1000(i,1) = output_nonlinear_4_HQIC.p;
        M_4_HQIC_1000(i,1) = output_nonlinear_4_HQIC.regimes;
    end
    
    if output_nonlinear_5_HQIC.regimes==1
        p_5_HQIC_1000(i,1) = output_linear_5_HQIC.p;
        M_5_HQIC_1000(i,1) = 1;
    else
        p_5_HQIC_1000(i,1) = output_nonlinear_5_HQIC.p;
        M_5_HQIC_1000(i,1) = output_nonlinear_5_HQIC.regimes;
    end
    
    if output_nonlinear_6_HQIC.regimes==1
        p_6_HQIC_1000(i,1) = output_linear_6_HQIC.p;
        M_6_HQIC_1000(i,1) = 1;
    else
        p_6_HQIC_1000(i,1) = output_nonlinear_6_HQIC.p;
        M_6_HQIC_1000(i,1) = output_nonlinear_6_HQIC.regimes;
    end
    
    if output_nonlinear_7_HQIC.regimes==1
        p_7_HQIC_1000(i,1) = output_linear_7_HQIC.p;
        M_7_HQIC_1000(i,1) = 1;
    else
        p_7_HQIC_1000(i,1) = output_nonlinear_7_HQIC.p;
        M_7_HQIC_1000(i,1) = output_nonlinear_7_HQIC.regimes;
    end
    
    if output_nonlinear_8_HQIC.regimes==1
        p_8_HQIC_1000(i,1) = output_linear_8_HQIC.p;
        M_8_HQIC_1000(i,1) = 1;
    else
        p_8_HQIC_1000(i,1) = output_nonlinear_8_HQIC.p;
        M_8_HQIC_1000(i,1) = output_nonlinear_8_HQIC.regimes;
    end
    
    if output_nonlinear_9_HQIC.regimes==1
        p_9_HQIC_1000(i,1) = output_linear_9_HQIC.p;
        M_9_HQIC_1000(i,1) = 1;
    else
        p_9_HQIC_1000(i,1) = output_nonlinear_9_HQIC.p;
        M_9_HQIC_1000(i,1) = output_nonlinear_9_HQIC.regimes;
    end
    
    if output_nonlinear_10_HQIC.regimes==1
        p_10_HQIC_1000(i,1) = output_linear_10_HQIC.p;
        M_10_HQIC_1000(i,1) = 1;
    else
        p_10_HQIC_1000(i,1) = output_nonlinear_10_HQIC.p;
        M_10_HQIC_1000(i,1) = output_nonlinear_10_HQIC.regimes;
    end

    if output_nonlinear_11_HQIC.regimes==1
        p_11_HQIC_1000(i,1) = output_linear_11_HQIC.p;
        M_11_HQIC_1000(i,1) = 1;
    else
        p_11_HQIC_1000(i,1) = output_nonlinear_11_HQIC.p;
        M_11_HQIC_1000(i,1) = output_nonlinear_11_HQIC.regimes;
    end
    
    if output_nonlinear_12_HQIC.regimes==1
        p_12_HQIC_1000(i,1) = output_linear_12_HQIC.p;
        M_12_HQIC_1000(i,1) = 1;
    else
        p_12_HQIC_1000(i,1) = output_nonlinear_12_HQIC.p;
        M_12_HQIC_1000(i,1) = output_nonlinear_12_HQIC.regimes;
    end
    
    if output_nonlinear_13_HQIC.regimes==1
        p_13_HQIC_1000(i,1) = output_linear_13_HQIC.p;
        M_13_HQIC_1000(i,1) = 1;
    else
        p_13_HQIC_1000(i,1) = output_nonlinear_13_HQIC.p;
        M_13_HQIC_1000(i,1) = output_nonlinear_13_HQIC.regimes;
    end
     
    if output_nonlinear_14_HQIC.regimes==1
        p_14_HQIC_1000(i,1) = output_linear_14_HQIC.p;
        M_14_HQIC_1000(i,1) = 1;
    else
        p_14_HQIC_1000(i,1) = output_nonlinear_14_HQIC.p;
        M_14_HQIC_1000(i,1) = output_nonlinear_14_HQIC.regimes;
    end
     
    if output_nonlinear_15_HQIC.regimes==1
        p_15_HQIC_1000(i,1) = output_linear_15_HQIC.p;
        M_15_HQIC_1000(i,1) = 1;
    else
        p_15_HQIC_1000(i,1) = output_nonlinear_15_HQIC.p;
        M_15_HQIC_1000(i,1) = output_nonlinear_15_HQIC.regimes;
    end
    
    if output_nonlinear_16_HQIC.regimes==1
        p_16_HQIC_1000(i,1) = output_linear_16_HQIC.p;
        M_16_HQIC_1000(i,1) = 1;
    else
        p_16_HQIC_1000(i,1) = output_nonlinear_16_HQIC.p;
        M_16_HQIC_1000(i,1) = output_nonlinear_16_HQIC.regimes;
    end
    
    if output_nonlinear_17_HQIC.regimes==1
        p_17_HQIC_1000(i,1) = output_linear_17_HQIC.p;
        M_17_HQIC_1000(i,1) = 1;
    else
        p_17_HQIC_1000(i,1) = output_nonlinear_17_HQIC.p;
        M_17_HQIC_1000(i,1) = output_nonlinear_17_HQIC.regimes;
    end
    
    if output_nonlinear_18_HQIC.regimes==1
        p_18_HQIC_1000(i,1) = output_linear_18_HQIC.p;
        M_18_HQIC_1000(i,1) = 1;
    else
        p_18_HQIC_1000(i,1) = output_nonlinear_18_HQIC.p;
        M_18_HQIC_1000(i,1) = output_nonlinear_18_HQIC.regimes;
    end
end
save results_spec_full

%--------------------------------------------------------------------------
% 5000 observations
%--------------------------------------------------------------------------
load data_5000
T = size(y,1);
trend = (2:T)./T';
parfor i=1:MC
    % -------------------------
    % Specification by LM tests
    % -------------------------
     
    % short-memory
    [output_linear_1_LM,output_nonlinear_1_LM] = estimation_arfi(y(2:T,i,1),r(1:T-1,i,1),p,options_linearLM,options_nonlinearLM);
    [output_linear_2_LM,output_nonlinear_2_LM] = estimation_arfi(y(2:T,i,2),r(1:T-1,i,2),p,options_linearLM,options_nonlinearLM);
    [output_linear_3_LM,output_nonlinear_3_LM] = estimation_arfi(y(2:T,i,3),r(1:T-1,i,3),p,options_linearLM,options_nonlinearLM);
    [output_linear_4_LM,output_nonlinear_4_LM] = estimation_arfi(y(2:T,i,4),r(1:T-1,i,4),p,options_linearLM,options_nonlinearLM);
    [output_linear_5_LM,output_nonlinear_5_LM] = estimation_arfi(y(2:T,i,5),r(1:T-1,i,5),p,options_linearLM,options_nonlinearLM);
    [output_linear_6_LM,output_nonlinear_6_LM] = estimation_arfi(y(2:T,i,6),r(1:T-1,i,6),p,options_linearLM,options_nonlinearLM);
    [output_linear_7_LM,output_nonlinear_7_LM] = estimation_arfi(y(2:T,i,7),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_8_LM,output_nonlinear_8_LM] = estimation_arfi(y(2:T,i,8),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_9_LM,output_nonlinear_9_LM] = estimation_arfi(y(2:T,i,9),trend,p,options_linearLM,options_nonlinearLM);
    
    [output_linear_1_BIC,output_nonlinear_1_BIC] = estimation_arfi(y(2:T,i,1),r(1:T-1,i,1),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_2_BIC,output_nonlinear_2_BIC] = estimation_arfi(y(2:T,i,2),r(1:T-1,i,2),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_3_BIC,output_nonlinear_3_BIC] = estimation_arfi(y(2:T,i,3),r(1:T-1,i,3),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_4_BIC,output_nonlinear_4_BIC] = estimation_arfi(y(2:T,i,4),r(1:T-1,i,4),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_5_BIC,output_nonlinear_5_BIC] = estimation_arfi(y(2:T,i,5),r(1:T-1,i,5),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_6_BIC,output_nonlinear_6_BIC] = estimation_arfi(y(2:T,i,6),r(1:T-1,i,6),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_7_BIC,output_nonlinear_7_BIC] = estimation_arfi(y(2:T,i,7),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_8_BIC,output_nonlinear_8_BIC] = estimation_arfi(y(2:T,i,8),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_9_BIC,output_nonlinear_9_BIC] = estimation_arfi(y(2:T,i,9),trend,p,options_linearBIC,options_nonlinearBIC);
    
    [output_linear_1_HQIC,output_nonlinear_1_HQIC] = estimation_arfi(y(2:T,i,1),r(1:T-1,i,1),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_2_HQIC,output_nonlinear_2_HQIC] = estimation_arfi(y(2:T,i,2),r(1:T-1,i,2),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_3_HQIC,output_nonlinear_3_HQIC] = estimation_arfi(y(2:T,i,3),r(1:T-1,i,3),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_4_HQIC,output_nonlinear_4_HQIC] = estimation_arfi(y(2:T,i,4),r(1:T-1,i,4),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_5_HQIC,output_nonlinear_5_HQIC] = estimation_arfi(y(2:T,i,5),r(1:T-1,i,5),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_6_HQIC,output_nonlinear_6_HQIC] = estimation_arfi(y(2:T,i,6),r(1:T-1,i,6),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_7_HQIC,output_nonlinear_7_HQIC] = estimation_arfi(y(2:T,i,7),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_8_HQIC,output_nonlinear_8_HQIC] = estimation_arfi(y(2:T,i,8),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_9_HQIC,output_nonlinear_9_HQIC] = estimation_arfi(y(2:T,i,9),trend,p,options_linearHQIC,options_nonlinearHQIC);

    % long-memory
    [output_linear_10_LM,output_nonlinear_10_LM] = estimation_arfi(y(2:T,i,10),r(1:T-1,i,10),p,options_linearLM,options_nonlinearLM);
    [output_linear_11_LM,output_nonlinear_11_LM] = estimation_arfi(y(2:T,i,11),r(1:T-1,i,11),p,options_linearLM,options_nonlinearLM);
    [output_linear_12_LM,output_nonlinear_12_LM] = estimation_arfi(y(2:T,i,12),r(1:T-1,i,12),p,options_linearLM,options_nonlinearLM);
    [output_linear_13_LM,output_nonlinear_13_LM] = estimation_arfi(y(2:T,i,13),r(1:T-1,i,13),p,options_linearLM,options_nonlinearLM);
    [output_linear_14_LM,output_nonlinear_14_LM] = estimation_arfi(y(2:T,i,14),r(1:T-1,i,14),p,options_linearLM,options_nonlinearLM);
    [output_linear_15_LM,output_nonlinear_15_LM] = estimation_arfi(y(2:T,i,15),r(1:T-1,i,15),p,options_linearLM,options_nonlinearLM);
    [output_linear_16_LM,output_nonlinear_16_LM] = estimation_arfi(y(2:T,i,16),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_17_LM,output_nonlinear_17_LM] = estimation_arfi(y(2:T,i,17),trend,p,options_linearLM,options_nonlinearLM);
    [output_linear_18_LM,output_nonlinear_18_LM] = estimation_arfi(y(2:T,i,18),trend,p,options_linearLM,options_nonlinearLM);
    
    [output_linear_10_BIC,output_nonlinear_10_BIC] = estimation_arfi(y(2:T,i,10),r(1:T-1,i,10),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_11_BIC,output_nonlinear_11_BIC] = estimation_arfi(y(2:T,i,11),r(1:T-1,i,11),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_12_BIC,output_nonlinear_12_BIC] = estimation_arfi(y(2:T,i,12),r(1:T-1,i,12),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_13_BIC,output_nonlinear_13_BIC] = estimation_arfi(y(2:T,i,13),r(1:T-1,i,13),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_14_BIC,output_nonlinear_14_BIC] = estimation_arfi(y(2:T,i,14),r(1:T-1,i,14),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_15_BIC,output_nonlinear_15_BIC] = estimation_arfi(y(2:T,i,15),r(1:T-1,i,15),p,options_linearBIC,options_nonlinearBIC);
    [output_linear_16_BIC,output_nonlinear_16_BIC] = estimation_arfi(y(2:T,i,16),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_17_BIC,output_nonlinear_17_BIC] = estimation_arfi(y(2:T,i,17),trend,p,options_linearBIC,options_nonlinearBIC);
    [output_linear_18_BIC,output_nonlinear_18_BIC] = estimation_arfi(y(2:T,i,18),trend,p,options_linearBIC,options_nonlinearBIC);
    
    [output_linear_10_HQIC,output_nonlinear_10_HQIC] = estimation_arfi(y(2:T,i,10),r(1:T-1,i,10),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_11_HQIC,output_nonlinear_11_HQIC] = estimation_arfi(y(2:T,i,11),r(1:T-1,i,11),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_12_HQIC,output_nonlinear_12_HQIC] = estimation_arfi(y(2:T,i,12),r(1:T-1,i,12),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_13_HQIC,output_nonlinear_13_HQIC] = estimation_arfi(y(2:T,i,13),r(1:T-1,i,13),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_14_HQIC,output_nonlinear_14_HQIC] = estimation_arfi(y(2:T,i,14),r(1:T-1,i,14),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_15_HQIC,output_nonlinear_15_HQIC] = estimation_arfi(y(2:T,i,15),r(1:T-1,i,15),p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_16_HQIC,output_nonlinear_16_HQIC] = estimation_arfi(y(2:T,i,16),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_17_HQIC,output_nonlinear_17_HQIC] = estimation_arfi(y(2:T,i,17),trend,p,options_linearHQIC,options_nonlinearHQIC);
    [output_linear_18_HQIC,output_nonlinear_18_HQIC] = estimation_arfi(y(2:T,i,18),trend,p,options_linearHQIC,options_nonlinearHQIC);
    
    if output_nonlinear_1_LM.regimes==1
        p_1_LM_5000(i,1) = output_linear_1_LM.p;
        M_1_LM_5000(i,1) = 1;
    else
        p_1_LM_5000(i,1) = output_nonlinear_1_LM.p;
        M_1_LM_5000(i,1) = output_nonlinear_1_LM.regimes;
    end
    
    if output_nonlinear_2_LM.regimes==1
        p_2_LM_5000(i,1) = output_linear_2_LM.p;
        M_2_LM_5000(i,1) = 1;
    else
        p_2_LM_5000(i,1) = output_nonlinear_13_LM.p;
        M_2_LM_5000(i,1) = output_nonlinear_13_LM.regimes;
    end
    
    if output_nonlinear_3_LM.regimes==1
        p_3_LM_5000(i,1) = output_linear_3_LM.p;
        M_3_LM_5000(i,1) = 1;
    else
        p_3_LM_5000(i,1) = output_nonlinear_3_LM.p;
        M_3_LM_5000(i,1) = output_nonlinear_3_LM.regimes;
    end
    
    if output_nonlinear_4_LM.regimes==1
        p_4_LM_5000(i,1) = output_linear_4_LM.p;
        M_4_LM_5000(i,1) = 1;
    else
        p_4_LM_5000(i,1) = output_nonlinear_4_LM.p;
        M_4_LM_5000(i,1) = output_nonlinear_4_LM.regimes;
    end
    
    if output_nonlinear_5_LM.regimes==1
        p_5_LM_5000(i,1) = output_linear_5_LM.p;
        M_5_LM_5000(i,1) = 1;
    else
        p_5_LM_5000(i,1) = output_nonlinear_5_LM.p;
        M_5_LM_5000(i,1) = output_nonlinear_5_LM.regimes;
    end
    
    if output_nonlinear_6_LM.regimes==1
        p_6_LM_5000(i,1) = output_linear_6_LM.p;
        M_6_LM_5000(i,1) = 1;
    else
        p_6_LM_5000(i,1) = output_nonlinear_6_LM.p;
        M_6_LM_5000(i,1) = output_nonlinear_6_LM.regimes;
    end
    
    if output_nonlinear_7_LM.regimes==1
        p_7_LM_5000(i,1) = output_linear_7_LM.p;
        M_7_LM_5000(i,1) = 1;
    else
        p_7_LM_5000(i,1) = output_nonlinear_7_LM.p;
        M_7_LM_5000(i,1) = output_nonlinear_7_LM.regimes;
    end
    
    if output_nonlinear_8_LM.regimes==1
        p_8_LM_5000(i,1) = output_linear_8_LM.p;
        M_8_LM_5000(i,1) = 1;
    else
        p_8_LM_5000(i,1) = output_nonlinear_8_LM.p;
        M_8_LM_5000(i,1) = output_nonlinear_8_LM.regimes;
    end
    
    if output_nonlinear_9_LM.regimes==1
        p_9_LM_5000(i,1) = output_linear_9_LM.p;
        M_9_LM_5000(i,1) = 1;
    else
        p_9_LM_5000(i,1) = output_nonlinear_9_LM.p;
        M_9_LM_5000(i,1) = output_nonlinear_9_LM.regimes;
    end
    
    if output_nonlinear_10_LM.regimes==1
        p_10_LM_5000(i,1) = output_linear_10_LM.p;
        M_10_LM_5000(i,1) = 1;
    else
        p_10_LM_5000(i,1) = output_nonlinear_10_LM.p;
        M_10_LM_5000(i,1) = output_nonlinear_10_LM.regimes;
    end

    if output_nonlinear_11_LM.regimes==1
        p_11_LM_5000(i,1) = output_linear_11_LM.p;
        M_11_LM_5000(i,1) = 1;
    else
        p_11_LM_5000(i,1) = output_nonlinear_11_LM.p;
        M_11_LM_5000(i,1) = output_nonlinear_11_LM.regimes;
    end
    
    if output_nonlinear_12_LM.regimes==1
        p_12_LM_5000(i,1) = output_linear_12_LM.p;
        M_12_LM_5000(i,1) = 1;
    else
        p_12_LM_5000(i,1) = output_nonlinear_12_LM.p;
        M_12_LM_5000(i,1) = output_nonlinear_12_LM.regimes;
    end
    
    if output_nonlinear_13_LM.regimes==1
        p_13_LM_5000(i,1) = output_linear_13_LM.p;
        M_13_LM_5000(i,1) = 1;
    else
        p_13_LM_5000(i,1) = output_nonlinear_13_LM.p;
        M_13_LM_5000(i,1) = output_nonlinear_13_LM.regimes;
    end
     
    if output_nonlinear_14_LM.regimes==1
        p_14_LM_5000(i,1) = output_linear_14_LM.p;
        M_14_LM_5000(i,1) = 1;
    else
        p_14_LM_5000(i,1) = output_nonlinear_14_LM.p;
        M_14_LM_5000(i,1) = output_nonlinear_14_LM.regimes;
    end
     
    if output_nonlinear_15_LM.regimes==1
        p_15_LM_5000(i,1) = output_linear_15_LM.p;
        M_15_LM_5000(i,1) = 1;
    else
        p_15_LM_5000(i,1) = output_nonlinear_15_LM.p;
        M_15_LM_5000(i,1) = output_nonlinear_15_LM.regimes;
    end
    
    if output_nonlinear_16_LM.regimes==1
        p_16_LM_5000(i,1) = output_linear_16_LM.p;
        M_16_LM_5000(i,1) = 1;
    else
        p_16_LM_5000(i,1) = output_nonlinear_16_LM.p;
        M_16_LM_5000(i,1) = output_nonlinear_16_LM.regimes;
    end
    
    if output_nonlinear_17_LM.regimes==1
        p_17_LM_5000(i,1) = output_linear_17_LM.p;
        M_17_LM_5000(i,1) = 1;
    else
        p_17_LM_5000(i,1) = output_nonlinear_17_LM.p;
        M_17_LM_5000(i,1) = output_nonlinear_17_LM.regimes;
    end
    
    if output_nonlinear_18_LM.regimes==1
        p_18_LM_5000(i,1) = output_linear_18_LM.p;
        M_18_LM_5000(i,1) = 1;
    else
        p_18_LM_5000(i,1) = output_nonlinear_18_LM.p;
        M_18_LM_5000(i,1) = output_nonlinear_18_LM.regimes;
    end
    
    if output_nonlinear_1_BIC.regimes==1
        p_1_BIC_5000(i,1) = output_linear_1_BIC.p;
        M_1_BIC_5000(i,1) = 1;
    else
        p_1_BIC_5000(i,1) = output_nonlinear_1_BIC.p;
        M_1_BIC_5000(i,1) = output_nonlinear_1_BIC.regimes;
    end
    
    if output_nonlinear_2_BIC.regimes==1
        p_2_BIC_5000(i,1) = output_linear_2_BIC.p;
        M_2_BIC_5000(i,1) = 1;
    else
        p_2_BIC_5000(i,1) = output_nonlinear_13_BIC.p;
        M_2_BIC_5000(i,1) = output_nonlinear_13_BIC.regimes;
    end
    
    if output_nonlinear_3_BIC.regimes==1
        p_3_BIC_5000(i,1) = output_linear_3_BIC.p;
        M_3_BIC_5000(i,1) = 1;
    else
        p_3_BIC_5000(i,1) = output_nonlinear_3_BIC.p;
        M_3_BIC_5000(i,1) = output_nonlinear_3_BIC.regimes;
    end
    
    if output_nonlinear_4_BIC.regimes==1
        p_4_BIC_5000(i,1) = output_linear_4_BIC.p;
        M_4_BIC_5000(i,1) = 1;
    else
        p_4_BIC_5000(i,1) = output_nonlinear_4_BIC.p;
        M_4_BIC_5000(i,1) = output_nonlinear_4_BIC.regimes;
    end
    
    if output_nonlinear_5_BIC.regimes==1
        p_5_BIC_5000(i,1) = output_linear_5_BIC.p;
        M_5_BIC_5000(i,1) = 1;
    else
        p_5_BIC_5000(i,1) = output_nonlinear_5_BIC.p;
        M_5_BIC_5000(i,1) = output_nonlinear_5_BIC.regimes;
    end
    
    if output_nonlinear_6_BIC.regimes==1
        p_6_BIC_5000(i,1) = output_linear_6_BIC.p;
        M_6_BIC_5000(i,1) = 1;
    else
        p_6_BIC_5000(i,1) = output_nonlinear_6_BIC.p;
        M_6_BIC_5000(i,1) = output_nonlinear_6_BIC.regimes;
    end
    
    if output_nonlinear_7_BIC.regimes==1
        p_7_BIC_5000(i,1) = output_linear_7_BIC.p;
        M_7_BIC_5000(i,1) = 1;
    else
        p_7_BIC_5000(i,1) = output_nonlinear_7_BIC.p;
        M_7_BIC_5000(i,1) = output_nonlinear_7_BIC.regimes;
    end
    
    if output_nonlinear_8_BIC.regimes==1
        p_8_BIC_5000(i,1) = output_linear_8_BIC.p;
        M_8_BIC_5000(i,1) = 1;
    else
        p_8_BIC_5000(i,1) = output_nonlinear_8_BIC.p;
        M_8_BIC_5000(i,1) = output_nonlinear_8_BIC.regimes;
    end
    
    if output_nonlinear_9_BIC.regimes==1
        p_9_BIC_5000(i,1) = output_linear_9_BIC.p;
        M_9_BIC_5000(i,1) = 1;
    else
        p_9_BIC_5000(i,1) = output_nonlinear_9_BIC.p;
        M_9_BIC_5000(i,1) = output_nonlinear_9_BIC.regimes;
    end
    
    if output_nonlinear_10_BIC.regimes==1
        p_10_BIC_5000(i,1) = output_linear_10_BIC.p;
        M_10_BIC_5000(i,1) = 1;
    else
        p_10_BIC_5000(i,1) = output_nonlinear_10_BIC.p;
        M_10_BIC_5000(i,1) = output_nonlinear_10_BIC.regimes;
    end

    if output_nonlinear_11_BIC.regimes==1
        p_11_BIC_5000(i,1) = output_linear_11_BIC.p;
        M_11_BIC_5000(i,1) = 1;
    else
        p_11_BIC_5000(i,1) = output_nonlinear_11_BIC.p;
        M_11_BIC_5000(i,1) = output_nonlinear_11_BIC.regimes;
    end
    
    if output_nonlinear_12_BIC.regimes==1
        p_12_BIC_5000(i,1) = output_linear_12_BIC.p;
        M_12_BIC_5000(i,1) = 1;
    else
        p_12_BIC_5000(i,1) = output_nonlinear_12_BIC.p;
        M_12_BIC_5000(i,1) = output_nonlinear_12_BIC.regimes;
    end
    
    if output_nonlinear_13_BIC.regimes==1
        p_13_BIC_5000(i,1) = output_linear_13_BIC.p;
        M_13_BIC_5000(i,1) = 1;
    else
        p_13_BIC_5000(i,1) = output_nonlinear_13_BIC.p;
        M_13_BIC_5000(i,1) = output_nonlinear_13_BIC.regimes;
    end
     
    if output_nonlinear_14_BIC.regimes==1
        p_14_BIC_5000(i,1) = output_linear_14_BIC.p;
        M_14_BIC_5000(i,1) = 1;
    else
        p_14_BIC_5000(i,1) = output_nonlinear_14_BIC.p;
        M_14_BIC_5000(i,1) = output_nonlinear_14_BIC.regimes;
    end
     
    if output_nonlinear_15_BIC.regimes==1
        p_15_BIC_5000(i,1) = output_linear_15_BIC.p;
        M_15_BIC_5000(i,1) = 1;
    else
        p_15_BIC_5000(i,1) = output_nonlinear_15_BIC.p;
        M_15_BIC_5000(i,1) = output_nonlinear_15_BIC.regimes;
    end
    
    if output_nonlinear_16_BIC.regimes==1
        p_16_BIC_5000(i,1) = output_linear_16_BIC.p;
        M_16_BIC_5000(i,1) = 1;
    else
        p_16_BIC_5000(i,1) = output_nonlinear_16_BIC.p;
        M_16_BIC_5000(i,1) = output_nonlinear_16_BIC.regimes;
    end
    
    if output_nonlinear_17_BIC.regimes==1
        p_17_BIC_5000(i,1) = output_linear_17_BIC.p;
        M_17_BIC_5000(i,1) = 1;
    else
        p_17_BIC_5000(i,1) = output_nonlinear_17_BIC.p;
        M_17_BIC_5000(i,1) = output_nonlinear_17_BIC.regimes;
    end
    
    if output_nonlinear_18_BIC.regimes==1
        p_18_BIC_5000(i,1) = output_linear_18_BIC.p;
        M_18_BIC_5000(i,1) = 1;
    else
        p_18_BIC_5000(i,1) = output_nonlinear_18_BIC.p;
        M_18_BIC_5000(i,1) = output_nonlinear_18_BIC.regimes;
    end
    
    if output_nonlinear_1_HQIC.regimes==1
        p_1_HQIC_5000(i,1) = output_linear_1_HQIC.p;
        M_1_HQIC_5000(i,1) = 1;
    else
        p_1_HQIC_5000(i,1) = output_nonlinear_1_HQIC.p;
        M_1_HQIC_5000(i,1) = output_nonlinear_1_HQIC.regimes;
    end
    
    if output_nonlinear_2_HQIC.regimes==1
        p_2_HQIC_5000(i,1) = output_linear_2_HQIC.p;
        M_2_HQIC_5000(i,1) = 1;
    else
        p_2_HQIC_5000(i,1) = output_nonlinear_13_HQIC.p;
        M_2_HQIC_5000(i,1) = output_nonlinear_13_HQIC.regimes;
    end
    
    if output_nonlinear_3_HQIC.regimes==1
        p_3_HQIC_5000(i,1) = output_linear_3_HQIC.p;
        M_3_HQIC_5000(i,1) = 1;
    else
        p_3_HQIC_5000(i,1) = output_nonlinear_3_HQIC.p;
        M_3_HQIC_5000(i,1) = output_nonlinear_3_HQIC.regimes;
    end
    
    if output_nonlinear_4_HQIC.regimes==1
        p_4_HQIC_5000(i,1) = output_linear_4_HQIC.p;
        M_4_HQIC_5000(i,1) = 1;
    else
        p_4_HQIC_5000(i,1) = output_nonlinear_4_HQIC.p;
        M_4_HQIC_5000(i,1) = output_nonlinear_4_HQIC.regimes;
    end
    
    if output_nonlinear_5_HQIC.regimes==1
        p_5_HQIC_5000(i,1) = output_linear_5_HQIC.p;
        M_5_HQIC_5000(i,1) = 1;
    else
        p_5_HQIC_5000(i,1) = output_nonlinear_5_HQIC.p;
        M_5_HQIC_5000(i,1) = output_nonlinear_5_HQIC.regimes;
    end
    
    if output_nonlinear_6_HQIC.regimes==1
        p_6_HQIC_5000(i,1) = output_linear_6_HQIC.p;
        M_6_HQIC_5000(i,1) = 1;
    else
        p_6_HQIC_5000(i,1) = output_nonlinear_6_HQIC.p;
        M_6_HQIC_5000(i,1) = output_nonlinear_6_HQIC.regimes;
    end
    
    if output_nonlinear_7_HQIC.regimes==1
        p_7_HQIC_5000(i,1) = output_linear_7_HQIC.p;
        M_7_HQIC_5000(i,1) = 1;
    else
        p_7_HQIC_5000(i,1) = output_nonlinear_7_HQIC.p;
        M_7_HQIC_5000(i,1) = output_nonlinear_7_HQIC.regimes;
    end
    
    if output_nonlinear_8_HQIC.regimes==1
        p_8_HQIC_5000(i,1) = output_linear_8_HQIC.p;
        M_8_HQIC_5000(i,1) = 1;
    else
        p_8_HQIC_5000(i,1) = output_nonlinear_8_HQIC.p;
        M_8_HQIC_5000(i,1) = output_nonlinear_8_HQIC.regimes;
    end
    
    if output_nonlinear_9_HQIC.regimes==1
        p_9_HQIC_5000(i,1) = output_linear_9_HQIC.p;
        M_9_HQIC_5000(i,1) = 1;
    else
        p_9_HQIC_5000(i,1) = output_nonlinear_9_HQIC.p;
        M_9_HQIC_5000(i,1) = output_nonlinear_9_HQIC.regimes;
    end
    
    if output_nonlinear_10_HQIC.regimes==1
        p_10_HQIC_5000(i,1) = output_linear_10_HQIC.p;
        M_10_HQIC_5000(i,1) = 1;
    else
        p_10_HQIC_5000(i,1) = output_nonlinear_10_HQIC.p;
        M_10_HQIC_5000(i,1) = output_nonlinear_10_HQIC.regimes;
    end

    if output_nonlinear_11_HQIC.regimes==1
        p_11_HQIC_5000(i,1) = output_linear_11_HQIC.p;
        M_11_HQIC_5000(i,1) = 1;
    else
        p_11_HQIC_5000(i,1) = output_nonlinear_11_HQIC.p;
        M_11_HQIC_5000(i,1) = output_nonlinear_11_HQIC.regimes;
    end
    
    if output_nonlinear_12_HQIC.regimes==1
        p_12_HQIC_5000(i,1) = output_linear_12_HQIC.p;
        M_12_HQIC_5000(i,1) = 1;
    else
        p_12_HQIC_5000(i,1) = output_nonlinear_12_HQIC.p;
        M_12_HQIC_5000(i,1) = output_nonlinear_12_HQIC.regimes;
    end
    
    if output_nonlinear_13_HQIC.regimes==1
        p_13_HQIC_5000(i,1) = output_linear_13_HQIC.p;
        M_13_HQIC_5000(i,1) = 1;
    else
        p_13_HQIC_5000(i,1) = output_nonlinear_13_HQIC.p;
        M_13_HQIC_5000(i,1) = output_nonlinear_13_HQIC.regimes;
    end
     
    if output_nonlinear_14_HQIC.regimes==1
        p_14_HQIC_5000(i,1) = output_linear_14_HQIC.p;
        M_14_HQIC_5000(i,1) = 1;
    else
        p_14_HQIC_5000(i,1) = output_nonlinear_14_HQIC.p;
        M_14_HQIC_5000(i,1) = output_nonlinear_14_HQIC.regimes;
    end
     
    if output_nonlinear_15_HQIC.regimes==1
        p_15_HQIC_5000(i,1) = output_linear_15_HQIC.p;
        M_15_HQIC_5000(i,1) = 1;
    else
        p_15_HQIC_5000(i,1) = output_nonlinear_15_HQIC.p;
        M_15_HQIC_5000(i,1) = output_nonlinear_15_HQIC.regimes;
    end
    
    if output_nonlinear_16_HQIC.regimes==1
        p_16_HQIC_5000(i,1) = output_linear_16_HQIC.p;
        M_16_HQIC_5000(i,1) = 1;
    else
        p_16_HQIC_5000(i,1) = output_nonlinear_16_HQIC.p;
        M_16_HQIC_5000(i,1) = output_nonlinear_16_HQIC.regimes;
    end
    
    if output_nonlinear_17_HQIC.regimes==1
        p_17_HQIC_5000(i,1) = output_linear_17_HQIC.p;
        M_17_HQIC_5000(i,1) = 1;
    else
        p_17_HQIC_5000(i,1) = output_nonlinear_17_HQIC.p;
        M_17_HQIC_5000(i,1) = output_nonlinear_17_HQIC.regimes;
    end
    
    if output_nonlinear_18_HQIC.regimes==1
        p_18_HQIC_5000(i,1) = output_linear_18_HQIC.p;
        M_18_HQIC_5000(i,1) = 1;
    else
        p_18_HQIC_5000(i,1) = output_nonlinear_18_HQIC.p;
        M_18_HQIC_5000(i,1) = output_nonlinear_18_HQIC.regimes;
    end
end
save results_spec_full
 



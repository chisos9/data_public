mcd
dateconverter
load resultsinsample

figure(1)
        hline1=line(A(3:end,1), output_nonlinear_LM_robust{19,4,2}.y ,'LineWidth',1, 'Color', [.6 .6 .6]);
        ax1 = gca;
        set(ax1,'XColor',[1 1 1])
        set(get(ax1,'YLabel'),'String','log(volatility)')
        datetick('x','yyyy')
        ax2 = axes('Position',get(ax1,'Position'),...
           'XAxisLocation','bottom',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k');
        set(get(ax2,'YLabel'),'String','transition function')
        hline2=line(A(3:end,1), output_nonlinear_LM_robust{19,4,2}.fX,'LineWidth',2, 'Color', [0 0 1],'Parent',ax2);
        datetick('x','yyyy')
           
      
parfor i=1:10
    i
end
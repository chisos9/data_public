 function [resid] = filtrafrac(serie,d)
 
 % Filtragem inversa de um ARFIMA(0,d,0)
 % d � a integra��o da s�rie

%         Leonardo Rocha Souza, 21/01/2002


Tam = length(serie);
serie = serie-mean(serie);

fi(1) = d/(1-d);
v(1) = 1;       % v(0), mas n�o h� �ndice 0. Ent�o, �ndice real = �ndice - 1
resid(1) = serie(1);

for j = 1:Tam-1
  fi2 = fi; %fi2=fi./sum(fi);
  fi1 = fi;
  fi(j+1) = d/(j+1-d);
  v(j+1) = v(j)*(1-fi1(j)^2);
  resid(j+1) = (serie(j+1) - rot90(rot90(serie(1:j)))*fi2')/sqrt(v(j+1)); 
  i = 1:j;
  fi(i) = fi1(i) - fi(j+1).*fi1((j+1)*ones(size(i))-i);
end



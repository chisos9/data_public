function d=dsiglog(a)

d = a.*(1-a);

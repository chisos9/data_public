function [f,G] = msecost(d,y,p,T,const,trunc)

% construct filtered series
v = fracfilter(y,d,trunc);

% construct lagged series
V = zeros(T-p,p + const);
Y = zeros(T-p,p + const);
if const == 1
    V(:,1) = ones(T-p,1);
    Y(:,1) = ones(T-p,1);
end
for i=1:p
    V(:,i + const) = v(p-i+1:T-i);
    Y(:,i + const) = y(p-i+1:T-i);
end
v = v(p+1:end);
y = y(p+1:end);

phi  = (V'*V)\(V'*v);
vhat = V*phi;
u    = v - vhat;
z    = y - Y*phi;

f = (u'*u)/T;

aux = zeros(T-p-trunc,1);
aux2 = zeros(trunc,trunc-1);

for j=1:trunc
    i=0:j-1;
    aux(:,j) = ((((-1)^j)/factorial(j))*sum(1./(d-i))*prod(d-i))*z(trunc-j+1:T-p-j);
    if j > 1
        trunc2 = j-1;
        for k=1:trunc2
            l=0:k-1;
            aux2(j,k) = ((((-1)^k)/factorial(k))*sum(1./(d-l))*prod(d-l))*z(j-k);
        end
    end
end

G = 2*u'*[sum(aux2,2);sum(aux,2)]/T;




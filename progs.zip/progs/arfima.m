function ser = arfima(AR,d,MA,sigma,n);

% Syntax: ser = ARFIMA(AR,d,MA,n)

% Generates ARFIMA series of length n, where d is the memory parameter, AR is the autoregressive
% component, in the form [1 -fi1 -fi2 ... -fip], and MA is the moving average component,
% in the form [1 theta1 theta2 ... thetaq].

% To avoid confusion, note that the parameterization is 
% (1-B)^d*Xt = fi1*Xt-1 + ... + fip*Xt-p + theta1*Et-1 + ... + thetaq*Et-q + Et
% You can find elsewhere (e.g., Box & Jenkins) parameterizations in which the parameters thetai (i = 1,...,q)
% are the negative of ours (our thetai = -(their thetai)). In that case (BJ parameterization), replace
% MA = [1 theta1 theta2 ... thetaq] by MA = [1 -theta1 -theta2 ... -thetaq]

% Leonardo Rocha Souza 06-Feb-2002

rfrac = frac32(d,n+100,sigma); % ARFIMA(0,d,0) of size n using the Durbin-Levinson algorithm
                         % 100 observations more are used to discard after the ARMA filtering

ser = filter(MA,AR,rfrac);

ser = ser(101:end); % discard the 100 first observations so that the transient effects of ARMA
                    % filtering is not perceived

load results_forecast_arfima_break
yhat_nonlinear_break = yhat_nonlinear;

load results_forecast_har_cr yhat_har yhat_har_cr
yhat_linear_har = yhat_har;
yhat_nonlinear_har = yhat_har_cr;

load results_forecast_arfima yhat_linear yhat_nonlinear

names = strvcat('AA','AXP','BA','BAC','CAT','CSCO','CVX','DD','DIS','GE','HD','HPQ','IBM','INTC','JNJ','JPM','KFT','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','T','UTX','VZ','WMT','XOM');

N = length(names);
K = 10;
      
for i = 1:5   
    for n = 1:N
        data = load(strcat('..\data\',names(n,:),'.txt'));
        
        date = data(:,1);
        if n==7
            aux  = find(date==20011010);
        elseif n==17
            aux  = find(date==20010613);
        else
            aux  = find(date==20000103);
        end
        data = data(aux:end,:);
        date = data(:,1);
        
        y      = data(:,i+2);
        logy   = log(y);
        
        T0 = find(date==20051230);       
        T  = size(y,1); 
        for k = 1:K
            yout{n,i}(:,k) = logy(T0+k:end-K+k);
            
            if k>1
                yhat_nonlinear{n,i}(:,k) = (yhat_linear{n,i}(:,k) + yhat_nonlinear_break{n,i}(:,k))/2;
            end
            
            e_linear{n,i}(:,k)          = yout{n,i}(:,k) - yhat_linear{n,i}(:,k);
            e_nonlinear{n,i}(:,k)       = yout{n,i}(:,k) - yhat_nonlinear{n,i}(:,k);
            e_nonlinear_break{n,i}(:,k) = yout{n,i}(:,k) - yhat_nonlinear_break{n,i}(:,k);
                
            e_linear_har{n,i}(:,k)          = yout{n,i}(:,k) - yhat_linear_har{n,i}(:,k);
            e_nonlinear_har{n,i}(:,k)       = yout{n,i}(:,k) - yhat_nonlinear_har{n,i}(:,k);
            
            pvalue_linear{n,i}(k,1) = dm(e_linear{n,i}(:,k),e_linear_har{n,i}(:,k),k,0);
            pvalue_linear{n,i}(k,2) = dm(e_nonlinear{n,i}(:,k),e_linear_har{n,i}(:,k),k,0);
            pvalue_linear{n,i}(k,3) = dm(e_nonlinear_break{n,i}(:,k),e_linear_har{n,i}(:,k),k,0);
            
            pvalue_nonlinear{n,i}(k,1) = dm(e_linear{n,i}(:,k),e_nonlinear_har{n,i}(:,k),k,0);
            pvalue_nonlinear{n,i}(k,2) = dm(e_nonlinear{n,i}(:,k),e_nonlinear_har{n,i}(:,k),k,0);
            pvalue_nonlinear{n,i}(k,3) = dm(e_nonlinear_break{n,i}(:,k),e_nonlinear_har{n,i}(:,k),k,0);
            
            LOSSES = [e_linear{n,i}(:,k).^2  e_nonlinear{n,i}(:,k).^2  e_nonlinear_break{n,i}(:,k).^2  e_linear_har{n,i}(:,k).^2  e_nonlinear_har{n,i}(:,k).^2];
            
            [INCLUDEDR{n,i,k},PVALSR{n,i,k},EXCLUDEDR{n,i,k},INCLUDEDSQ{n,i,k},PVALSSQ{n,i,k},EXCLUDEDSQ{n,i,k}] = mcs(LOSSES,0.05,100,10);
            
            aux = [EXCLUDEDR{n,i,k};INCLUDEDR{n,i,k}];
            PVALSR{n,i,k} = sortrows([PVALSR{n,i,k} aux],2);
            PVALSSQ{n,i,k} = sortrows([PVALSSQ{n,i,k} aux],2);
            
            rmse_linear(n,i,k)          = sqrt(mean(e_linear{n,i}(:,k).^2));
            rmse_nonlinear(n,i,k)       = sqrt(mean(e_nonlinear{n,i}(:,k).^2));
            rmse_nonlinear_break(n,i,k) = sqrt(mean(e_nonlinear_break{n,i}(:,k).^2));
                
            rmse_linear_har(n,i,k)          = sqrt(mean(e_linear_har{n,i}(:,k).^2));
            rmse_nonlinear_har(n,i,k)       = sqrt(mean(e_nonlinear_har{n,i}(:,k).^2));
            
            mae_linear(n,i,k)          = mean(abs(e_linear{n,i}(:,k)));
            mae_nonlinear(n,i,k)       = mean(abs(e_nonlinear{n,i}(:,k)));
            mae_nonlinear_break(n,i,k) = mean(abs(e_nonlinear_break{n,i}(:,k)));
                
            mae_linear_har(n,i,k)          = mean(abs(e_linear_har{n,i}(:,k)));
            mae_nonlinear_har(n,i,k)       = mean(abs(e_nonlinear_har{n,i}(:,k)));
              
            medae_linear(n,i,k)          = median(abs(e_linear{n,i}(:,k)));
            medae_nonlinear(n,i,k)       = median(abs(e_nonlinear{n,i}(:,k)));
            medae_nonlinear_break(n,i,k) = median(abs(e_nonlinear_break{n,i}(:,k)));
                
            medae_linear_har(n,i,k)          = median(abs(e_linear_har{n,i}(:,k)));
            medae_nonlinear_har(n,i,k)       = median(abs(e_nonlinear_har{n,i}(:,k)));
        end
    end
    TABLE1{i,1} = [squeeze(rmse_linear(:,i,1)) squeeze(rmse_nonlinear(:,i,1)) squeeze(rmse_nonlinear_break(:,i,1)) squeeze(rmse_linear_har(:,i,1)) squeeze(rmse_nonlinear_har(:,i,1))];
    TABLE1{i,2} = [squeeze(rmse_linear(:,i,5)) squeeze(rmse_nonlinear(:,i,5)) squeeze(rmse_nonlinear_break(:,i,5)) squeeze(rmse_linear_har(:,i,5)) squeeze(rmse_nonlinear_har(:,i,5))];
    TABLE1{i,3} = [squeeze(rmse_linear(:,i,10)) squeeze(rmse_nonlinear(:,i,10)) squeeze(rmse_nonlinear_break(:,i,10)) squeeze(rmse_linear_har(:,i,10)) squeeze(rmse_nonlinear_har(:,i,10))];
    
    TABLE2{i,1} = [squeeze(mae_linear(:,i,1)) squeeze(mae_nonlinear(:,i,1)) squeeze(mae_nonlinear_break(:,i,1)) squeeze(mae_linear_har(:,i,1)) squeeze(mae_nonlinear_har(:,i,1))];
    TABLE2{i,2} = [squeeze(mae_linear(:,i,5)) squeeze(mae_nonlinear(:,i,5)) squeeze(mae_nonlinear_break(:,i,5)) squeeze(mae_linear_har(:,i,5)) squeeze(mae_nonlinear_har(:,i,5))];
    TABLE2{i,3} = [squeeze(mae_linear(:,i,10)) squeeze(mae_nonlinear(:,i,10)) squeeze(mae_nonlinear_break(:,i,10)) squeeze(mae_linear_har(:,i,10)) squeeze(mae_nonlinear_har(:,i,10))];
    
    TABLE3{i,1} = [squeeze(medae_linear(:,i,1)) squeeze(medae_nonlinear(:,i,1)) squeeze(medae_nonlinear_break(:,i,1)) squeeze(medae_linear_har(:,i,1)) squeeze(medae_nonlinear_har(:,i,1))];
    TABLE3{i,2} = [squeeze(medae_linear(:,i,5)) squeeze(medae_nonlinear(:,i,5)) squeeze(medae_nonlinear_break(:,i,5)) squeeze(medae_linear_har(:,i,5)) squeeze(medae_nonlinear_har(:,i,5))];
    TABLE3{i,3} = [squeeze(medae_linear(:,i,10)) squeeze(medae_nonlinear(:,i,10)) squeeze(medae_nonlinear_break(:,i,10)) squeeze(medae_linear_har(:,i,10)) squeeze(medae_nonlinear_har(:,i,10))];
end

for i=1:3
    if i==1
        j = 1;
    elseif i==2
        j = 5;
    else
        j = 10;
    end
    A1(:,:,i)     = TABLE1{1,i}(:,1:3)./repmat(squeeze(rmse_linear_har(:,1,j)),1,3);
    B1(:,:,i)     = TABLE1{1,i}(:,1:3)./repmat(squeeze(rmse_nonlinear_har(:,1,j)),1,3);
    
    A2(:,:,i)     = TABLE1{2,i}(:,1:3)./repmat(squeeze(rmse_linear_har(:,2,j)),1,3);
    B2(:,:,i)     = TABLE1{2,i}(:,1:3)./repmat(squeeze(rmse_nonlinear_har(:,2,j)),1,3);
   
    A3(:,:,i)     = TABLE1{3,i}(:,1:3)./repmat(squeeze(rmse_linear_har(:,3,j)),1,3);
    B3(:,:,i)     = TABLE1{3,i}(:,1:3)./repmat(squeeze(rmse_nonlinear_har(:,3,j)),1,3);
   
    A4(:,:,i)     = TABLE1{4,i}(:,1:3)./repmat(squeeze(rmse_linear_har(:,4,j)),1,3);
    B4(:,:,i)     = TABLE1{4,i}(:,1:3)./repmat(squeeze(rmse_nonlinear_har(:,4,j)),1,3);
end



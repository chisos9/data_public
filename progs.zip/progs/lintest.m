

[increase,output.pvalue_lt] = testnonlinear(output_linear.V,q(p+1:end,:),output_linear.error,...
            [output_linear.G.phi, output_linear.G.d],options.rob,options.const,options.index,options.sig);
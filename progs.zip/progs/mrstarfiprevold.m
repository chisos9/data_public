function yhat = mrstarfiprev(y,v,q,stdret,e,phi,d,c,gamma,omega,p,m,const,trunc,K,flag)

M  = 200;
T  = length(y);
T2 = length(e);

index  = unidrnd(T2,M,K);
index2 = unidrnd(T2,M,K);

pnew = p + const;
V    = NaN*ones(pnew,1);
if const == 1
    V(1,1) = 1;
    V(2:end,1) = v(end:-1:end-p+1);
else
    V = v(end:-1:end-p+1);
end

if m == 0
    %----------------------------------------------------------------------
    % Linear Forecast
    %----------------------------------------------------------------------
    yhat = NaN*ones(1,K);
    for k = 1:K
        vhat   = V'*phi;
        V(1)   = vhat;
        aux    = prevfracfilter(y,d,trunc);
        y(T+k) = aux(end) + vhat; 
        yhat(1,k) = y(T+k);
    end
else
    %----------------------------------------------------------------------
    % Nonlinear Forecast
    %----------------------------------------------------------------------
    yhat = NaN*ones(M,K);
    for k = 1:K
        for j = 1:M
            fX = NaN*ones(m,1);
            for i = 1:m
                transition = gamma(i)*(q*omega(:,i)-c(i)); 
                fX(i,1)    = siglog(transition);
            end
            if k>1
                vhat = V'*phi(:,1) + (repmat(V,m,1).*vec(repmat(fX',pnew,1)))'*vec(phi(:,2:end)) + e(index(j,k));
            else
                vhat = V'*phi(:,1) + (repmat(V,m,1).*vec(repmat(fX',pnew,1)))'*vec(phi(:,2:end));
            end
            V(1)      = vhat;
            aux       = prevfracfilter(y,d,trunc);
            y(T+k)    = aux(end) + vhat; 
            yhat(j,k) = y(end);
            if flag==1
                q = (exp(y(end)).^(1/2)).*stdret(index2(j,k));
            else 
                q = T+k;
            end
        end
    end
    yhat = mean(y(end-K+1:end,:),2)';
end
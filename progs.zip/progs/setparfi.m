function psi = setparfi(d,c,gamma,omega)

psi = [d;c;gamma;vec(omega)];
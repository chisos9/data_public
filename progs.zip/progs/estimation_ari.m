function [output_linear output_nonlinear] = estimation_ari(y,p,T,options)

func = 'msecost';

options_optim = optimset('Display','off','Jacobian','on','MaxFunEvals',1e10,...
    'LargeScale','off','MaxIter',4000,'TolFun',1e-8,...
    'DerivativeCheck','on','LevenbergMarquardt','on','FunValCheck', 'off',...
    'LineSearchType','cubicpoly','TolX',1e-8,'GradObj','on','Hessian','fin-diff-grads',...
    'Algorithm','interior-point','Diagnostics','off','FinDiffType','central',...
    'UseParallel','always','SubproblemAlgorithm','cg');

%--------------------------------------------------------------------------
% Remove the unconditional mean
%--------------------------------------------------------------------------
ybar = mean(y);
if ybar~=0
    y = y - ybar;
end

%--------------------------------------------------------------------------
% Linear Estimation
%--------------------------------------------------------------------------
d_set   = 0.01:0.01:0.5;
Nd      = length(d_set);
SSE     = zeros(Nd,1);

for j=1:Nd
    v = fracfilter(y,d_set(j),options.trunc);
    if options.const == 1
        V      = zeros(T-p,p+1);
        V(:,1) = ones(T-p,1);
    else
        V = zeros(T-p,p);
    end
    for i=1:p
        V(:,i+options.const) = v(p-i+1:T-i);
    end
    v = v(p+1:end);

    output_linear.alpha = (V'*V)\(V'*v);
    output_linear.error = v - V*output_linear.alpha;
    
    SSE(j,1) = output_linear.error'*output_linear.error; 
end

j = SSE==min(SSE);

[d feval]= fmincon(func,d_set(j),[],[],[],[],-0.5,0.5,[],...
        options_optim,y,p,T,options_linear.const,options_linear.trunc);

if feval>SSE(j)/T
    output_linear.d = d_set(j);
else
    output_linear.d = d;
end

% construct filtered series
v = fracfilter(y,output_linear.d,options_linear.trunc);

% construct lagged series
if options_linear.const == 1
    V      = zeros(T-p,p+1);
    Y      = zeros(T-p,p+1);
    V(:,1) = ones(T-p,1);
    Y(:,1) = ones(T-p,1);
else
    V = zeros(T-p,p);
    Y = zeros(T-p,p);
end
for i=1:p
    V(:,i+options.const) = v(p-i+1:T-i);
    Y(:,i+options.const) = y(p-i+1:T-i);
end
v = v(p+1:end);
y = y(p+1:end);

output_linear.alpha = (V'*V)\(V'*v);
output_linear.vhat  = V*output_linear.alpha;
output_linear.error = v - output_linear.vhat;
output_linear.yhat  = invfracfilter(output_linear.vhat,...
    output_linear.d,options_linear.trunc) + ybar;
output_linear.p     = p;

z = y - Y*output_linear.alpha;

[output_linear.G,output_linear.B] = gradglinear(V,output_linear.error,z,output_linear.d,output_linear.p,T,...
    options.const,options.trunc); 
           
output_linear.Sigma = inv(output_linear.B)/T;
          
output_linear.d_se = sqrt(output_linear.Sigma(1));
output_linear.d_t  = output_linear.d./output_linear.d_se;

aux = diag(output_linear.Sigma);
output_linear.alpha_se = sqrt(aux(2:end));
output_linear.alpha_t  = output_linear.alpha./output_linear.alpha_se;

output_linear.y    = y;
output_linear.ybar = ybar;
output_linear.v    = v;
output_linear.V    = V;

output_linear.mean     = mean(output_linear.error);
output_linear.std      = std(output_linear.error);
output_linear.median   = median(output_linear.error);
output_linear.max      = max(output_linear.error);
output_linear.min      = min(output_linear.error);
output_linear.kurtosis = kurtosis(output_linear.error);
output_linear.skewness = skewness(output_linear.error);

[~,p_JB,stat_JB]         = jbtest(output_linear.error);
[~,p_lillie,stat_lillie] = lillietest(output_linear.error); 

R2 = 1 - (output_linear.error'*output_linear.error)/...
    ((y-ybar)'*(y-ybar));

output_linear.stat_jb       = stat_JB;
output_linear.pvalue_jb     = p_JB;
output_linear.stat_lillie   = stat_lillie;
output_linear.pvalue_lillie = p_lillie;
output_linear.R2            = R2;

loglkh = log((output_linear.error'*output_linear.error)/T);
numpar = p+1;
            
output_linear.AIC  = loglkh + numpar*(2/T);
output_linear.BIC  = loglkh + numpar*(log(T)/T);
output_linear.HQIC = loglkh + numpar*(2*log(log(T))/T);

%--------------------------------------------------------------------------
% Nonlinear Estimation
%--------------------------------------------------------------------------
if options.nonlinear==1
    output_nonlinear = mrstari(y,x,w,q,nX,nW,T,options);
else
    output_nonlinear = [];
end
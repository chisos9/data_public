reset(RandStream.getDefaultStream)

T = 500;

%phi      = [0 0 0;0.8 -0.6 0.4;0.1 0.6 -0.5];
phi      = [0;0.8;0.1];
theta    = [];                                 
sigma    = 0.2;                                
alpha    = [];                                 
lambda   = [];                                 
gamma    = [10;6];
omega    = ones(1,1);
c        = [-1;1];                            
d        = 0.4;                                
df_error = [];                                
J        = 0;                                 

flag_dist     = 0;      
flag_vol      = 0;      
flag_outliers = 0;      
flag_nonlin   = 0;      
flag_sb       = 0;

options_linear.pmax      = 5;
options_linear.const     = 0;
options_linear.trunc     = 100;
options_linear.index     = [];
options_linear.IC        = 3;
options_linear.nonlinear = 0;

options_nonlinear.pmax      = 5;
options_nonlinear.const     = 0;
options_nonlinear.trunc     = 100;
options_nonlinear.index     = [];
options_nonlinear.IC        = 3;
options_nonlinear.grow_crit = 1;
options_nonlinear.rob       = 0;
options_nonlinear.sig       = 0.90:0.01:0.99;
options_nonlinear.size      = 5;
options_nonlinear.Nstart    = 1;
options_nonlinear.C         = 2;
options.diagnostics         = 1;

increase = zeros(1000,10);
p=2;
for i=1:1000
disp(i)
    data = genarfima(phi,theta,alpha,lambda,gamma,c,omega,sigma,d,...
                          flag_dist,flag_vol,flag_outliers,...
                          flag_nonlin,flag_sb,...
                          T,df_error,J);
    y = data.volatility;
    q = data.lagmean;

    output_linear = estimation_arfi(y,q,2,options_linear,options_nonlinear);

    [increase(i,:),output.pvalue_lt] = testnonlinear(output_linear.V,q(p+1:end,:),output_linear.error,...
            [output_linear.G.phi, output_linear.G.d],...
            options_nonlinear.rob,options_nonlinear.const,options_nonlinear.index,options_nonlinear.sig');

end       
        


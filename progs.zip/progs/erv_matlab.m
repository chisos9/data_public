function erv=erv_matlab(erv)

options = optimset('Diagnostics', 'off', 'Display', 'iter', 'MaxFunEvals', 1000);
%, 'LineSearchType', 'cubicpoly'

[erv.theta,erv.L,exitflag,output,g,H] = fminunc(erv.llh,erv.theta0,options,erv);

% standard errors
I_ = inv(H);
Iop = g*g'; 
erv.stderr1 = sqrt(diag(I_/erv.T));
erv.stderr2 = sqrt(diag(I_*Iop*I_/erv.T));
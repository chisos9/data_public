load parcial

for i=1:178
    
    M1_robust(i) = output_nonlinear_robust{i}.regimes-1;
    M1_BIC(i)    = output_nonlinear_BIC{i}.regimes-1;
    M1_HQIC(i)   = output_nonlinear_HQIC{i}.regimes-1;
    
    if output_nonlinear_robust{i}.regimes > 1
        p1_robust(i) = output_nonlinear_robust{i}.p;
    else
        p1_robust(i) = output_linear_robust{i}.p;
    end
    
    if output_nonlinear_BIC{i}.regimes > 1
        p1_BIC(i)    = output_nonlinear_BIC{i}.p;
    else
        p1_BIC(i)    = output_linear_BIC{i}.p;
    end
    
    if output_nonlinear_HQIC{i}.regimes > 1    
        p1_HQIC(i)   = output_nonlinear_HQIC{i}.p;
    else
        p1_HQIC(i)   = output_linear_HQIC{i}.p;
    end
    
    if output_nonlinear_robust{i}.regimes > 1
        d1_robust(i) = output_nonlinear_robust{i}.d;
    else
        d1_robust(i) = output_linear_robust{i}.d;
    end
    
    if output_nonlinear_BIC{i}.regimes > 1
        d1_BIC(i) = output_nonlinear_BIC{i}.d;
    else
        d1_BIC(i) = output_linear_BIC{i}.d;
    end
    
    if output_nonlinear_HQIC{i}.regimes > 1
        d1_HQIC(i) = output_nonlinear_HQIC{i}.d;
    else
        d1_HQIC(i) = output_linear_HQIC{i}.d;
    end
    
    if output_nonlinear_robust{i}.regimes > 1
        s1_robust(i) = output_nonlinear_robust{i}.std;
    else
        s1_robust(i) = output_linear_robust{i}.std;
    end
    
    if output_nonlinear_BIC{i}.regimes > 1
        s1_BIC(i) = output_nonlinear_BIC{i}.std;
    else
        s1_BIC(i) = output_linear_BIC{i}.std;
    end
    
    if output_nonlinear_HQIC{i}.regimes > 1
        s1_HQIC(i) = output_nonlinear_HQIC{i}.std;
    else
        s1_HQIC(i) = output_linear_HQIC{i}.std;
    end
end

load parcial2

for i=1:50
    
    M2_robust(i) = output_nonlinear_robust{i}.regimes-1;
    M2_BIC(i)    = output_nonlinear_BIC{i}.regimes-1;
    M2_HQIC(i)   = output_nonlinear_HQIC{i}.regimes-1;
    
    if output_nonlinear_robust{i}.regimes > 1
        p2_robust(i) = output_nonlinear_robust{i}.p;
    else
        p2_robust(i) = output_linear_robust{i}.p;
    end
    
    if output_nonlinear_BIC{i}.regimes > 1
        p2_BIC(i)    = output_nonlinear_BIC{i}.p;
    else
        p2_BIC(i)    = output_linear_BIC{i}.p;
    end
    
    if output_nonlinear_HQIC{i}.regimes > 1    
        p2_HQIC(i)   = output_nonlinear_HQIC{i}.p;
    else
        p2_HQIC(i)   = output_linear_HQIC{i}.p;
    end
    
    if output_nonlinear_robust{i}.regimes > 1
        d2_robust(i) = output_nonlinear_robust{i}.d;
    else
        d2_robust(i) = output_linear_robust{i}.d;
    end
    
    if output_nonlinear_BIC{i}.regimes > 1
        d2_BIC(i) = output_nonlinear_BIC{i}.d;
    else
        d2_BIC(i) = output_linear_BIC{i}.d;
    end
    
    if output_nonlinear_HQIC{i}.regimes > 1
        d2_HQIC(i) = output_nonlinear_HQIC{i}.d;
    else
        d2_HQIC(i) = output_linear_HQIC{i}.d;
    end
    
    if output_nonlinear_robust{i}.regimes > 1
        s2_robust(i) = output_nonlinear_robust{i}.std;
    else
        s2_robust(i) = output_linear_robust{i}.std;
    end
    
    if output_nonlinear_BIC{i}.regimes > 1
        s2_BIC(i) = output_nonlinear_BIC{i}.std;
    else
        s2_BIC(i) = output_linear_BIC{i}.std;
    end
    
    if output_nonlinear_HQIC{i}.regimes > 1
        s2_HQIC(i) = output_nonlinear_HQIC{i}.std;
    else
        s2_HQIC(i) = output_linear_HQIC{i}.std;
    end
end

load partial3

for i=1:122
    
    M3_robust(i) = output_nonlinear_robust{i}.regimes-1;
    M3_BIC(i)    = output_nonlinear_BIC{i}.regimes-1;
    M3_HQIC(i)   = output_nonlinear_HQIC{i}.regimes-1;
    
    if output_nonlinear_robust{i}.regimes > 1
        p3_robust(i) = output_nonlinear_robust{i}.p;
    else
        p3_robust(i) = output_linear_robust{i}.p;
    end
    
    if output_nonlinear_BIC{i}.regimes > 1
        p3_BIC(i)    = output_nonlinear_BIC{i}.p;
    else
        p3_BIC(i)    = output_linear_BIC{i}.p;
    end
    
    if output_nonlinear_HQIC{i}.regimes > 1    
        p3_HQIC(i)   = output_nonlinear_HQIC{i}.p;
    else
        p3_HQIC(i)   = output_linear_HQIC{i}.p;
    end
    
    if output_nonlinear_robust{i}.regimes > 1
        d3_robust(i) = output_nonlinear_robust{i}.d;
    else
        d3_robust(i) = output_linear_robust{i}.d;
    end
    
    if output_nonlinear_BIC{i}.regimes > 1
        d3_BIC(i) = output_nonlinear_BIC{i}.d;
    else
        d3_BIC(i) = output_linear_BIC{i}.d;
    end
    
    if output_nonlinear_HQIC{i}.regimes > 1
        d3_HQIC(i) = output_nonlinear_HQIC{i}.d;
    else
        d3_HQIC(i) = output_linear_HQIC{i}.d;
    end
    
    if output_nonlinear_robust{i}.regimes > 1
        d3_robust(i) = output_nonlinear_robust{i}.d;
    else
        d3_robust(i) = output_linear_robust{i}.d;
    end
    
    if output_nonlinear_robust{i}.regimes > 1
        s3_robust(i) = output_nonlinear_robust{i}.std;
    else
        s3_robust(i) = output_linear_robust{i}.std;
    end
    
    if output_nonlinear_BIC{i}.regimes > 1
        s3_BIC(i) = output_nonlinear_BIC{i}.std;
    else
        s3_BIC(i) = output_linear_BIC{i}.std;
    end
    
    if output_nonlinear_HQIC{i}.regimes > 1
        s3_HQIC(i) = output_nonlinear_HQIC{i}.std;
    else
        s3_HQIC(i) = output_linear_HQIC{i}.std;
    end
end

TABLE_p = [mean(p1_robust) mean(p2_robust) mean(p3_robust) mean(p1_BIC) mean(p2_BIC) mean(p3_BIC) mean(p1_HQIC) mean(p2_HQIC) mean(p3_HQIC)]; 
TABLE_M = [mean(M1_robust) mean(M2_robust) mean(M3_robust) mean(M1_BIC) mean(M2_BIC) mean(M3_BIC) mean(M1_HQIC) mean(M2_HQIC) mean(M3_HQIC)]; 
TABLE_d = [mean(d1_robust) mean(d2_robust) mean(d3_robust) mean(d1_BIC) mean(d2_BIC) mean(d3_BIC) mean(d1_HQIC) mean(d2_HQIC) mean(d3_HQIC)]; 
TABLE_s = [mean(s1_robust) mean(s2_robust) mean(s3_robust) mean(s1_BIC) mean(s2_BIC) mean(s3_BIC) mean(s1_HQIC) mean(s2_HQIC) mean(s3_HQIC)]; 

fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE_p) 
fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE_M)
fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE_d)
fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE_s)
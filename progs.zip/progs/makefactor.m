names = strvcat('AA','AXP','BA','BAC','CAT','CSCO','CVX','DD','DIS','GE','HD','HPQ','IBM','INTC','JNJ','JPM','KFT','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','T','UTX','VZ','WMT','XOM');


for n = 1:30;
    data = load(strcat('..\data\',names(n,:),'.txt'));
    x(:,n) = data(:,3);
end
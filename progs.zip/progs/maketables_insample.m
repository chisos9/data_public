pvalue = NaN*ones(30,8,5);

for n = 1:30
    for j=1:5
        regimes(n,1,j) = output_nonlinear_LM_robust{n,j,1}.regimes;
        regimes(n,2,j) = output_nonlinear_LM{n,j,1}.regimes;
        regimes(n,3,j) = output_nonlinear_BIC{n,j,1}.regimes;
        regimes(n,4,j) = output_nonlinear_HQIC{n,j,1}.regimes;
        
        regimes(n,5,j) = output_nonlinear_LM_robust{n,j,2}.regimes;
        regimes(n,6,j) = output_nonlinear_LM{n,j,2}.regimes;
        regimes(n,7,j) = output_nonlinear_BIC{n,j,2}.regimes;
        regimes(n,8,j) = output_nonlinear_HQIC{n,j,2}.regimes;
        
        if output_nonlinear_LM_robust{n,j,1}.regimes > 1
            d(n,1,j)      = output_nonlinear_LM_robust{n,j,1}.d;
            s(n,1,j)      = output_nonlinear_LM_robust{n,j,1}.std;
            r2(n,1,j)     = output_nonlinear_LM_robust{n,j,1}.R2;
            aic(n,1,j)    = output_nonlinear_LM_robust{n,j,1}.AIC;
            bic(n,1,j)    = output_nonlinear_LM_robust{n,j,1}.BIC;
            hqic(n,1,j)   = output_nonlinear_LM_robust{n,j,1}.HQIC;
            pvalue(n,1,j) = output_nonlinear_LM_robust{n,j,1}.pvalue(end);
        else
            d(n,1,j)     = output_linear_LM_robust{n,j,1}.d;
            s(n,1,j)      = output_linear_LM_robust{n,j,1}.std;
            r2(n,1,j)     = output_linear_LM_robust{n,j,1}.R2;
            aic(n,1,j)    = output_linear_LM_robust{n,j,1}.AIC;
            bic(n,1,j)    = output_linear_LM_robust{n,j,1}.BIC;
            hqic(n,1,j)   = output_linear_LM_robust{n,j,1}.HQIC;
            pvalue(n,1,j) = output_nonlinear_LM_robust{n,j,1}.pvalue_lt;

        end
        
        if output_nonlinear_LM{n,j,1}.regimes > 1
            d(n,2,j)      = output_nonlinear_LM{n,j,1}.d;
            s(n,2,j)      = output_nonlinear_LM{n,j,1}.std;
            r2(n,2,j)     = output_nonlinear_LM{n,j,1}.R2;
            aic(n,2,j)    = output_nonlinear_LM{n,j,1}.AIC;
            bic(n,2,j)    = output_nonlinear_LM{n,j,1}.BIC;
            hqic(n,2,j)   = output_nonlinear_LM{n,j,1}.HQIC;
            pvalue(n,2,j) = output_nonlinear_LM{n,j,1}.pvalue(end);

        else
            d(n,2,j)      = output_linear_LM{n,j,1}.d;
            s(n,2,j)      = output_linear_LM{n,j,1}.std;
            r2(n,2,j)     = output_linear_LM{n,j,1}.R2;
            aic(n,2,j)    = output_linear_LM{n,j,1}.AIC;
            bic(n,2,j)    = output_linear_LM{n,j,1}.BIC;
            hqic(n,2,j)   = output_linear_LM{n,j,1}.HQIC;
            pvalue(n,2,j) = output_nonlinear_LM{n,j,1}.pvalue_lt;
        end
        
        if output_nonlinear_BIC{n,j,1}.regimes > 1
            d(n,3,j)    = output_nonlinear_BIC{n,j,1}.d;
            s(n,3,j)    = output_nonlinear_BIC{n,j,1}.std;
            r2(n,3,j)   = output_nonlinear_BIC{n,j,1}.R2;
            aic(n,3,j)  = output_nonlinear_BIC{n,j,1}.AIC;
            bic(n,3,j)  = output_nonlinear_BIC{n,j,1}.BIC;
            hqic(n,3,j) = output_nonlinear_BIC{n,j,1}.HQIC;
        else
            d(n,3,j)    = output_linear_BIC{n,j,1}.d;
            s(n,3,j)    = output_linear_BIC{n,j,1}.std;
            r2(n,3,j)   = output_linear_BIC{n,j,1}.R2;
            aic(n,3,j)  = output_linear_BIC{n,j,1}.AIC;
            bic(n,3,j)  = output_linear_BIC{n,j,1}.BIC;
            hqic(n,3,j) = output_linear_BIC{n,j,1}.HQIC;
        end
            
        if output_nonlinear_HQIC{n,j,1}.regimes > 1
            d(n,4,j)    = output_nonlinear_HQIC{n,j,1}.d;
            s(n,4,j)    = output_nonlinear_HQIC{n,j,1}.std;
            r2(n,4,j)   = output_nonlinear_HQIC{n,j,1}.R2;
            aic(n,4,j)  = output_nonlinear_HQIC{n,j,1}.AIC;
            bic(n,4,j)  = output_nonlinear_HQIC{n,j,1}.BIC;
            hqic(n,4,j) = output_nonlinear_HQIC{n,j,1}.HQIC;
        else
            d(n,4,j)    = output_linear_HQIC{n,j,1}.d;
            s(n,4,j)    = output_linear_HQIC{n,j,1}.std;
            r2(n,4,j)   = output_linear_HQIC{n,j,1}.R2;
            aic(n,4,j)  = output_linear_HQIC{n,j,1}.AIC;
            bic(n,4,j)  = output_linear_HQIC{n,j,1}.BIC;
            hqic(n,4,j) = output_linear_HQIC{n,j,1}.HQIC;
        end
        
        if output_nonlinear_LM_robust{n,j,2}.regimes > 1
            d(n,5,j)      = output_nonlinear_LM_robust{n,j,2}.d;
            s(n,5,j)      = output_nonlinear_LM_robust{n,j,2}.std;
            r2(n,5,j)     = output_nonlinear_LM_robust{n,j,2}.R2;
            aic(n,5,j)    = output_nonlinear_LM_robust{n,j,2}.AIC;
            bic(n,5,j)    = output_nonlinear_LM_robust{n,j,2}.BIC;
            hqic(n,5,j)   = output_nonlinear_LM_robust{n,j,2}.HQIC;
            pvalue(n,5,j) = output_nonlinear_LM_robust{n,j,2}.pvalue(end);
        else
            d(n,5,j)      = output_linear_LM_robust{n,j,2}.d;
            s(n,5,j)      = output_linear_LM_robust{n,j,2}.std;
            r2(n,5,j)     = output_linear_LM_robust{n,j,2}.R2;
            aic(n,5,j)    = output_linear_LM_robust{n,j,2}.AIC;
            bic(n,5,j)    = output_linear_LM_robust{n,j,2}.BIC;
            hqic(n,5,j)   = output_linear_LM_robust{n,j,2}.HQIC;
            pvalue(n,5,j) = output_nonlinear_LM_robust{n,j,2}.pvalue_lt;
        end
        
        if output_nonlinear_LM{n,j,2}.regimes > 1
            d(n,6,j)      = output_nonlinear_LM{n,j,2}.d;
            s(n,6,j)      = output_nonlinear_LM{n,j,2}.std;
            r2(n,6,j)     = output_nonlinear_LM{n,j,2}.R2;
            aic(n,6,j)    = output_nonlinear_LM{n,j,2}.AIC;
            bic(n,6,j)    = output_nonlinear_LM{n,j,2}.BIC;
            hqic(n,6,j)   = output_nonlinear_LM{n,j,2}.HQIC;
            pvalue(n,6,j) = output_nonlinear_LM{n,j,2}.pvalue(end);
        else
            d(n,6,j)      = output_linear_LM{n,j,2}.d;
            s(n,6,j)      = output_linear_LM{n,j,2}.std;
            r2(n,6,j)     = output_linear_LM{n,j,2}.R2;
            aic(n,6,j)    = output_linear_LM{n,j,2}.AIC;
            bic(n,6,j)    = output_linear_LM{n,j,2}.BIC;
            hqic(n,6,j)   = output_linear_LM{n,j,2}.HQIC;
            pvalue(n,6,j) = output_nonlinear_LM{n,j,2}.pvalue_lt;
        end
        
        if output_nonlinear_BIC{n,j,2}.regimes > 1
            d(n,7,j)    = output_nonlinear_BIC{n,j,2}.d;
            s(n,7,j)    = output_nonlinear_BIC{n,j,2}.std;
            r2(n,7,j)   = output_nonlinear_BIC{n,j,2}.R2;
            aic(n,7,j)  = output_nonlinear_BIC{n,j,2}.AIC;
            bic(n,7,j)  = output_nonlinear_BIC{n,j,2}.BIC;
            hqic(n,7,j) = output_nonlinear_BIC{n,j,2}.HQIC;
        else
            d(n,7,j)    = output_linear_BIC{n,j,2}.d;
            s(n,7,j)    = output_linear_BIC{n,j,2}.std;
            r2(n,7,j)   = output_linear_BIC{n,j,2}.R2;
            aic(n,7,j)  = output_linear_BIC{n,j,2}.AIC;
            bic(n,7,j)  = output_linear_BIC{n,j,2}.BIC;
            hqic(n,7,j) = output_linear_BIC{n,j,2}.HQIC;
        end
            
        if output_nonlinear_HQIC{n,j,2}.regimes > 1
            d(n,8,j)    = output_nonlinear_HQIC{n,j,2}.d;
            s(n,8,j)    = output_nonlinear_HQIC{n,j,2}.std;
            r2(n,8,j)   = output_nonlinear_HQIC{n,j,2}.R2;
            aic(n,8,j)  = output_nonlinear_HQIC{n,j,2}.AIC;
            bic(n,8,j)  = output_nonlinear_HQIC{n,j,2}.BIC;
            hqic(n,8,j) = output_nonlinear_HQIC{n,j,2}.HQIC;
        else
            d(n,8,j)    = output_linear_HQIC{n,j,2}.d;
            s(n,8,j)    = output_linear_HQIC{n,j,2}.std;
            r2(n,8,j)   = output_linear_HQIC{n,j,2}.R2;
            aic(n,8,j)  = output_linear_HQIC{n,j,2}.AIC;
            bic(n,8,j)  = output_linear_HQIC{n,j,2}.BIC;
            hqic(n,8,j) = output_linear_HQIC{n,j,2}.HQIC;
        end
        
    end
end

% TABLE1_regimes = [squeeze(regimes(:,[1 3 4],1)) squeeze(regimes(:,[1 3 4],2)) squeeze(regimes(:,[1 3 4],3)) squeeze(regimes(:,[1 3 4],4))];
% TABLE2_regimes = [squeeze(regimes(:,[5 7 8],1)) squeeze(regimes(:,[5 7 8],2)) squeeze(regimes(:,[5 7 8],3)) squeeze(regimes(:,[5 7 8],4))];
% 
% TABLE1_d = [squeeze(d(:,[1 3 4],1)) squeeze(d(:,[1 3 4],2)) squeeze(d(:,[1 3 4],3)) squeeze(d(:,[1 3 4],4))];
% TABLE2_d = [squeeze(d(:,[5 7 8],1)) squeeze(d(:,[5 7 8],2)) squeeze(d(:,[5 7 8],3)) squeeze(d(:,[5 7 8],4))];
% 
% TABLE1_bic = [squeeze(bic(:,[1 3 4],1)) squeeze(bic(:,[1 3 4],2)) squeeze(bic(:,[1 3 4],3)) squeeze(bic(:,[1 3 4],4))];
% TABLE2_bic = [squeeze(bic(:,[5 7 8],1)) squeeze(bic(:,[5 7 8],2)) squeeze(bic(:,[5 7 8],3)) squeeze(bic(:,[5 7 8],4))];
% 
% TABLE1_hqic = [squeeze(hqic(:,[1 3 4],1)) squeeze(hqic(:,[1 3 4],2)) squeeze(hqic(:,[1 3 4],3)) squeeze(hqic(:,[1 3 4],4))];
% TABLE2_hqic = [squeeze(hqic(:,[5 7 8],1)) squeeze(hqic(:,[5 7 8],2)) squeeze(hqic(:,[5 7 8],3)) squeeze(hqic(:,[5 7 8],4))];
% 
% TABLE1_pvalue = [squeeze(pvalue(:,[1 3 4],1)) squeeze(pvalue(:,[1 3 4],2)) squeeze(pvalue(:,[1 3 4],3)) squeeze(pvalue(:,[1 3 4],4))];
% TABLE2_pvalue = [squeeze(pvalue(:,[5 7 8],1)) squeeze(pvalue(:,[5 7 8],2)) squeeze(pvalue(:,[5 7 8],3)) squeeze(pvalue(:,[5 7 8],4))];
% 
% 
% fprintf('%2.0f & %2.0f & %2.0f && %2.0f & %2.0f & %2.0f && %2.0f & %2.0f & %2.0f && %2.0f & %2.0f & %2.0f \n',TABLE1_regimes')
% fprintf('\n\n\n\n')
% fprintf('%2.0f & %2.0f & %2.0f && %2.0f & %2.0f & %2.0f && %2.0f & %2.0f & %2.0f && %2.0f & %2.0f & %2.0f \n',TABLE2_regimes')
% 
% fprintf('\n\n\n\n')
% fprintf('\n\n\n\n')
% fprintf('%2.2f & %2.2f & %2.2f && %2.2f & %2.2f & %2.2f && %2.2f & %2.2f & %2.2f && %2.2f & %2.2f & %2.2f \n',TABLE1_d')
% fprintf('\n\n\n\n')
% fprintf('%2.2f & %2.2f & %2.2f && %2.2f & %2.2f & %2.2f && %2.2f & %2.2f & %2.2f && %2.2f & %2.2f & %2.2f \n',TABLE2_d')
% 
% fprintf('\n\n\n\n')
% fprintf('\n\n\n\n')
% fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE1_bic')
% fprintf('\n\n\n\n')
% fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE2_bic')
% 
% fprintf('\n\n\n\n')
% fprintf('\n\n\n\n')
% fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE1_hqic')
% fprintf('\n\n\n\n')
% fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE2_hqic')
% 
% fprintf('\n\n\n\n')
% fprintf('\n\n\n\n')
% fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE1_pvalue')
% fprintf('\n\n\n\n')
% fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE2_pvalue')


TABLE_regimes = [squeeze(regimes(:,[1 3 4],1)) squeeze(regimes(:,[1 3 4],4)) squeeze(regimes(:,[5 7 8],1)) squeeze(regimes(:,[5 7 8],4))];

TABLE_d = [squeeze(d(:,[1 3 4],1)) squeeze(d(:,[1 3 4],4)) squeeze(d(:,[5 7 8],1)) squeeze(d(:,[5 7 8],4))];

TABLE_bic = [squeeze(bic(:,[1 3 4],1)) squeeze(bic(:,[1 3 4],4)) squeeze(bic(:,[5 7 8],1)) squeeze(bic(:,[5 7 8],4))];

TABLE_hqic = [squeeze(hqic(:,[1 3 4],1)) squeeze(hqic(:,[1 3 4],4)) squeeze(hqic(:,[5 7 8],1)) squeeze(hqic(:,[5 7 8],4))];

TABLE_pvalue = [squeeze(pvalue(:,[1 3 4],1)) squeeze(pvalue(:,[1 3 4],4)) squeeze(pvalue(:,[5 7 8],1)) squeeze(pvalue(:,[5 7 8],4))];

fprintf('%2.0f & %2.0f & %2.0f && %2.0f & %2.0f & %2.0f && %2.0f & %2.0f & %2.0f && %2.0f & %2.0f & %2.0f \n',TABLE_regimes')
fprintf('\n\n\n\n')

fprintf('\n\n\n\n')
fprintf('\n\n\n\n')
fprintf('%2.2f & %2.2f & %2.2f && %2.2f & %2.2f & %2.2f && %2.2f & %2.2f & %2.2f && %2.2f & %2.2f & %2.2f \n',TABLE_d')

fprintf('\n\n\n\n')
fprintf('\n\n\n\n')
fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE_bic')

fprintf('\n\n\n\n')
fprintf('\n\n\n\n')
fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE_hqic')

fprintf('\n\n\n\n')
fprintf('\n\n\n\n')
fprintf('%2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f \n',TABLE_pvalue')

%--------------------------------------------------------------------------
% Nonlinear HAR
%--------------------------------------------------------------------------

T = 1001;
dgp.alpha  = [0.38 0.25 0.41 0.20;...
             -0.30 -0.10 0.17 -0.03;...
              0.15 0.05 -0.41 -0.17]';
dgp.beta   = 0;
dgp.theta  = [0.0001;0.95;0.049];
dgp.phi    = [];
dgp.gamma  = [12 4]';
dgp.c      = [-2 2]';
dgp.sigma  = 0.5;

tau = [1 5 22]';

flag_nonlin = 1;
flag_outliers = 0;
flag_vol = 1;
flag_sb = 0;
flag_dist = 0;

df_error = 5;

options_linear.pmax        = 10;
options_linear.const       = 0;
options_linear.trunc       = 100;
options_linear.index       = 1;
options_linear.nonlinear   = 1;
options_linear.diagnostics = 0;

options_nonlinear.pmax        = 10;
options_nonlinear.const       = 0;
options_nonlinear.trunc       = 100;
options_nonlinear.index       = 1;
options_nonlinear.rob         = 1;
options_nonlinear.sig         = 0.95;
options_nonlinear.size        = 4;
options_nonlinear.Nstart      = 100;
options_nonlinear.C           = 2;
options_nonlinear.diagnostics = 0;


for i=1:1000
    i
    data_nonlinear = genhar([],dgp.theta,dgp.alpha,dgp.beta,dgp.phi,...
                        dgp.gamma,dgp.c,dgp.sigma,...
                        tau,flag_dist,flag_vol,flag_outliers,...
                        flag_nonlin,flag_sb,...
                        T,df_error);


    yin = data_nonlinear.variance(2:1001);
    qin = data_nonlinear.mean(1:1000);

    %h = 12;
    %[output_linear{i},output_nonlinear{i}] = estimation_har(yin,qin,[],tau,1000,options);
    options_linear.IC = 2;
    options_nonlinear.rob = 1;
    options_nonlinear.grow_crit = 1;
    options_nonlinear.IC = 2;
    [output_linear_robust{i},output_nonlinear_robust{i}] = estimation_arfi(yin,qin,[],options_linear,options_nonlinear);
    
    options_nonlinear.rob = 0;
    [output_linear_LM{i},output_nonlinear_LM{i}] = estimation_arfi(yin,qin,[],options_linear,options_nonlinear);
        
    options_linear.IC = 2;
    options_nonlinear.grow_crit = 2;
    options_nonlinear.IC = 2;
    [output_linear_BIC{i},output_nonlinear_BIC{i}] = estimation_arfi(yin,qin,[],options_linear,options_nonlinear);
    
    options_linear.IC = 3;
    options_nonlinear.grow_crit = 2;
    options_nonlinear.IC = 3;
    [output_linear_HQIC{i},output_nonlinear_HQIC{i}] = estimation_arfi(yin,qin,[],options_linear,options_nonlinear);
end
% youthat_linear_mean        = NaN*ones(T-h-1002+1,h);
% youthat_linear_std         = NaN*ones(T-h-1002+1,h);
% youthat_linear_median      = NaN*ones(T-h-1002+1,h);
% youthat_linear_skewness    = NaN*ones(T-h-1002+1,h);
% youthat_linear_kurtosis    = NaN*ones(T-h-1002+1,h);
% youthat_linear_prctile1    = NaN*ones(T-h-1002+1,h);
% youthat_linear_prctile2_5  = NaN*ones(T-h-1002+1,h);
% youthat_linear_prctile5    = NaN*ones(T-h-1002+1,h);
% youthat_linear_prctile10   = NaN*ones(T-h-1002+1,h);
% youthat_linear_prctile99   = NaN*ones(T-h-1002+1,h);
% youthat_linear_prctile97_5 = NaN*ones(T-h-1002+1,h);
% youthat_linear_prctile95   = NaN*ones(T-h-1002+1,h);
% youthat_linear_prctile90   = NaN*ones(T-h-1002+1,h);
% 
% youthat_nonlinear_mean        = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_std         = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_median      = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_skewness    = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_kurtosis    = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_prctile1    = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_prctile2_5  = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_prctile5    = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_prctile10   = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_prctile99   = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_prctile97_5 = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_prctile95   = NaN*ones(T-h-1002+1,h);
% youthat_nonlinear_prctile90   = NaN*ones(T-h-1002+1,h);

% for t=1002:T-h
%     yout = data_nonlinear.variance(t-1-max(tau):t-1);
%     wout = w(t:t+h-1);
%     qout = data_nonlinear.mean(t-1);
%     
%     
%     forecast_linear = ... 
%         forecast_har(yout,wout,qout,tau,output_linear.error,...
%           output_linear.alpha,output_linear.beta,...
%           [],[],[],h,0,length(output_linear.error));
%       
%     
%     youthat_linear_mean(t-1002+1,:)        = forecast_linear.mean;
%     youthat_linear_std(t-1002+1,:)         = forecast_linear.std;
%     youthat_linear_median(t-1002+1,:)      = forecast_linear.median;
%     youthat_linear_skewness(t-1002+1,:)    = forecast_linear.skewness;
%     youthat_linear_kurtosis(t-1002+1,:)    = forecast_linear.kurtosis;
%     youthat_linear_prctile1(t-1002+1,:)    = forecast_linear.prctile1;
%     youthat_linear_prctile2_5(t-1002+1,:)  = forecast_linear.prctile2_5;
%     youthat_linear_prctile5(t-1002+1,:)    = forecast_linear.prctile5;
%     youthat_linear_prctile10(t-1002+1,:)   = forecast_linear.prctile10;
%     youthat_linear_prctile99(t-1002+1,:)   = forecast_linear.prctile99;
%     youthat_linear_prctile97_5(t-1002+1,:) = forecast_linear.prctile97_5;
%     youthat_linear_prctile95(t-1002+1,:)   = forecast_linear.prctile95;
%     youthat_linear_prctile90(t-1002+1,:)   = forecast_linear.prctile90;
%     
%     forecast_nonlinear = ...
%         forecast_har(yout,wout,qout,tau,output_nonlinear.error,...
%           output_nonlinear.alpha,output_nonlinear.beta,...
%           output_nonlinear.lambda,output_nonlinear.gamma,...
%           output_nonlinear.c,h,output_nonlinear.regimes-1,...
%           length(output_nonlinear.error));
%       
%     youthat_nonlinear_mean(t-1002+1,:)        = forecast_nonlinear.mean;
%     youthat_nonlinear_std(t-1002+1,:)         = forecast_nonlinear.std;
%     youthat_nonlinear_median(t-1002+1,:)      = forecast_nonlinear.median;
%     youthat_nonlinear_skewness(t-1002+1,:)    = forecast_nonlinear.skewness;
%     youthat_nonlinear_kurtosis(t-1002+1,:)    = forecast_nonlinear.kurtosis;
%     youthat_nonlinear_prctile1(t-1002+1,:)    = forecast_nonlinear.prctile1;
%     youthat_nonlinear_prctile2_5(t-1002+1,:)  = forecast_nonlinear.prctile2_5;
%     youthat_nonlinear_prctile5(t-1002+1,:)    = forecast_nonlinear.prctile5;
%     youthat_nonlinear_prctile10(t-1002+1,:)   = forecast_nonlinear.prctile10;
%     youthat_nonlinear_prctile99(t-1002+1,:)   = forecast_nonlinear.prctile99;
%     youthat_nonlinear_prctile97_5(t-1002+1,:) = forecast_nonlinear.prctile97_5;
%     youthat_nonlinear_prctile95(t-1002+1,:)   = forecast_nonlinear.prctile95;
%     youthat_nonlinear_prctile90(t-1002+1,:)   = forecast_nonlinear.prctile90;
% end
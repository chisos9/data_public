
runs=1000;
qhat=zeros(runs,1);

    T=1000;
logx=zeros(T,1);
y=zeros(T,1);
    alpha0=.5;
    alpha1=.8;
    sigmae=1;
    sigmay=1;

c1=-2*log(1-sqrt(.95));
LR=zeros(T-1,runs);

for j=1:runs
    disp(j)
    e=sigmae*randn(T,1);
    eta=sigmay*randn(T,1);
    logx(1)=alpha0/(1-alpha1);
    for t=2:T
        logx(t)=alpha0+alpha1*logx(t-1)+e(t);
    end
    y=sqrt(exp(logx)).*eta;
    q=(y(1:T-1)-min(y(1:T-1)))/(max(y(1:T-1))-min(y(1:T-1)));
    %q=sqrt(logx(1:T-1));
    %q = (q-min(q))/(max(q)-min(q));
    
    dat = [logx(2:T) logx(1:T-1) q];
    na  = { 'logSV' 'logSV(-1)' 'RETURNS'  };
    yi  = 1;
    xi  = 2;
    qi  = 3;
    h   = 0;
    
    [qhat(j) LR(:,j)] = thr_est_trunc2(dat,na,yi,xi,qi,h);
end
lrmean=mean(LR');

figure
ax=linspace(0,1,T-1);
plot(lrmean(3:end-3))
figure
[h,ax]=hist(qhat,20);
bar(ax,h)

function [increase,pvalue] = testnonlinear(x,q,e,G,flag_rob,flag_const,index_x,sig)
                                           
% inputs:
% ------
% y: dependent variable.
% x: regressors, including a constant (or not).
% q: transition variable.
% e: residuals estimated under the null.
% G: estimated gradient under the null.
% flag_rob: dummy variable indicating if robust version should be used
% flag_const: dummy variabel indicatring if there is a constant in x
% index_x: index elements of q that are not in x
% sig: significance level(s).

% outputs:
% -------
% increase: dummy variable indicating if the model should be augmented or not.
% pvalue: p-value of the linearity test.

N = length(sig);

[T,nX] = size(x);
nQ     = size(q,2);

%--------------------------------------------------------------------------
% Null Hypothesis
%--------------------------------------------------------------------------
nG    = size(G,2);
normG = norm(G'*e);

% check if the residuals are orthogonal to the gradient
if normG>1e-4
    rG = rank(G'*G);
    if rG < nG
        [PC,~,lambda] = princomp(G);
        lambda        = cumsum(lambda./sum(lambda));
        indmin        = find(lambda>0.99999,1);
        GPCA          = (PC*G')';
        GPCA          = GPCA(:,1:indmin);
        b             = (GPCA'*GPCA)\(GPCA'*e);
        u             = e - GPCA*b;
        xH0           = GPCA;
    else
        b   = (G'*G)\(G'*e);
        u   = e - G*b;
        xH0 = G;
    end
else
    u = e;
    rG = rank(G'*G);
    if rG < nG
        [PC,~,lambda] = princomp(G);
        lambda        = cumsum(lambda./sum(lambda));
        indmin        = find(lambda>0.99999, 1 );
		GPCA          = (PC*G')';
        GPCA          = GPCA(:,1:indmin);
        xH0           = GPCA;
    else
        xH0 = G;
   end
end
SSE0 = sumsqr(u);

%--------------------------------------------------------------------------
% Taylor Expansion (Third Order)
%--------------------------------------------------------------------------
if flag_const==1
    xH1 = q(:,index_x);
    
    % first-order terms
    aux1 = reshape(vec(repmat(q,nX-1,1)),T,(nX-1)*nQ);
    aux2 = repmat(x(:,2:end),1,nQ);
    xH1  = [xH1 aux1.*aux2];
    
    % second-order terms
    aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
    aux2 = repmat(q,1,nQ);
    aux3 = aux1.*aux2;
    aux4 = reshape(vec(repmat(aux3,nX,1)),T,nX*nQ*nQ);
    aux5 = repmat(x,1,nQ*nQ);
    xH1  = [xH1 aux4.*aux5];
    
    % third-order terms
    aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
    aux2 = repmat(q,1,nQ);
    aux3 = aux1.*aux2;
    aux4 = reshape(vec(repmat(aux3,nQ,1)),T,nQ*nQ*nQ);
    aux5 = repmat(q,1,nQ*nQ);
    aux6 = aux4.*aux5;
    aux7 = reshape(vec(repmat(aux6,nX,1)),T,nX*nQ*nQ*nQ);
    aux8 = repmat(x,1,nQ*nQ*nQ);
    xH1  = [xH1 aux7.*aux8]; 
    
else
    % first-order terms
    aux1 = reshape(vec(repmat(q,nX,1)),T,nX*nQ);
    aux2 = repmat(x,1,nQ);
    xH1  = aux1.*aux2;
    
    % second-order terms
    aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
    aux2 = repmat(q,1,nQ);
    aux3 = aux1.*aux2;
    aux4 = reshape(vec(repmat(aux3,nX,1)),T,nX*nQ*nQ);
    aux5 = repmat(x,1,nQ*nQ);
    xH1  = [xH1 aux4.*aux5];
    
    % third-order terms
    aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
    aux2 = repmat(q,1,nQ);
    aux3 = aux1.*aux2;
    aux4 = reshape(vec(repmat(aux3,nQ,1)),T,nQ*nQ*nQ);
    aux5 = repmat(q,1,nQ*nQ);
    aux6 = aux4.*aux5;
    aux7 = reshape(vec(repmat(aux6,nX,1)),T,nX*nQ*nQ*nQ);
    aux8 = repmat(x,1,nQ*nQ*nQ);
    xH1  = [xH1 aux7.*aux8];  
end

% test if xH1 has full rank
nXH1 = size(xH1,2);
rH1  = rank(xH1'*xH1);
if rH1 < nXH1
    [PC,~,lambda] = princomp(xH1);
    lambda        = cumsum(lambda./sum(lambda));
    indmin        = find(lambda>0.99999, 1 );
	xH1_PC        = (PC*xH1')';
    xH1_PC        = xH1_PC(:,1:indmin);
    xH1           = xH1_PC;
end

%--------------------------------------------------------------------------
% Test Statistic
%--------------------------------------------------------------------------
  
% standarize the regressors and check for possible multicolinearity
z = [xH0 xH1];
if flag_const == 1
    nZ        = size(z,2);
    stdZ      = std(z);
    stdZ      = repmat(stdZ,T,1);
    z(:,2:nZ) = z(:,2:nZ)./stdZ(:,2:nZ);
else
    stdZ = std(z);
    stdZ = repmat(stdZ,T,1);
    z    = z./stdZ;
end


% Compute the test statistic
% --------------------------
if flag_rob == 0
    zz = (z'*z);
    if rank(zz)==size(zz,2)
        c   = (zz)\(z'*u);
    else
        c   = pinv(zz)*(z'*u);
    end
    v   = u - z*c;
    SSE = sumsqr(v);

    nXH0 = size(xH0,2);
    nXH1 = size(xH1,2);

    F = ((SSE0-SSE)/nXH1)/(SSE/(T-nXH0-nXH1));
    F = ones(N,1)*F;
    f = finv(sig,nXH1,T-nXH0-nXH1);
    increase = 1-(F <= f);
    pvalue = 1-fcdf(F,nXH1,T-nXH0-nXH1);
else
    nXH1 = size(xH1,2);
    d    = (xH0'*xH0)\(xH0'*xH1);
    r    = xH1 - xH0*d;
    i    = ones(T,1);
    aux  = (repmat(u,1,nXH1).*r);
    aa   = (aux'*aux);
    if rank(aa)==size(aa,2)
        c    = (aa)\(aux'*i);
    else
        c    = pinv(aa)*(aux'*i);
    end
    v    = i - aux*c;
    SSE  = sumsqr(v);
    
    CHI2     = T - SSE;
    CHI2     = ones(N,1)*CHI2;
    chi2     = chi2inv(sig,nXH1);
    chi2     = chi2';
    increase = 1- (CHI2 <= chi2);
    pvalue   = 1 - chi2cdf(CHI2,nXH1);
end
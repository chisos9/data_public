function h = fracdiff(h,d,T)

trunc = 20;

aux = 0:trunc;
d = d - aux;

phi(1,1) = 1;
for i=2:trunc
    phi(i,1)=((-1)^(i+1))*prod(d(1:i-1))/(factorial(i-1));
end

for i=1:trunc,
	X(:,i)=h(trunc-i+1:T-i);
end

haux = X*phi;
keyboard

function G = gradg(V,u,s,fX,d,phi,gamma,c,M,p,T,const)

sigma2_u = var(u);

if const == 1   
    aux = zeros(T-p-99,1);
else
    aux = zeros(T-p-100,1);
end

dldphi0 = -repmat(u./sigma2_u,1,p).*V(:,1:p);

if M>0
    if const == 1
        dldgammam = zeros(T-p+1,M);
        dldcm     = zeros(T-p+1,M);
    else
        dldgammam = zeros(T-p,M);
        dldcm     = zeros(T-p,M);
    end
    dldphim   = -repmat((u./sigma2_u),1,p*M).*V(:,p+1:end);
end

for m = 1:M  
    dldgammam(:,m)= -(u./sigma2_u).*(V(:,1:p)*phi(:,m+1)).*fX(:,m).*(1-fX(:,m)).*(s-c(m));
    dldcm(:,m)     = gamma(m)*(u./sigma2_u).*(V(:,1:p)*phi(:,m+1)).*fX(:,m).*(1-fX(:,m));
end

trunc = 100;
if const==1
    for j=1:trunc
        i=0:j-1;
        aux(:,j) = ((((-1)^j)/factorial(j))*sum(1./(d-i))*prod(d-i)).*u(trunc-j+1:T-p+1-j);
    end
else
    for j=1:trunc
        i=0:j-1;
        aux(:,j) = ((((-1)^j)/factorial(j))*sum(1./(d-i))*prod(d-i)).*u(trunc-j+1:T-p-j);
    end
end
dldd = [zeros(trunc,1);sum(aux,2)].*(u./sigma2_u);

if M>0
    G = [dldd dldphi0 dldphim dldgammam dldcm];
else
    G = [dldd dldphi0];
end
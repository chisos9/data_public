function [d_hat,phi_hat,gamma_hat,c_hat,sigma_hat,M_hat,s_hat,G_hat,ybar,...
    pvalue_linear,LM_linear,pvalue_robust_linear,LM_robust_linear,...
    pvalue,LM,pvalue_robust,LM_robust] = ...
    nlestimation(y,s,T,M,p,robust,const)

flag_M = isempty(M);

% Starting values
gamma    = [];
c        = [];
d_linear = 0.4;

% Remove the unconditional mean
ybar = mean(y);
y = y - ybar;

% linear estimation
options = optimset('Display','off','GradObj','off','MaxFunEvals',1e10,...
        'MaxIter',6000,'TolFun',1e-8,'DerivativeCheck','off',...
        'LineSearchType','cubicpoly','TolX',1e-8);
d_linear= fminunc(@(d_linear) msecost(d_linear,y,p,T,const),d_linear,options);
     
% construct filtered series
%v = fracfilter(y,d_linear);
v = fractint_filter_d(y,d_linear,100);

% construct lagged series
V = zeros(T-p,p);
for i=1:p
    V(:,i) = v(p-i+1:T-i);
end
if const == 1
    V = [ones(T-p,1) V];
end
v = v(p+1:end);
s = s(p+1:end,:);
q = size(s,2);

phi_linear = pinv(V'*V)*V'*v;

% residuals under linear estimation
u_linear = v - V*phi_linear;

% linearity testing and transition variable selection
if flag_M == 1
    rejectH0_linear        = zeros(q,1);
    pvalue_linear          = zeros(q,1);
    LM_linear              = zeros(q,1);
    rejectH0_robust_linear = zeros(q,1);
    pvalue_robust_linear   = zeros(q,1);
    LM_robust_linear       = zeros(q,1);
    for i=1:q
        [rejectH0_linear(i),pvalue_linear(i),LM_linear(i),...
            rejectH0_robust_linear(i),pvalue_robust_linear(i),LM_robust_linear(i)]=...
            testnl(V,u_linear,s(:,i),[],d_linear,phi_linear,[],[],0,p,T,0.95,const);
    end
    if robust == 0
        i = find(pvalue_linear == min(pvalue_linear));
        s = s(:,i);
        s_hat = i;
        increase = rejectH0_linear(i);
        
        pvalue_linear          = pvalue_linear(i);
        LM_linear              = LM_linear(i);
        pvalue_robust_linear   = pvalue_robust_linear(i);
        LM_robust_linear       = LM_robust_linear(i);
    else
        i = find(pvalue_robust_linear == min(pvalue_robust_linear));
        s = s(:,i);
        s_hat = i;
        increase = rejectH0_robust_linear;
        
        pvalue_linear          = pvalue_linear(i);
        LM_linear              = LM_linear(i);
        pvalue_robust_linear   = pvalue_robust_linear(i);
        LM_robust_linear       = LM_robust_linear(i);
    end
else
    if M>0
        increase = 1;
        s_hat = 1;
    else
        increase = 0;
    end
end

m = 0;
d = d_linear;
while increase==1
    m = m + 1;
    
    % starting values for gamma and c
    [gamma,c,d] = startval(y,s,m,gamma,c,T,p,const);
        
    % construct the vector of parameters
    PSI = setpar(d,gamma,c);
      
    options = optimset('Display','off','GradObj','off','MaxFunEvals',1e10,...
        'MaxIter',6000,'TolFun',0.01,'DerivativeCheck','off',...
        'LineSearchType','cubicpoly','TolX',1e-8);
    
    % simplex derivative-free optimization
    PSI = fminunc(@(PSI) msecostnl(PSI,y,s,p,m,T,const),PSI,options);
       
    [d,gamma,c] = getpar(PSI,m);
    aux   = [gamma,c];
    aux   = sortrows(aux,2);
    gamma = aux(:,1);
    c     = aux(:,2);
    
    %v = fracfilter(y,d);
    v = fractint_filter_d(y,d,100);
    
    V = zeros(T-p,p);
    for i=1:p
        V(:,i) = v(p-i+1:T-i);
    end
    if const == 1
        V = [ones(T-p,1) V];
    end
    v = v(p+1:end);
    
    fX = zeros(T-p,m);
    for i=1:m
        fX(:,i) = siglog(gamma(i)*(s-c(i)));
        if const==1
            V(:,i*(p+1)+1:(i+1)*(p+1)) = repmat(fX(:,i),1,p+1).*V(:,1:p+1);
        else
            V(:,i*p+1:(i+1)*p) = repmat(fX(:,i),1,p).*V(:,1:p);
        end
    end
    theta = pinv(V'*V)*V'*v;
    if const == 1
        phi   = reshape(theta,p+1,m+1);
        vhat  = V(:,1:p+1)*phi(:,1) + V(:,p+2:end)*vec(phi(:,2:end));
    else
        phi   = reshape(theta,p,m+1);
        vhat  = V(:,1:p)*phi(:,1) + V(:,p+1:end)*vec(phi(:,2:end));
    end    
    u     = v - vhat;
        
    if flag_M==1
        [rejectH0,pvalue,LM,...
        rejectH0_robust,pvalue_robust,LM_robust]=...
        testnl(V,u,s,fX,d,phi,gamma,c,m,p,T,1-(1-0.95)/(2^m),const);
        if robust == 0
            increase = rejectH0;
        else
            increase = rejectH0_robust;
        end
        if m>3
            increase = 0;
        end
    else
        if m<M
            increase = 1;
        else
            increase = 0;
        end
    end
end
if m>0
    d_hat     = d;
    phi_hat   = phi;
    gamma_hat = gamma;
    c_hat     = c;
    M_hat     = m;
    sigma_hat = std(u);
    if const == 1
        G_hat     = calcgrad(V,u,s,fX,d,phi,gamma,c,m,p+1,T,const);
    else
        G_hat     = calcgrad(V,u,s,fX,d,phi,gamma,c,m,p,T,const);
    end
else
    d_hat         = d_linear;
    phi_hat       = phi_linear;
    gamma_hat     = [];
    c_hat         = [];
    pvalue        = [];
    LM            = [];
    pvalue_robust = [];
    LM_robust     = [];
    M_hat         = m;
    sigma_hat     = std(u_linear);
    if const == 1
        G_hat = calcgrad(V,u_linear,[],[],d_linear,phi_linear,[],[],m,p+1,T,const);
    else
        G_hat = calcgrad(V,u_linear,[],[],d_linear,phi_linear,[],[],m,p,T,const);
    end
end
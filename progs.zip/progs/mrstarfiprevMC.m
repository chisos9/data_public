function yhat = mrstarfiprev(y,v,q,stdret,e,phi,d,c,gamma,p,m,const,trunc,K,flag)

M  = 200;
T  = length(y);
T2 = length(e);

index  = unidrnd(T2,M,K);
index2 = unidrnd(T2,M,K);

pnew = p + const;
V    = NaN*ones(pnew,1);
if const == 1
    V(1,1) = 1;
    V(2:end,1) = v(end:-1:end-p+1);
else
    V = v(end:-1:end-p+1);
end

if m == 0
    %----------------------------------------------------------------------
    % Linear Forecast
    %----------------------------------------------------------------------
    yhat = NaN*ones(1,K);
    for k = 1:K
        vhat   = V'*phi;
        V(1)   = vhat;
        aux    = prevfracfilter(y,d,trunc);
        y(T+k) = aux(end) + vhat; 
        yhat(1,k) = y(T+k);
    end
else
    %----------------------------------------------------------------------
    % Nonlinear Forecast
    %----------------------------------------------------------------------
    yhat = NaN*ones(M,K);
    transition = NaN*ones(m,M);
    q = repmat(q,1,M);
    V = repmat(V,1,M);
    y = repmat(y,1,M);
    for k = 1:K
        for i = 1:m
            fX = siglog(gamma(i)*(q-c(i)));
            transition(i,:) = (phi(:,i)'*V).*fX;
        end
        if k>1
            vhat = phi(:,1)'*V + sum(transition,1) + e(index(:,k))';
        else
            vhat = phi(:,1)'*V + sum(transition,1);
        end
        V(1,:)    = vhat;
        aux       = prevfracfilter(y,d,trunc);
        y(T+k,:)  = aux(end) + vhat; 
        yhat(:,k) = y(end,:)';
        if flag==1
            q = (exp(y(end,:)).^(1/2)).*stdret(index2(:,k))';
        else 
            q = T+k*ones(1,M);
        end
    end
    yhat = mean(y(end-K+1:end,:),2)';
end
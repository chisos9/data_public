function [isLinear_AIC,isLinear_SBIC,qhat] = tar_ic(y,X,q,T,p)

% Estimate the linear model
% -------------------------
b = inv(X'*X)*X'*y;
u = y-X*b;

AIC_linear  = log(var(u))+2*length(b)/T;
SBIC_linear = log(var(u))+log(T)*length(b)/T;

% Estimate the TAR model
% ----------------------
qhat = thr_est_trunc2([y,X,q],1,[3:size(X,2)+1],size(X,2)+2,0);

Z = [X X.*repmat((q>=qhat),1,p)];
b = inv(Z'*Z)*Z'*y;
e = y - Z*b;

AIC_TAR  = log(var(e))+2*length(b)/T;
SBIC_TAR = log(var(e))+log(T)*length(b)/T;

if AIC_TAR<AIC_linear
    isLinear_AIC=0;
else
    isLinear_AIC=1;
end

if SBIC_TAR<SBIC_linear
    isLinear_SBIC=0;
else
    isLinear_SBIC=1;
end
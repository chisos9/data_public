function pvalue = dm(e_1,e_2,h,flag)

kk=0;

if flag==0
    d=e_1.^2-e_2.^2;
elseif flag==1
    d=abs(e_1)-abs(e_2);
else
    d=e_1.*(e_1-e_2);
end
N=length(d);
d_bar=mean(d);
if h==1
    g=var(d);
    V=g/N;
else
    if var(d)>0
        g=var(d)*autocorr(d,h-1);
        V=abs(g(1)+2*sum(g(2:h)))/N;
    else
        V=0;
    end
end
if V>0
    DM=abs(d_bar)/sqrt(V);
    CF=sqrt((N+1-2*h+h*(h-1)/N)/N);
    MDM=(CF*DM);
    pvalue=1-tcdf(MDM,N-1);
else
    pvalue=NaN;
end
%keyboard
runs = 2000;
L=zeros(runs,1);
L1=zeros(runs,1);


T=10000;
t=(1:T)';
sigma=1;
lambda=linspace(0,1,T);
S=zeros(T,1);
S1=zeros(T,1);
S2=zeros(T,1);


for j=1:runs
    e1=sigma*randn(T+200,1);
    %e=cumsum(e1)';
    e=arfima(e1,0.4,T);
    se2=sum(e.^2)/T;
    for k=1:T-1
        S1(k)=1/(k*T)*sum(e(1:k))^2;
        S2(k)=1/((T-k)*T)*sum(e(k+1:T))^2;
        S(k)=se2-S1(k)-S2(k);
    end
    S1(T)=sum(e)^2/T^2;
    S2(T)=0;
    S(T)=se2-S1(T)-S2(T);
    [m, pos]=min(S);
    S_=S1+S2;
    [m1,pos1]=max(S_);
    L(j)=lambda(pos);
    L1(j)=lambda(pos1);
end
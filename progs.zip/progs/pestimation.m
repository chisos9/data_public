function p_hat = pestimation(y,q,T,pmax,index_V,const,trunc,IC)

% y:    dependent variable
% q:    transition variable
% T:    number of observations
% pmax: maximum AR order
% k:    order of the polynominal expansion
% IC:   ic to be used (AIC=1,BIC=2,HQ=3)

% This program uses a polynomial expansion of the nonlinear function to
% determine the AR order in the nonlinear ARFIMA model

ybar = mean(y);
y = y - ybar;

if isempty(q)==0
    q = q(pmax+1:end,:);
end

AIC  = zeros(pmax,1);
BIC  = zeros(pmax,1);
HQIC = zeros(pmax,1);

nQ    = size(q,2);
d_set = 0.01:0.01:0.49;
d_set = [0,d_set];    
Nd    = length(d_set);

for p = 1:pmax   
    % Grid search over the fractional difference parameter    
    SSE = zeros(Nd,1);
    for j=1:Nd
        v = fracfilter(y,d_set(j),trunc);
        if const == 1
            V      = zeros(T-pmax,p+1);
            V(:,1) = ones(T-pmax,1);
        else
            V = zeros(T-pmax,p);
        end
        for i=1:p
            V(:,i+const) = v(pmax-i+1:T-i);
        end
        v = v(pmax+1:end);

        nV = size(V,2);
    
        %------------------------------------------------------------------
        % Taylor Expansion (Third Order)
        %------------------------------------------------------------------
        if isempty(q)==0
            if const == 1
                X = [V q(:,index_V)];
    
                % first-order terms
                aux1 = reshape(vec(repmat(q,nV-1,1)),T,(nV-1)*nQ);
                aux2 = repmat(V(:,2:end),1,nQ);
                X    = [X aux1.*aux2];
    
                % second-order terms
                aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
                aux2 = repmat(q,1,nQ);
                aux3 = aux1.*aux2;
                aux4 = reshape(vec(repmat(aux3,nX,1)),T,nV*nQ*nQ);
                aux5 = repmat(V,1,nQ*nQ);
                X    = [X aux4.*aux5];
    
                % third-order terms
                aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
                aux2 = repmat(q,1,nQ);
                aux3 = aux1.*aux2;
                aux4 = reshape(vec(repmat(aux3,nQ,1)),T,nQ*nQ*nQ);
                aux5 = repmat(q,1,nQ*nQ);
                aux6 = aux4.*aux5;
                aux7 = reshape(vec(repmat(aux6,nX,1)),T,nV*nQ*nQ*nQ);
                aux8 = repmat(V,1,nQ*nQ*nQ);
                X    = [X aux7.*aux8];
            else
                % first-order terms
                aux1 = reshape(vec(repmat(q,nC,1)),T,nV*nQ);
                aux2 = repmat(V,1,nQ);
                X  = aux1.*aux2;
    
                % second-order terms
                aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
                aux2 = repmat(q,1,nQ);
                aux3 = aux1.*aux2;
                aux4 = reshape(vec(repmat(aux3,nX,1)),T,nV*nQ*nQ);
                aux5 = repmat(V,1,nQ*nQ);
                X    = [X aux4.*aux5];
    
                % third-order terms
                aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
                aux2 = repmat(q,1,nQ);
                aux3 = aux1.*aux2;
                aux4 = reshape(vec(repmat(aux3,nQ,1)),T,nQ*nQ*nQ);
                aux5 = repmat(q,1,nQ*nQ);
                aux6 = aux4.*aux5;
                aux7 = reshape(vec(repmat(aux6,nX,1)),T,nV*nQ*nQ*nQ);
                aux8 = repmat(V,1,nQ*nQ*nQ);
                X    = [X aux7.*aux8];  
            end
        else
            X = V;
        end
        b = (X'*X)\(X'*v);
        u = v - X*b;
        
        SSE(j,1) = u'*u;
    end    
    
    % Choose the value for d which minimized the sum of squared errors and use 
    % it as initial value for the nonlinear optimization procedure.
    j = SSE == min(SSE);
    
    d = d_set(j);
    
    v = fracfilter(y,d,trunc);
    if const == 1
        V      = zeros(T-pmax,p+1);
        V(:,1) = ones(T-pmax,1);
    else
        V = zeros(T-pmax,p);
    end
    for i=1:p
        V(:,i+const) = v(pmax-i+1:T-i);
    end
    v = v(pmax+1:end);

    nV = size(V,2);
    
    %------------------------------------------------------------------
    % Taylor Expansion (Third Order)
    %------------------------------------------------------------------
    if isempty(q)==0
        if const == 1
            X = [V q(:,index_V)];
    
            % first-order terms
            aux1 = reshape(vec(repmat(q,nV-1,1)),T,(nV-1)*nQ);
            aux2 = repmat(V(:,2:end),1,nQ);
            X    = [X aux1.*aux2];
    
            % second-order terms
            aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
            aux2 = repmat(q,1,nQ);
            aux3 = aux1.*aux2;
            aux4 = reshape(vec(repmat(aux3,nX,1)),T,nV*nQ*nQ);
            aux5 = repmat(V,1,nQ*nQ);
            X    = [X aux4.*aux5];
    
            % third-order terms
            aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
            aux2 = repmat(q,1,nQ);
            aux3 = aux1.*aux2;
            aux4 = reshape(vec(repmat(aux3,nQ,1)),T,nQ*nQ*nQ);
            aux5 = repmat(q,1,nQ*nQ);
            aux6 = aux4.*aux5;
            aux7 = reshape(vec(repmat(aux6,nX,1)),T,nV*nQ*nQ*nQ);
            aux8 = repmat(V,1,nQ*nQ*nQ);
            X    = [X aux7.*aux8];
         else
            % first-order terms
            aux1 = reshape(vec(repmat(q,nC,1)),T,nV*nQ);
            aux2 = repmat(V,1,nQ);
            X  = aux1.*aux2;
    
            % second-order terms
            aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
            aux2 = repmat(q,1,nQ);
            aux3 = aux1.*aux2;
            aux4 = reshape(vec(repmat(aux3,nX,1)),T,nV*nQ*nQ);
            aux5 = repmat(V,1,nQ*nQ);
            X    = [X aux4.*aux5];
    
            % third-order terms
            aux1 = reshape(vec(repmat(q,nQ,1)),T,nQ*nQ);
            aux2 = repmat(q,1,nQ);
            aux3 = aux1.*aux2;
            aux4 = reshape(vec(repmat(aux3,nQ,1)),T,nQ*nQ*nQ);
            aux5 = repmat(q,1,nQ*nQ);
            aux6 = aux4.*aux5;
            aux7 = reshape(vec(repmat(aux6,nX,1)),T,nV*nQ*nQ*nQ);
            aux8 = repmat(V,1,nQ*nQ*nQ);
            X    = [X aux7.*aux8];  
        end
    else
        X = V;
    end
    b = (X'*X)\(X'*v);
    u = v - X*b;
    
    loglkh = log((u'*u)/T);
    numpar = length(b);
    AIC(p,1)  = loglkh + numpar*(2/T);
    BIC(p,1)  = loglkh + numpar*(log(T)/T);
    HQIC(p,1) = loglkh + numpar*(2*log(log(T))/T);
end
if IC == 1
    p_hat = find(AIC==min(vec(AIC)));
elseif IC == 2  
    p_hat = find(BIC==min(vec(BIC)));
else
    p_hat = find(HQIC==min(vec(HQIC)));
end
p_hat = p_hat(1);

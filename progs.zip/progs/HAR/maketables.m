for i=1:1000
    regimes(i) = output_nonlinear{i}.regimes;
end
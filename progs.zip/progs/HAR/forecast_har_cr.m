function [yhat_har,yhat_har_cr] = forecast_har_cr(y,w,r,tau,e,stdret,alpha_har,beta_har,alpha_har_cr,beta_har_cr,h)

M        = 100;
t0       = max(tau);
nX       = length(tau)+1;
y_har    = repmat(y,1,M);
y_har_cr = repmat(y,1,M);
u        = unidrnd(length(e),M,1);
x        = ones(nX,M);
z        = zeros(nX-1,M);

%---------------------------------------------------------------------
% HAR Forecast
%----------------------------------------------------------------------
for t=t0:t0+h-1
    for i=1:nX-1
        x(i+1,:)=sum(y_har(t-tau(i)+1:t,:),1)/tau(i);
    end
    if isempty(w)==0
        y_har(t+1,:) = w(t-t0+1,:)*beta_har + x'*alpha_har;
    else
        y_har(t+1,:) = x'*alpha_har;
    end
end

%----------------------------------------------------------------------
% Nonlinear Forecast
%----------------------------------------------------------------------
r = repmat(r,1,M);
   
for t=t0:t0+h-1
    for i=1:nX-1
        x(i+1,:)=sum(y_har_cr(t-tau(i)+1:t,:),1)/tau(i);
        z(i,:)=sum(r(t-tau(i)+1:t,:),1)/tau(i);
    end
    z = z.*(z<0);
    if isempty(w)==0
        y_har_cr(t+1,:) = w(t-t0+1,:)*beta_har_cr + [x;z]'*alpha_har_cr;
    else
        y_har_cr(t+1,:) = [x;z]'*alpha_har_cr;
    end
    
    aux = find((exp(y_har_cr(t+1,:)).^(1/2))>10*mean(exp(y).^(0.5)));
    if isempty(aux)==0
        y_har_cr(t+1,aux)=y_har(t+1,aux);    
    end
    r(t+1,:) = (exp(y_har_cr(t+1,:)).^(1/2)).*stdret(u)';
    %r(t+1,:) = (exp(y_har_cr(t+1,:)).^(1/2)).*randn(1,M);
    r(t+1,:) = r(t+1,:).*(r(t+1,:)<0);
    if sum(isinf(y_har_cr(t+1,:)).*isnan(y_har_cr(t+1,:)))>0
        keyboard
    end
end
y_har    = y_har(t0+1:end,:);
y_har_cr = y_har_cr(t0+1:end,:);

yhat_har    = mean(y_har,2)';
yhat_har_cr = mean(y_har_cr,2)';
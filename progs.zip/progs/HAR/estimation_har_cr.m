function [output_har,output_har_cr] = estimation_har_cr(y,r,w,tau,T)

N   = length(tau);
nW  = size(w,2);

x = ones(T,N+1);
for i=1:N
    b = (1/tau(i))*ones(tau(i),1);
    x(:,i+1)=filter(b,1,y);
end

z = zeros(T,N);
for i=1:N
    b = (1/tau(i))*ones(tau(i),1);
    z(:,i)=filter(b,1,r);
end

z = z.*(z<0);

x = x(1:end-1,:);
z = z(1:end-1,:);
w = w(2:end,:);
X = [x w];
Z = [x z w];
y = y(2:end,1);


T = length(y);

% HAR and HAR-CR Estimation
% -------------------------
XX = X'*X;
ZZ = Z'*Z;

psi    = XX\(X'*y);
psi_cr = ZZ\(Z'*y);

alpha       = psi(1:N+1,1);
alpha_cr    = psi_cr(1:2*N+1,1);
beta        = psi(N+2:end,1);
beta_cr     = psi_cr(2*N+2:end,1);
yhat        = X*psi;
yhat_cr     = Z*psi_cr;
e           = y - yhat;
e_cr        = y - yhat_cr;
s           = std(e);
s_cr        = std(e_cr);
psi_se      = s*sqrt(diag((XX\eye(N+nW+1))));
psi_se_cr   = s_cr*sqrt(diag((ZZ\eye(2*N+nW+1))));
alpha_se    = psi_se(1:N+1,1);
alpha_se_cr = psi_se_cr(1:2*N+1,1);
beta_se     = psi_se(N+2:end,1);
beta_se_cr  = psi_se_cr(2*N+2:end,1);

S = zeros(N+nW+1);
for t=1:T
    S = S + e(t)^2*(X(t,:)'*X(t,:));
end
S_cr = zeros(2*N+nW+1);
for t=1:T
    S_cr = S_cr + e_cr(t)^2*(Z(t,:)'*Z(t,:));
end
psi_robust_se      =  sqrt(diag(((XX\S)/S)));
psi_robust_se_cr   =  sqrt(diag(((ZZ\S_cr)/S_cr)));
alpha_robust_se    = psi_robust_se(1:N+1,1);
alpha_robust_se_cr = psi_robust_se_cr(1:2*N+1,1);
beta_robust_se     = psi_robust_se(N+2:end,1);
beta_robust_se_cr  = psi_robust_se_cr(2*N+2:end,1);

R2    = 1 - (e'*e)/((y-mean(y))'*(y-mean(y)));
R2_cr = 1 - (e_cr'*e_cr)/((y-mean(y))'*(y-mean(y)));

output_har.alpha           = alpha;
output_har.alpha_se        = alpha_se;
output_har.alpha_t         = alpha./alpha_se;
output_har.alpha_se_robust = alpha_robust_se;
output_har.alpha_t_robust  = alpha./alpha_robust_se;
output_har.beta            = beta;
output_har.beta_se         = beta_se;
output_har.beta_t          = beta./beta_se;
output_har.beta_se_robust  = beta_robust_se;
output_har.beta_t_robust   = beta./beta_robust_se;
output_har.yhat            = yhat;
output_har.error           = e;
output_har.y               = y;
output_har.x               = X(:,1:N+1);
output_har.w               = X(:,1:N+2:end);
output_har.mean            = mean(e);
output_har.std             = s;
output_har.median          = median(e);
output_har.max             = max(e);
output_har.min             = min(e);
output_har.kurtosis        = kurtosis(e);
output_har.skewness        = skewness(e);
%output_har.stat_jb         = stat_JB;
%output_har.pvalue_jb       = p_JB;
%output_har.stat_lillie     = stat_lillie;
%output_har.pvalue_lillie   = p_lillie;
output_har.R2              = R2;

loglkh = log((e'*e)/T);
numpar = length(psi);
            
output_har.AIC  = loglkh + numpar*(2/T);
output_har.BIC  = loglkh + numpar*(log(T)/T);
output_har.HQIC = loglkh + numpar*(2*log(log(T))/T);

output_har_cr.alpha           = alpha_cr;
output_har_cr.alpha_se        = alpha_se_cr;
output_har_cr.alpha_t         = alpha_cr./alpha_se_cr;
output_har_cr.alpha_se_robust = alpha_robust_se_cr;
output_har_cr.alpha_t_robust  = alpha_cr./alpha_robust_se_cr;
output_har_cr.beta            = beta_cr;
output_har_cr.beta_se         = beta_se_cr;
output_har_cr.beta_t          = beta_cr./beta_se_cr;
output_har_cr.beta_se_robust  = beta_robust_se_cr;
output_har_cr.beta_t_robust   = beta_cr./beta_robust_se_cr;
output_har_cr.yhat            = yhat_cr;
output_har_cr.error           = e_cr;
output_har_cr.y               = y;
output_har_cr.x               = Z(:,1:N+1);
output_har_cr.w               = Z(:,1:N+2:end);
output_har_cr.mean            = mean(e_cr);
output_har_cr.std             = s_cr;
output_har_cr.median          = median(e_cr);
output_har_cr.max             = max(e_cr);
output_har_cr.min             = min(e_cr);
output_har_cr.kurtosis        = kurtosis(e_cr);
output_har_cr.skewness        = skewness(e_cr);
%output_har_cr.stat_jb         = stat_JB_cr;
%output_har_cr.pvalue_jb       = p_JB_cr;
%output_har_cr.stat_lillie     = stat_lillie_cr;
%output_har_cr.pvalue_lillie   = p_lillie_cr;
output_har_cr.R2              = R2_cr;

loglkh_cr = log((e_cr'*e_cr)/T);
numpar_cr = length(psi_cr);
            
output_har_cr.AIC  = loglkh_cr + numpar_cr*(2/T);
output_har_cr.BIC  = loglkh_cr + numpar_cr*(log(T)/T);
output_har_cr.HQIC = loglkh_cr + numpar_cr*(2*log(log(T))/T);

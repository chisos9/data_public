function [f,J] = msecost_mrstar(psi,y,x,w,q,m,n,nX,T)

[gamma,c] = getpar(psi,m);

fX       = zeros(T,m);
dfX      = zeros(T,m);
z        = zeros(T,n+nX*m);
z(:,1:n) = [x w];
for i=1:m
    fX(:,i)            = siglog(gamma(i)*(q-c(i)));
    dfX(:,i)           = dsiglog(fX(:,i));
    z(:,n+(i-1)*nX+1:n+i*nX) = repmat(fX(:,i),1,nX).*x;
end
theta  = (z'*z)\(z'*y);
alpha  = theta(1:nX);
if isempty(w)==1
    beta = [];
else
    beta = theta(nX+1:n);
end
lambda = reshape(theta(n+1:end),nX,m);
if isempty(w)==1
    yhat = x*alpha + sum((fX*lambda').*x,2);
else
    yhat = x*alpha + w*beta + sum((fX*lambda').*x,2);
end; 
ehat = y - yhat;
f    =  ehat/sqrt(T);

ggamma = ones(T,m);
gc     = ones(T,m);
for i=1:m
    ggamma(:,i) = (x*lambda(:,i)).*(dfX(:,i).*(q-c(i)));
    gc(:,i)     = -(x*lambda(:,i)).*(gamma(i)*dfX(:,i));
end

J = -[ggamma,gc]/sqrt(T);
function yhat=forecast_har(y,w,q,tau,e,stdret,alpha,beta,lambda,gamma,c,h,m,flag)

M = 100;
t0 = max(tau);
nX = length(tau)+1;
y = repmat(y,1,M);
u = unidrnd(length(e),M,1);
x = ones(nX,M);

if m == 0
    %----------------------------------------------------------------------
    % Linear Forecast
    %----------------------------------------------------------------------
    for t=t0:t0+h-1
        for i=1:nX-1
            x(i+1,:)=sum(y(t-tau(i)+1:t,:),1)/tau(i);
        end
        if isempty(w)==0
            y(t+1,:) = w(t-t0+1,:)*beta + x'*alpha;
        else
            y(t+1,:) = x'*alpha;
        end
    end
else
    %----------------------------------------------------------------------
    % Nonlinear Forecast
    %----------------------------------------------------------------------
    q = q.*ones(length(q),M);
    
    c     = repmat(c,1,M);
    gamma = repmat(gamma,1,M);
    for t=t0:t0+h-1
        for i=1:nX-1
            x(i+1,:)=sum(y(t-tau(i)+1:t,:),1)/tau(i);
        end
        f = siglog(gamma.*(repmat(q,m,1)- c));
        if isempty(w)==0
            y(t+1,:) = w(t-t0+1,:)*beta + x'*alpha+...
                sum(repmat(x,m,1).*repmat(f,nX,1).*repmat(vec(lambda),1,M),1)'+e(u);          
        else
            y(t+1,:) = x'*alpha+sum(repmat(x,m,1).*repmat(f,nX,1).*repmat(vec(lambda),1,M),1)'+e(u);
        end    
        if flag==1
           q = (exp(y(t+1,:)).^(1/2)).*stdret(u)';
        else
           q = q + 1;
        end
    end
end
y = y(t0+1:end,:);
yhat = mean(y,2)';
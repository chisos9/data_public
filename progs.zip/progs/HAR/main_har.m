%--------------------------------------------------------------------------
% data
%--------------------------------------------------------------------------
names = strvcat('AA','AXP','BA','BAC','CAT','CSCO','CVX','DD','DIS','GE','HD','HPQ','IBM','INTC','JNJ','JPM','KFT','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','T','UTX','VZ','WMT','XOM');

N = length(names);
K = 10;

s = RandStream('mcg16807', 'Seed', 4645132);
RandStream.setGlobalStream(s);

yhat_har      = cell(N,5);
yhat_har_cr   = cell(N,5);   
output_har    = cell(N,1,5);
output_har_cr = cell(N,1,5);
    
      
for flag_vol = 1:5
    flag_vol
    
    for n = 1:N
        data = load(strcat('..\..\data\',names(n,:),'.txt'));
        
        date = data(:,1);
        if n==7
            aux  = find(date==20011010);
        elseif n==17
            aux  = find(date==20010613);
        else
            aux  = find(date==20000103);
        end
        data = data(aux:end,:);
        date = data(:,1);
        
        r      = data(:,end);
        y      = data(:,flag_vol+2);
        logy   = log(y);
        stdret = (100*r)./sqrt(y);
        
        T0 = find(date==20051230);       
        T  = size(y,1); 
       
        %------------------------------------------------------------------
        % Estimation
        %------------------------------------------------------------------
        j = 0;
        for t = T0:T-K
            l = t-T0+1;
            if rem(l,50)==0 || l==1
                j = j+1;
                [output_har{n,j,flag_vol},output_har_cr{n,j,flag_vol}] = estimation_har_cr(logy(l+1:t),r(l+1:t),[],[1 5 22],length(logy(l+1:t)));
            end
  
            aux1 = logy(2:t);
            aux2 = r(2:t);   
            %if (flag_vol==1 && n==6 && t==1912); keyboard; end;
            %if (flag_vol==1 && n==1 && t==2207); keyboard; end;
            [yhat_har{n,flag_vol}(l,:) yhat_har_cr{n,flag_vol}(l,:)] = ...
                forecast_har_cr(aux1(end-22+1:end),[],aux2(end-22+1:end),[1 5 22],output_har_cr{n,j,flag_vol}.error,stdret,...
                output_har{n,j,flag_vol}.alpha,output_har{n,j,flag_vol}.beta,output_har_cr{n,j,flag_vol}.alpha,output_har_cr{n,j,flag_vol}.alpha,10);
        end
    end
end
save results_forecast_har_cr
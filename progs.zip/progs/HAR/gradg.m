function [G,B]=gradg(x,w,q,z,e,lambda,gamma,c,dfX,m,n,nX,T)

G.alpha  = x;

if isempty(w)==1
    G.lambda = z(:,nX+1:end);
    G.beta   = [];
else
    G.lambda = z(:,n+1:end);
    G.beta   = w;
end

G.gamma = ones(T,m);
G.c     = ones(T,m);
for i=1:m
    G.gamma(:,i) = (x*lambda(:,i)).*(dfX(:,i).*(q-c(i)));
    G.c(:,i)     = -(x*lambda(:,i)).*(gamma(i)*dfX(:,i));
end

numpar = n + nX*m + 2*m; 
aux = 2.*repmat(e,1,numpar).*[G.alpha G.beta G.lambda G.gamma G.c];

B = aux'*aux/T;
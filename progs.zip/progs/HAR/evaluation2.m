[N,J,M]=size(output_linear);

for n = 1:N   
    for j = 1:J
        for m=1:M
            if isempty(output_linear{n,j,m})==0
                d_linear(n,j,m) = abs(output_linear{n,j,m}.d);
                if output_nonlinear{n,j,m}.regimes > 1
                    d_nonlinear(n,j,m) = abs(output_nonlinear{n,j,m}.d);
                else
                    d_nonlinear(n,j,m) = abs(output_linear{n,j,m}.d);
                end
                M_nonlinear(n,j,m) = output_nonlinear{n,j,m}.regimes - 1;
            else
                d_linear(n,j,m)    = NaN;
                d_nonlinear(n,j,m) = NaN;
                M_nonlinear(n,j,m) = NaN;
            end
        end         
   end
end
% -------------------------------------------------------------------------
% Estimation of the multiple-Regime STAR model
%--------------------------------------------------------------------------

% inputs:
% ------
% y:  dependent variable.
% x:  regressors including a constant.
% w:  regressors variables with fixed coefficients (coefficients that are
%     fixed accross diferent regimes
% q:  transition variable.
% nX: number of columns in x.
% nW: number of columns in w.
% T:  number of observations.
% options: structure contating the settings of the estimation and testing 
%          procedure.
%    options.grow_crit:   1 (LM tests) or 2 (Information Criteria).
%    options.IC:          choice of IC when options.grow_crit = 2. 1 (AIC), 
%                         2 (BIC) or 3 (HQ).  
%    options.size:        maximum number of additional regimes.
%    options.diagnostics: 1 to compute diagnostic tests, 0 otherwise.
%    options.se:          1 to compute standard errors with the 
%                         sandwich estimator, 0 use the 
%                         outer product of the gradient.
%    options.rob:         dummy variable indicating if robust tests 
%                         (against non-normality and heteroskedasticity)  
%                         should be used or not. 
%    options.flag_x:      dummy variable indicating if q belongs to 
%                         x or not.
%    options.sig:         initial significance level of the tests.
%    options.C:           reducing rate for the sequence of LM tests.

% outputs:
% -------
% yhat: fitted values.
% ehat: residuals.
% alpha: linear parameters.
% lambda: nonlinear parameters.
% gamma: slope parameters.
% c: location parameters.

function output = mrstar(y,x,w,q,nX,nW,T,options)
                                                     
func='msecost_mrstar';
options_lsq = optimset('Display','off','Jacobian','on','MaxFunEvals',1e10,...
                'LargeScale','on','MaxIter',10000,'TolFun',1e-8,...
                'DerivativeCheck','off','Algorithm','trust-region-reflective',...
                'LineSearchType','cubicpoly','TolX',1e-8);

if isempty(w)
    n = nX;
else
    n = nX + nW;
end

if isempty(options)
    options.grow_crit   = 1;
    options.size        = 10;
    options.diagnostics = 1;
    options.se          = 1;
end

stdq = std(q);
if stdq~=1
    q = q./stdq;
end

switch options.grow_crit
    case 1
        X = [x w];
        e = y - X*((X'*X)\(X'*y));
        [increase,output.pvalue_lt] = testnonlinear(x,q,e,x,options.rob,1,options.index,options.sig);
        
        output.isLinear = 1 - increase;
        if increase == 1
            output.gamma = [];
            output.c     = [];
        end

        m = 0; % number of nonlinear terms in the model.
        while increase==1 && m<options.size
            m = m + 1;

            [output.gamma,output.c] = startval(y,x,w,q,m,output.gamma,output.c,n,nX,T);
            psi = setpar(output.gamma,output.c);
            lb  = [zeros(m,1);prctile(q,5)*ones(m,1)];
            ub  = [20*ones(m,1);prctile(q,95)*ones(m,1)];
            [psi,~,~,output.exitflag_nlsq,output.optimization] = lsqnonlin(func,psi,lb,ub,options_lsq,y,x,w,q,m,n,nX,T);
                
            [output.gamma,output.c] = getpar(psi,m);

            output.fX = zeros(T,m);
            z         = zeros(T,n+nX*m);
            z(:,1:n)  = [x w];
            for i=1:m
                output.fX(:,i)           = siglog(output.gamma(i)*(q-output.c(i)));
                z(:,n+(i-1)*nX+1:n+i*nX) = repmat(output.fX(:,i),1,nX).*x;
            end
            dfX  = dsiglog(output.fX);
                        
            theta  = (z'*z)\(z'*y);
            output.alpha  = theta(1:nX);
            if isempty(w)==1
                output.beta   = [];
                output.lambda = reshape(theta(nX+1:end),nX,m);
                output.yhat   = x*output.alpha + sum((output.fX*output.lambda').*x,2);
            else
                output.beta   = theta(nX+1:n);
                output.lambda = reshape(theta(n+1:end),nX,m);
                output.yhat   = x*output.alpha + w*output.beta + sum((output.fX*output.lambda').*x,2);
            end
            output.error = y - output.yhat;
                      
            [output.G,output.B] = gradg(x,w,q,z,output.error,output.lambda,...
                output.gamma,output.c,dfX,m,n,nX,T);
            
            G = [output.G.alpha output.G.beta output.G.lambda output.G.gamma output.G.c];
                                   
            [increase,output.pvalue(m)] = testnonlinear(x,q,output.error,...
                G,options.rob,options.index,options.const,1-(1-options.sig)/(options.C^m));
            
            output.regimes = m+1;
        end
    case 2
        gamma = [];
        c     = [];
        psi_IC = cell(options.size,1);
        exitflag_nlsq = cell(options.size,1);
        optimization  = cell(options.size,1);
        for m=1:options.size
            [gamma,c] = startval(y,x,w,q,m,gamma,c,n,nX,T);
            psi       = setpar(gamma,c);
            [psi,~,~,exitflag_nlsq{m},optimization{m}] = lsqnonlin(func,psi,[],[],options_lsq,y,x,w,q,m,n,nX,T);
            psi_IC{m} = psi;
            
            [gamma,c] = getpar(psi,m);

            fX       = zeros(T,m);
            z        = zeros(T,n+nX*m);
            z(:,1:n) = [x w];
            for i=1:m
                fX(:,i)                  = siglog(gamma(i)*(q-c(i)));
                z(:,n+(i-1)*nX+1:n+i*nX) = repmat(fX(:,i),1,nX).*x;
            end
                        
            theta  = (z'*z)\(z'*y);
            alpha  = theta(1:nX);
            if isempty(w)==1
                lambda = reshape(theta(nX+1:end),nX,m);
                yhat   = x*alpha + sum((fX*lambda').*x,2);
            else
                beta   = theta(nX+1:n);
                lambda = reshape(theta(n+1:end),nX,m);
                yhat   = x*alpha + w*beta + sum((fX*lambda').*x,2); 
            end
            ehat = y - yhat;
                      
            loglkh = log((ehat'*ehat)/T);
            numpar = length(theta)+length(psi);
                      
            output.AIC(m)  = loglkh + numpar*(2/T);
            output.BIC(m)  = loglkh + numpar*(log(T)/T);
            output.HQIC(m) = loglkh + numpar*(2*log(log(T))/T);
        end      
        
        %------------------------------------------------------------------
        % Linear model estimation
        %------------------------------------------------------------------
        X  = [x w];
        XX = X'*X;
        
        psi_linear  = XX\(X'*y);
        yhat_linear = X*psi_linear;
        e_linear    = y - yhat_linear;
        
        loglkh = log((e_linear'*e_linear)/T);
        numpar = length(psi_linear);
                      
        output.AIC_linear  = loglkh + numpar*(2/T);
        output.BIC_linear  = loglkh + numpar*(log(T)/T);
        output.HQIC_linear = loglkh + numpar*(2*log(log(T))/T);
        
        %------------------------------------------------------------------
        % Select the best specification
        %------------------------------------------------------------------
        if options.IC==1
            if min(output.AIC)>output.AIC_linear
                m = 0;
            else
                m = find(output.AIC == min(output.AIC));
            end
        elseif options.IC==2
            if min(output.BIC)>output.BIC_linear
                m = 0;
            else
                m = find(output.BIC == min(output.BIC));
            end
        else
            if min(output.HQIC)>output.HQIC_linear
                m = 0;
            else
                m = find(output.HQIC == min(output.HQIC));
            end
        end
        if m>0                  
            psi = psi_IC{m};
            output.exitflag_nlsq = exitflag_nlsq{m};
            output.optimization  = optimization{m};
        
            [output.gamma,output.c] = getpar(psi,m);

            output.fX = zeros(T,m);
            z         = zeros(T,n+nX*m);
            z(:,1:n)  = [x w];
            for i=1:m
                output.fX(:,i)           = siglog(output.gamma(i)*(q-output.c(i)));
                z(:,n+(i-1)*nX+1:n+i*nX) = repmat(output.fX(:,i),1,nX).*x;
            end
            dfX  = dsiglog(output.fX);
            
            theta  = (z'*z)\(z'*y);
            output.alpha  = theta(1:nX);
            if isempty(w)==1
                output.beta = [];
                output.lambda = reshape(theta(nX+1:end),nX,m);
                output.yhat   = x*output.alpha + sum((output.fX*output.lambda').*x,2);
            else
                output.beta   = theta(nX+1:n);
                output.lambda = reshape(theta(n+1:end),nX,m);
                output.yhat   = x*output.alpha + w*output.beta + sum((output.fX*output.lambda').*x,2); 
            end
            output.error = y - output.yhat;
            
            [output.G,output.B] = gradg(x,w,q,z,output.error,output.lambda,...
                output.gamma,output.c,dfX,m,n,nX,T);
                                            
            output.regimes = m+1;
        end
    case 3
        gamma = [];
        c     = [];
        for m=1:options.size
            [output.gamma,output.c] = startval(y,x,w,q,m,gamma,c,n,nX,T);
            output.psi = setpar(output.gamma,output.c);
            [output.psi,~,~,output.exitflag_nlsq,output.optimization] = lsqnonlin(func,output.psi,[],[],options_lsq,y,x,w,q,m,n,nX,T);
            
            [output.gamma,output.c] = getpar(output.psi,m);

            output.fX = zeros(T,m);
            z         = zeros(T,n+nX*m);
            z(:,1:n)  = [x w];
            for i=1:m
                output.fX(:,i)           = siglog(output.gamma(i)*(q-output.c(i)));
                z(:,n+(i-1)*nX+1:n+i*nX) = repmat(output.fX(:,i),1,nX).*x;
            end
            dfX  = dsiglog(output.fX);
            
            theta  = (z'*z)\(z'*y);
            output.alpha  = theta(1:nX);
            if isempty(w)==1
                output.lambda = reshape(theta(nX+1:end),nX,m);
                output.yhat   = x*output.alpha + sum((output.fX*output.lambda').*x,2);
            else
                output.beta   = theta(nX+1:n);
                output.lambda = reshape(theta(n+1:end),nX,m);
                output.yhat   = x*output.alpha + w*output.beta + sum((output.fX*output.lambda').*x,2); 
            end
            output.error = y - output.yhat;
        end
        [output.G,output.B] = gradg(x,w,q,z,output.error,output.lambda,...
                output.gamma,output.c,dfX,m,n,nX,T);    
            
        output.regimes = m+1;
end

if m>0
    %----------------------------------------------------------------------
    % Impose restrictions on parameter c (ordering)
    %----------------------------------------------------------------------
    q = q*stdq;
    output.gamma = output.gamma/stdq;
    output.c     = output.c*stdq;
    [~,index] = sortrows([output.gamma output.c],2);
    output.gamma=output.gamma(index);
    output.c=output.c(index);
       
    output.fX = zeros(T,m); 
    z  = zeros(T,n+nX*m);
    z(:,1:n)  = [x w];
    for i=1:m
        output.fX(:,i)           = siglog(output.gamma(i)*(q-output.c(i)));
        z(:,n+(i-1)*nX+1:n+i*nX) = repmat(output.fX(:,i),1,nX).*x;
    end
    theta  = (z'*z)\(z'*y);
    output.alpha  = theta(1:nX);
    if isempty(w)==1
        output.beta   = [];
        output.lambda = reshape(theta(nX+1:end),nX,m);
        output.yhat   = x*output.alpha + sum((output.fX*output.lambda').*x,2);
    else
        output.beta   = theta(nX+1:n);
        output.lambda = reshape(theta(n+1:end),nX,m);
        output.yhat   = x*output.alpha + w*output.beta + sum((output.fX*output.lambda').*x,2);
    end
    output.error = y - output.yhat;

    [output.G,output.B] = gradg(x,w,q,z,output.error,output.lambda,...
        output.gamma,output.c,dfX,m,n,nX,T);

    % -------------------------------------------------------------------------
    % Compute standard errors & diagnostic statistics
    % -------------------------------------------------------------------------
    if options.se==1
        % Compute the Hessian and the Sandwich Estimator
        [output.H,output.A] = calch(x,w,q,z(:,n+1:end),output.error,...
            output.G.gamma,output.G.c,output.lambda,output.gamma,...
            output.c,output.fX,dfX,m,nX,T);

        output.Sigma = ((output.A\output.B)/output.A);
    else
        % Compute the Outer Product of the Gradient
        output.Sigma = output.B;
    end
    
    % Standard errors
    se = sqrt(diag(output.Sigma));

    output.alpha_se = se(1:nX);
    output.alpha_t  = output.alpha/output.alpha_se;
    if isempty(w)==1
        output.beta_se = [];
        output.beta_t  = [];
    else
        output.beta_se = se(nX+1:n);
        output.beta_se = output.beta/output.beta_se;
    end
    output.lambda_se = reshape(se(n+1:n+m*nX),nX,m);
    output.lambda_t  = output.lambda/output.lambda_se;
    output.gamma_se  = se(n+m*nX+1:n+m*(nX+1));
    output.gamma_t   = output.gamma/output.gamma_se;
    output.c_se      = se(n+m*(nX+1)+1:end);
    output.c_t       = output.c/output.c_se;

    output.y = y;    % Actual dependent variable
    output.x = x;    % Regressors with time-varying coefficients
    output.w = w;    % Regressors with fixed coefficients
    output.q = q;    % Transition variable
    
    % Compute diagnostic statistics
    if options.diagnostics==1
        output.mean     = mean(output.error);       % residual mean
        output.std      = std(output.error);        % residual standard deviation
        output.median   = median(output.error);     % residual median
        output.max      = max(output.error);        % max residual
        output.min      = min(output.error);        % min residual
        output.kurtosis = kurtosis(output.error);   % residual kurtosis
        output.skewness = skewness(output.error);   % residual skewness
        output.R2       = 1 - ...                   % R-squared
            (output.error'*output.error)/((y-mean(y))'*(y-mean(y)));

        [~,output.pvalue_jb,output.stat_jb] = ...   % Jarque-Bera test
            jbtest(output.error);   
        [~,output.pvalue_lillie,output.stat_lillie] = ...   % Lilliefors test
            lillietest(output.error); 
    end
else
    output.regimes = 1;
end
% Function to compute starting valus for a multiple-regime Smooth
% Transition Regression (STR). The algorith is based on a grid search over
% the parameters gamma and c.

function [gammaf,cf]=startval(y,x,w,q,m,gamma,c,n,nX,T)

% inputs:
% ------
% y: dependent variable.
% x: regressors.
% w: dummy regressors.
% q: transition variable.
% m: number of nonlinear terms (number of regimes - 1)
% gamma: gamma values for the previous nonlinear terms.
% c: c values for the previous nonlinear terms.

% outputs:
% -------
% gammaf: starting value for gamma.
% cf: starting value for c.

bestcost=999999999999999999999999;

% Maximum and minimum values for gamma
% ------------------------------------
maxgamma  = 20;
mingamma  = 1;
rategamma = .5;

% Maximum and minumum values for c
% --------------------------------
minc  = prctile(q,10);
maxc  = prctile(q,90);
ratec = (maxc-minc)/200;

gamma(m,1) = 0;
c(m,1) = 0;

fX       = zeros(T,m);
z        = zeros(T,n+nX*m);
z(:,1:n) = [x w];
for newgamma=mingamma:rategamma:maxgamma
    for newc=minc:ratec:maxc
        gamma(m,1) = newgamma;
        c(m,1)     = newc;
        for i=1:m
            fX(:,i)                  = siglog(gamma(i)*(q-c(i)));
            z(:,n+(i-1)*nX+1:n+i*nX) = repmat(fX(:,i),1,nX).*x;
        end
        theta  = (z'*z)\(z'*y);
        alpha  = theta(1:nX);
        if isempty(w)
            lambda = reshape(theta(n+1:end),nX,m);
            yhat   = x*alpha +  sum((fX*lambda').*x,2);
        else
            beta = theta(nX+1:n);
            lambda = reshape(theta(n+1:end),nX,m);
            yhat   = x*alpha + w*beta + sum((fX*lambda').*x,2);
        end
        e    = y - yhat;
      	cost = var(e);
       	if cost<=bestcost
            bestcost = cost;
            gammaf   = gamma;
            cf       = c;
        end
    end
end
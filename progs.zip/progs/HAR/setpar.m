function X = setpar(gamma,c)

X = [gamma;c];
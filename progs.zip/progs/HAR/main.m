%--------------------------------------------------------------------------
% Settings
%--------------------------------------------------------------------------
options.grow_crit   = 1;
options.IC          = 2;
options.size        = 4;
options.diagnostics = 0;
options.se          = 1;
options.nonlinear   = 1;
options.rob         = 1;
options.sig         = 0.95;
options.flag_x      = 0;
options.C           = 2;
options.index       = 1;
options.const       = 1;

%--------------------------------------------------------------------------
% data
%--------------------------------------------------------------------------
names = strvcat('AA','AXP','BA','BAC','CAT','CSCO','CVX','DD','DIS','GE','HD','HPQ','IBM','INTC','JNJ','JPM','KFT','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','T','UTX','VZ','WMT','XOM');

N = length(names);
K = 10;

yhat_linear      = cell(N,5);
yhat_nonlinear   = cell(N,5);   
output_linear    = cell(N,1,5);
output_nonlinear = cell(N,1,5);
    
      
for flag_vol = 1:5
    flag_vol
    
    for n = 1:N
        data = load(strcat('..\..\data\',names(n,:),'.txt'));
        
        date = data(:,1);
        if n==7
            aux  = find(date==20011010);
        elseif n==17
            aux  = find(date==20010613);
        else
            aux  = find(date==20000103);
        end
        data = data(aux:end,:);
        date = data(:,1);
        
        r      = 100*data(:,end);
        y      = data(:,flag_vol+2);
        logy   = log(y);
        stdret = r./sqrt(y);
        
        T0 = find(date==20051230);       
        T  = size(y,1); 
       
        %------------------------------------------------------------------
        % Estimation
        %------------------------------------------------------------------
        j = 0;
        for t = T0:T-K
            l = t-T0+1;
            if rem(l,50)==0 || l==1
                j = j+1;
                [output_linear{n,j,flag_vol},output_nonlinear{n,j,flag_vol}] = estimation_har(logy(l+1:t),r(l:t-1),[],[1 5 22],length(logy(l+1:t)),options);
            end
  
            aux = logy(2:t);
            yhat_linear{n,flag_vol}(l,:) = forecast_har(aux(end-22+1:end),[],[],[1 5 22],[],[],output_linear{n,j,flag_vol}.alpha,output_linear{n,j,flag_vol}.beta,[],[],[],K,0,0);
                                                              
            if output_nonlinear{n,j,flag_vol}.regimes>1
                yhat_nonlinear{n,flag_vol}(l,:)=forecast_har(aux(end-22+1:end),[],r(t),[1 5 22],output_nonlinear{n,j,flag_vol}.error,stdret,output_nonlinear{n,j,flag_vol}.alpha,[],output_nonlinear{n,j,flag_vol}.lambda,output_nonlinear{n,j,flag_vol}.gamma,output_nonlinear{n,j,flag_vol}.c,K,output_nonlinear{n,j,flag_vol}.regimes-1,1);
            else
                yhat_nonlinear{n,flag_vol}(l,:)=yhat_linear{n}(l,:);
            end
        end
    end
end
save results_forecast_har
function [H,A]=calch(x,w,q,z,e,ggamma,gc,lambda,gamma,c,fX,dfX,m,nX,T)

H.alpha_alpha  = 2*(x'*x);
if isempty(w) == 0
    H.alpha_beta   = 2*(w'*x);
else
    H.alpha_beta   = [];
end
H.alpha_lambda = 2*z'*x;
H.alpha_gamma  = 2*ggamma'*x;
H.alpha_c      = 2*gc'*x;

H.beta_alpha  = H.alpha_beta';

if isempty(w) == 0
    H.beta_beta   = 2*(w'*w);
    H.beta_lambda = 2*z'*w;
    H.beta_gamma  = 2*ggamma'*w;
    H.beta_c      = 2*gc'*w;
else
    H.beta_beta   = [];
    H.beta_lambda = [];
    H.beta_gamma  = [];
    H.beta_c      = [];
end

H.lambda_alpha  = H.alpha_lambda';
H.lambda_beta   = H.beta_lambda';
H.lambda_lambda = 2*(z'*z);

d2fX2 = dfX-2*fX.*dfX;

auxA = repmat(q,1,m)-repmat(c',T,1);
auxB = repmat(gamma',T,1);

aux1 = (x*lambda).*dfX.*auxA;
aux2 = (x*lambda).*dfX.*auxB;

aux3 =  repmat(e,1,m).*(x*lambda).*auxA;
aux4 =  sum(aux3.*auxA.*d2fX2);
aux5 =  sum(aux3.*auxB.*d2fX2);

aux6 = repmat(e,1,nX).*x;
aux7 = zeros(m,nX*m);
aux8 = zeros(m,nX*m);
for i=1:m
    aux7(i,(i-1)*nX+1:i*nX) = sum(aux6.*repmat(dfX(:,i).*(q-c(i)),1,nX));
    aux8(i,(i-1)*nX+1:i*nX) = -sum(aux6.*repmat(dfX(:,i).*gamma(i),1,nX));
end

H.lambda_gamma = 2*(ggamma'*z - aux7);
H.lambda_c     = 2*(gc'*z - aux8);

H.gamma_alpha  = H.alpha_gamma';
H.gamma_beta   = H.beta_gamma';
H.gamma_lambda = H.lambda_gamma';

H.gamma_gamma = 2*(aux1'*aux1 - diag(aux4));
H.gamma_c     = -2*(aux1'*aux2 + diag(aux5));

H.c_alpha  = H.alpha_c';
H.c_beta   = H.beta_c';
H.c_lambda = H.lambda_c';
H.c_gamma  = H.lambda_c';

aux10 = repmat(e,1,m).*(x*lambda).*auxB;
aux11 = sum(aux10.*auxB.*d2fX2);

H.c_gamma = H.gamma_c';
H.c_c = 2*(aux2'*aux2 - diag(aux11));

A = [H.alpha_alpha'  H.alpha_beta'  H.alpha_lambda'  H.alpha_gamma'  H.alpha_c';...
     H.beta_alpha'   H.beta_beta'   H.beta_lambda'   H.beta_gamma'   H.beta_c';...
     H.lambda_alpha' H.lambda_beta' H.lambda_lambda' H.lambda_gamma' H.lambda_c';...
     H.gamma_alpha'  H.gamma_beta'  H.gamma_lambda'  H.gamma_gamma'  H.gamma_c';...
     H.c_alpha'      H.c_beta'      H.c_lambda'      H.c_gamma'      H.c_c'];
 
 A =A/T;
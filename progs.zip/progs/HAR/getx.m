function [gamma,c]=getX(X,p) 

gamma=X(1);
c=X(2);
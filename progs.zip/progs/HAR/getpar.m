function [gamma,c]=getpar(X,m) 

gamma = X(1:m,1);
c = X(m+1:end,1);
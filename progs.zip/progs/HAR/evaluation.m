names = strvcat('AA','AXP','BA','BAC','CAT','CSCO','CVX','DD','DIS','GE','HD','HPQ','IBM','INTC','JNJ','JPM','KFT','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','T','UTX','VZ','WMT','XOM');

N = length(names);
K = 10;
      
for i = 1:5   
    for n = 1:N
        data = load(strcat('..\..\data\',names(n,:),'.txt'));
        
        date = data(:,1);
        if n==7
            aux  = find(date==20011010);
        elseif n==17
            aux  = find(date==20010613);
        else
            aux  = find(date==20000103);
        end
        data = data(aux:end,:);
        date = data(:,1);
        
        y      = data(:,i+2);
        logy   = log(y);
        
        T0 = find(date==20051230);       
        T  = size(y,1); 
        
        if isempty( yhat_linear{n,i})==0
            for k = 1:K
                yout{n,i}(:,k)        = logy(T0+k:end-K+k);
                e_linear{n,i}(:,k)    = yout{n,i}(:,k) - yhat_linear{n,i}(:,k);
                e_nonlinear{n,i}(:,k) = yout{n,i}(:,k) - yhat_nonlinear{n,i}(:,k);
                
                rmse_linear(n,i,k)    = sqrt(mean(e_linear{n,i}(:,k).^2));
                rmse_nonlinear(n,i,k) = sqrt(mean(e_nonlinear{n,i}(:,k).^2));
            
                mae_linear(n,i,k)    = mean(abs(e_linear{n,i}(:,k)));
                mae_nonlinear(n,i,k) = mean(abs(e_nonlinear{n,i}(:,k)));
            end
        else
                e_linear{n,i}(:,k)    = NaN;
                e_nonlinear{n,i}(:,k) = NaN;
            
                rmse_linear(n,i,k)    = NaN;
                rmse_nonlinear(n,i,k) = NaN;
            
                mae_linear(n,i,k)    = NaN;
                mae_nonlinear(n,i,k) = NaN;
        end
    end
end
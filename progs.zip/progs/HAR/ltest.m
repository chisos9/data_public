% Linearity test against a Logistic STAR specification.
% The test is based on the third-order Taylor series expansion of the
% logistic function around the null hypothesis.

function [isLinear,pvalue]=ltest(y,x,w,q,flag_x,flag_rob,sig)

% inputs:
% ------
% y: dependent variable.
% X: regressors, including a constant.
% q: transition variable.
% flag_x: dummy variable indicating if q belongs to x (flag = 1) or not (flag = 0).
% flag_rob: dummy variable indicating if robust test should be used (flag = 1) or not (flag = 0).
% sig: significance level(s).

% outputs:
% -------
% isLinear: dummy variable indicating if linearity is rejected or not.
% pvalue: p-value of the linearity test. 

N  = length(sig);
X  = [x w];
[T,nX] = size(x);

% Linear Model (Null hypothesis)
% -----------------------------
b    = (X'*X)\(X'*y);
u    = y - X*b;
SSE0 = u'*u;

xH0  = X;

% Regressors under the alternative
% --------------------------------
if flag_x == 1
    q   = repmat(q,1,nX-1);
    xH1 = [x(:,2:nX).*q x(:,2:nX).*(q.^2) x(:,2:nX).*(q.^3)];
else
    q   = repmat(q,1,nX);
    xH1 = [x.*q x.*(q.^2) x.*(q.^3)];
end

Z = [xH0 xH1];

% Standardize the regressors
% --------------------------
nZ        = size(Z,2);
stdZ      = std(Z);
stdZ      = repmat(stdZ,T,1);
Z(:,2:nZ) = Z(:,2:nZ)./stdZ(:,2:nZ);


% Nonlinear Model (Alternative hypothesis)
% ----------------------------------------
c   = (Z'*Z)\(Z'*u);
e   = u - Z*c;
SSE = e'*e;

% Compute the test statistic
% --------------------------
if flag_rob == 0
    nXH0 = size(xH0,2);
    nXH1 = size(xH1,2);
    
    F = ((SSE0-SSE)/nXH1)/(SSE/(T-nXH0-nXH1));
    F = ones(N,1)*F;
    f = finv(sig,nXH1,T-nXH0-nXH1);
    f = f';
    isLinear = F <= f;
    pvalue = 1-fcdf(F,nXH1,T-nXH0-nXH1);
else
    nXH1 = size(xH1,2);
    d   = (xH0'*xH0)\(xH0'*xH1);
    r   = xH1 - xH0*d;
    i   = ones(T,1);
    aux = (repmat(u,1,nXH1).*r);
    c   = (aux'*aux)\aux'*i;
    e   = i - aux*c;
    SSE = e'*e;

    CHI2     = T - SSE;
    CHI2     = ones(N,1)*CHI2;
    chi2     = chi2inv(sig,nXH1);
    chi2     = chi2';
    isLinear = CHI2 <= chi2;
    pvalue   = 1 - chi2cdf(CHI2,nXH1);
end
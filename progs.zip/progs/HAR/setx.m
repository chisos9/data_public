function X=setX(gamma,c)

X(1)=gamma;
X(2)=c;
function [output_linear,output_nonlinear] = estimation_har(y,q,w,tau,T)

N   = length(tau);
nW  = size(w,2);
nX  = N + 1;

x = ones(T,N+1);
for i=1:N
    b = (1/tau(i))*ones(tau(i),1);
    x(:,i+1)=filter(b,1,y);
end

x = x(1:end-1,:);
w = w(2:end,:);
X = [x w];
y = y(2:end,1);
q = q(2:end,1);

T = length(q);

% Linear Estimation
% -----------------
XX    = X'*X;

psi_linear      = XX\(X'*y);
alpha_linear    = psi_linear(1:N+1,1);
beta_linear     = psi_linear(N+2:end,1);
yhat_linear     = X*psi_linear;
e_linear        = y - yhat_linear;
s_linear        = std(e_linear);
psi_linear_se   = s_linear*sqrt(diag((XX\eye(N+nW+1))));
alpha_linear_se = psi_linear_se(1:N+1,1);
beta_linear_se  = psi_linear_se(N+2:end,1);

S = zeros(N+nW+1);
for t=1:T
    S = S + e_linear(t)^2*(X(t,:)'*X(t,:));
end
psi_linear_robust_se =  sqrt(diag(((XX\S)/S)));
alpha_linear_robust_se = psi_linear_robust_se(1:N+1,1);
beta_linear_robust_se  = psi_linear_robust_se(N+2:end,1);

%[~,p_JB,stat_JB] = jbtest(e_linear);
%[~,p_lillie,stat_lillie] = lillietest(e_linear); 

R2 = 1 - (e_linear'*e_linear)/((y-mean(y))'*(y-mean(y)));

% Linearity testing
[~,pvalue_lt] = ltest(y,x,w,q/std(q),options.flag_x,options.rob,options.sig);

output_linear.alpha           = alpha_linear;
output_linear.alpha_se        = alpha_linear_se;
output_linear.alpha_t         = alpha_linear./alpha_linear_se;
output_linear.alpha_se_robust = alpha_linear_robust_se;
output_linear.alpha_t_robust  = alpha_linear./alpha_linear_robust_se;
output_linear.beta            = beta_linear;
output_linear.beta_se         = beta_linear_se;
output_linear.beta_t          = beta_linear./beta_linear_se;
output_linear.beta_se_robust  = beta_linear_robust_se;
output_linear.beta_t_robust   = beta_linear./beta_linear_robust_se;
output_linear.yhat            = yhat_linear;
output_linear.error           = e_linear;
output_linear.y               = y;
output_linear.x               = x(:,1:N+1);
output_linear.w               = x(:,1:N+2:end);
output_linear.mean            = mean(e_linear);
output_linear.std             = s_linear;
output_linear.median          = median(e_linear);
output_linear.max             = max(e_linear);
output_linear.min             = min(e_linear);
output_linear.kurtosis        = kurtosis(e_linear);
output_linear.skewness        = skewness(e_linear);
%output_linear.stat_jb         = stat_JB;
%output_linear.pvalue_jb       = p_JB;
%output_linear.stat_lillie     = stat_lillie;
%output_linear.pvalue_lillie   = p_lillie;
output_linear.R2              = R2;
output_linear.pvalue_ltest    = pvalue_lt;

loglkh = log((e_linear'*e_linear)/T);
numpar = length(psi_linear);
            
output_linear.AIC  = loglkh + numpar*(2/T);
output_linear.BIC  = loglkh + numpar*(log(T)/T);
output_linear.HQIC = loglkh + numpar*(2*log(log(T))/T);

if options.nonlinear==1
    output_nonlinear = mrstar(y,x,w,q,nX,nW,T,options);
else
    output_nonlinear.regimes = 1;
end
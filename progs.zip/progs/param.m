%--------------------------------------------------------------------------
% Models with Leverage
%--------------------------------------------------------------------------
MC = 100;

options_linearLM.IC          = 2;
options_linearLM.pmax        = 5;
options_linearLM.const       = 0;
options_linearLM.trunc       = 100;
options_linearLM.index       = 1;
options_linearLM.nonlinear   = 1;
options_linearLM.diagnostics = 0;

options_nonlinearLM.IC          = 2;
options_nonlinearLM.pmax        = 5;
options_nonlinearLM.const       = 0;
options_nonlinearLM.trunc       = 100;
options_nonlinearLM.index       = 1;
options_nonlinearLM.rob         = 1;
options_nonlinearLM.sig         = 0.95;
options_nonlinearLM.size        = 2;
options_nonlinearLM.Nstart      = 100;
options_nonlinearLM.C           = 2;
options_nonlinearLM.diagnostics = 0;
options_nonlinearLM.grow_crit   = 3;

p = 2;

load data_500
T = size(y,1);
trend = (2:T)./T;
trend = trend'; 
for i=1:MC
    i
    % -------------------------
    % Specification by LM tests
    % -------------------------
     
    % short-memory
    options_linearLM.nonlinear   = 0;
    [output_linear_1_LM{i},output_nonlinear_1_LM{i}] = estimation_arfi(y(2:T,i,1),r(1:T-1,i,1),p,options_linearLM,options_nonlinearLM); disp('1')
    [output_linear_2_LM{i},output_nonlinear_2_LM{i}] = estimation_arfi(y(2:T,i,2),r(1:T-1,i,2),p,options_linearLM,options_nonlinearLM);disp('2')
    [output_linear_3_LM{i},output_nonlinear_3_LM{i}] = estimation_arfi(y(2:T,i,3),r(1:T-1,i,3),p,options_linearLM,options_nonlinearLM);disp('3')
    
    options_linearLM.nonlinear   = 1;
    [output_linear_4_LM{i},output_nonlinear_4_LM{i}] = estimation_arfi(y(2:T,i,4),r(1:T-1,i,4),p,options_linearLM,options_nonlinearLM);disp('4')
    [output_linear_5_LM{i},output_nonlinear_5_LM{i}] = estimation_arfi(y(2:T,i,5),r(1:T-1,i,5),p,options_linearLM,options_nonlinearLM);disp('5')
    [output_linear_6_LM{i},output_nonlinear_6_LM{i}] = estimation_arfi(y(2:T,i,6),r(1:T-1,i,6),p,options_linearLM,options_nonlinearLM);disp('6')
    [output_linear_7_LM{i},output_nonlinear_7_LM{i}] = estimation_arfi(y(2:T,i,7),trend,p,options_linearLM,options_nonlinearLM);disp('7')
    [output_linear_8_LM{i},output_nonlinear_8_LM{i}] = estimation_arfi(y(2:T,i,8),trend,p,options_linearLM,options_nonlinearLM);disp('8')
    [output_linear_9_LM{i},output_nonlinear_9_LM{i}] = estimation_arfi(y(2:T,i,9),trend,p,options_linearLM,options_nonlinearLM);disp('9')
    
    % long-memory
    options_linearLM.nonlinear   = 0;
    [output_linear_10_LM{i},output_nonlinear_10_LM{i}] = estimation_arfi(y(2:T,i,10),r(1:T-1,i,10),p,options_linearLM,options_nonlinearLM);disp('10')
    [output_linear_11_LM{i},output_nonlinear_11_LM{i}] = estimation_arfi(y(2:T,i,11),r(1:T-1,i,11),p,options_linearLM,options_nonlinearLM);disp('11')
    [output_linear_12_LM{i},output_nonlinear_12_LM{i}] = estimation_arfi(y(2:T,i,12),r(1:T-1,i,12),p,options_linearLM,options_nonlinearLM);disp('12')
    
    options_linearLM.nonlinear   = 1;
    [output_linear_13_LM{i},output_nonlinear_13_LM{i}] = estimation_arfi(y(2:T,i,13),r(1:T-1,i,13),p,options_linearLM,options_nonlinearLM);disp('13')
    [output_linear_14_LM{i},output_nonlinear_14_LM{i}] = estimation_arfi(y(2:T,i,14),r(1:T-1,i,14),p,options_linearLM,options_nonlinearLM);disp('14')
    [output_linear_15_LM{i},output_nonlinear_15_LM{i}] = estimation_arfi(y(2:T,i,15),r(1:T-1,i,15),p,options_linearLM,options_nonlinearLM);disp('15')
    [output_linear_16_LM{i},output_nonlinear_16_LM{i}] = estimation_arfi(y(2:T,i,16),trend,p,options_linearLM,options_nonlinearLM);disp('16')
    [output_linear_17_LM{i},output_nonlinear_17_LM{i}] = estimation_arfi(y(2:T,i,17),trend,p,options_linearLM,options_nonlinearLM);disp('17')
    [output_linear_18_LM{i},output_nonlinear_18_LM{i}] = estimation_arfi(y(2:T,i,18),trend,p,options_linearLM,options_nonlinearLM);disp('18')
end
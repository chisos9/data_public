function gz = g_nelson(z,gamma,erv)

%normal
Eabsz=sqrt(2/pi);

gz=gamma(1)*z+gamma(2)*(abs(z)-Eabsz);
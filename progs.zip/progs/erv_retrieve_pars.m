function    [betar,gamma,betav,phi,psi,matheta,d,sigmav]=erv_retrieve_pars(erv)

betar=erv.theta(1:erv.kbetar);
gamma=erv.theta(erv.kbetar+1:erv.kbetar+erv.kgamma);
betav=erv.theta(erv.kbetar+erv.kgamma+1:erv.kbetar+erv.kgamma+erv.kbetav);
phi=erv.theta(erv.kbetar+erv.kgamma+erv.kbetav+1:erv.kbetar+erv.kgamma+erv.kbetav+erv.kphi);
psi=erv.theta(erv.kbetar+erv.kgamma+erv.kbetav+erv.kphi+1:erv.kbetar+erv.kgamma+erv.kbetav+erv.kphi+erv.kpsi);
matheta=erv.theta(erv.kbetar+erv.kgamma+erv.kbetav+erv.kphi+erv.kpsi+1:erv.kbetar+erv.kgamma+erv.kbetav+erv.kphi+erv.kpsi+erv.kmatheta);
d=erv.theta(erv.kbetar+erv.kgamma+erv.kbetav+erv.kphi+erv.kpsi+erv.kmatheta+1);
sigmav=erv.theta(erv.kbetar+erv.kgamma+erv.kbetav+erv.kphi+erv.kpsi+erv.kmatheta+2);
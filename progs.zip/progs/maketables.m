for n=1:N
    p_linear1(n,:,1)    = pvalue_linear{n,1}(1,:);
    p_nonlinear1(n,:,1) = pvalue_nonlinear{n,1}(1,:);
    p_linear1(n,:,2)    = pvalue_linear{n,1}(5,:);
    p_nonlinear1(n,:,2) = pvalue_nonlinear{n,1}(5,:);
    p_linear1(n,:,3)    = pvalue_linear{n,1}(10,:);
    p_nonlinear1(n,:,3) = pvalue_nonlinear{n,1}(10,:);
    
    p_linear2(n,:,1)    = pvalue_linear{n,2}(1,:);
    p_nonlinear2(n,:,1) = pvalue_nonlinear{n,2}(1,:);
    p_linear2(n,:,2)    = pvalue_linear{n,2}(5,:);
    p_nonlinear2(n,:,2) = pvalue_nonlinear{n,2}(5,:);
    p_linear2(n,:,3)    = pvalue_linear{n,2}(10,:);
    p_nonlinear2(n,:,3) = pvalue_nonlinear{n,2}(10,:);
    
    p_linear3(n,:,1)    = pvalue_linear{n,3}(1,:);
    p_nonlinear3(n,:,1) = pvalue_nonlinear{n,3}(1,:);
    p_linear3(n,:,2)    = pvalue_linear{n,3}(5,:);
    p_nonlinear3(n,:,2) = pvalue_nonlinear{n,3}(5,:);
    p_linear3(n,:,3)    = pvalue_linear{n,3}(10,:);
    p_nonlinear3(n,:,3) = pvalue_nonlinear{n,3}(10,:);
    
    p_linear4(n,:,1)    = pvalue_linear{n,4}(1,:);
    p_nonlinear4(n,:,1) = pvalue_nonlinear{n,4}(1,:);
    p_linear4(n,:,2)    = pvalue_linear{n,4}(5,:);
    p_nonlinear4(n,:,2) = pvalue_nonlinear{n,4}(5,:);
    p_linear4(n,:,3)    = pvalue_linear{n,4}(10,:);
    p_nonlinear4(n,:,3) = pvalue_nonlinear{n,4}(10,:);
    
    p_msc1(n,:,1) = PVALSR{n,1,1}(1:3)';
    p_msc1(n,:,2) = PVALSR{n,1,2}(1:3)';
    p_msc1(n,:,3) = PVALSR{n,1,3}(1:3)';
    
    p_msc2(n,:,1) = PVALSR{n,2,1}(1:3)';
    p_msc2(n,:,2) = PVALSR{n,2,2}(1:3)';
    p_msc2(n,:,3) = PVALSR{n,2,3}(1:3)';
    
    p_msc3(n,:,1) = PVALSR{n,3,1}(1:3)';
    p_msc3(n,:,2) = PVALSR{n,3,2}(1:3)';
    p_msc3(n,:,3) = PVALSR{n,3,3}(1:3)';
    
    p_msc4(n,:,1) = PVALSR{n,4,1}(1:3)';
    p_msc4(n,:,2) = PVALSR{n,4,2}(1:3)';
    p_msc4(n,:,3) = PVALSR{n,4,3}(1:3)';
end

TABLE_RMSE_11 =[A1(:,1,1) B1(:,1,1) p_linear1(:,1,1) p_nonlinear1(:,1,1) ...
               A1(:,2,1) B1(:,2,1) p_linear1(:,2,1) p_nonlinear1(:,2,1)  ...
               A1(:,3,1) B1(:,3,1) p_linear1(:,3,1) p_nonlinear1(:,3,1) ];
           
TABLE_RMSE_21 =[A2(:,1,1) B2(:,1,1) p_linear2(:,1,1) p_nonlinear2(:,1,1) ...
               A2(:,2,1) B2(:,2,1) p_linear2(:,2,1) p_nonlinear2(:,2,1)  ...
               A2(:,3,1) B2(:,3,1) p_linear2(:,3,1) p_nonlinear2(:,3,1) ];

TABLE_RMSE_31 =[A3(:,1,1) B3(:,1,1) p_linear3(:,1,1) p_nonlinear3(:,1,1)  ...
               A3(:,2,1) B3(:,2,1) p_linear3(:,2,1) p_nonlinear3(:,2,1)  ...
               A3(:,3,1) B3(:,3,1) p_linear3(:,3,1) p_nonlinear3(:,3,1) ];

TABLE_RMSE_41 =[A4(:,1,1) B4(:,1,1) p_linear4(:,1,1) p_nonlinear4(:,1,1) ...
               A4(:,2,1) B4(:,2,1) p_linear4(:,2,1) p_nonlinear4(:,2,1)  ...
               A4(:,3,1) B4(:,3,1) p_linear4(:,3,1) p_nonlinear4(:,3,1) ];
           
fprintf('%2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f &%2.3f && %2.3f & %2.3f & %2.3f & %2.3f  \n',TABLE_RMSE_41') 
fprintf('\n\n\n\n');
%fprintf('%2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f \n',TABLE_RMSE_2')
%fprintf('\n\n\n\n');
%fprintf('%2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f \n',TABLE_RMSE_3')
%fprintf('\n\n\n\n');
%fprintf('%2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f \n',TABLE_RMSE_4')

TABLE_RMSE_12 =[A1(:,1,2) B1(:,1,2) p_linear1(:,1,2) p_nonlinear1(:,1,2) ...
               A1(:,2,2) B1(:,2,2) p_linear1(:,2,2) p_nonlinear1(:,2,2)  ...
               A1(:,3,2) B1(:,3,2) p_linear1(:,3,2) p_nonlinear1(:,3,2) ];
           
TABLE_RMSE_22 =[A2(:,1,2) B2(:,1,2) p_linear2(:,1,2) p_nonlinear2(:,1,2) ...
               A2(:,2,2) B2(:,2,2) p_linear2(:,2,2) p_nonlinear2(:,2,2) ...
               A2(:,3,2) B2(:,3,2) p_linear2(:,3,2) p_nonlinear2(:,3,2) ];

TABLE_RMSE_32 =[A3(:,1,2) B3(:,1,2) p_linear3(:,1,2) p_nonlinear3(:,1,2)...
               A3(:,2,2) B3(:,2,2) p_linear3(:,2,2) p_nonlinear3(:,2,2) ...
               A3(:,3,2) B3(:,3,2) p_linear3(:,3,2) p_nonlinear3(:,3,2)];

TABLE_RMSE_42 =[A4(:,1,2) B4(:,1,2) p_linear4(:,1,2) p_nonlinear4(:,1,2)...
               A4(:,2,2) B4(:,2,2) p_linear4(:,2,2) p_nonlinear4(:,2,2) ...
               A4(:,3,2) B4(:,3,2) p_linear4(:,3,2) p_nonlinear4(:,3,2)];
           
fprintf('%2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f &%2.3f && %2.3f & %2.3f & %2.3f & %2.3f  \n',TABLE_RMSE_42')  
fprintf('\n\n\n\n');
%fprintf('%2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f \n',TABLE_RMSE_2')
%fprintf('\n\n\n\n');
%fprintf('%2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f \n',TABLE_RMSE_3')
%fprintf('\n\n\n\n');
%fprintf('%2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f \n',TABLE_RMSE_4')


TABLE_RMSE_13 =[A1(:,1,3) B1(:,1,3) p_linear1(:,1,3) p_nonlinear1(:,1,3) ...
                A1(:,2,3) B1(:,2,3) p_linear1(:,2,3) p_nonlinear1(:,2,3) ...
                A1(:,3,3) B1(:,3,3) p_linear1(:,3,3) p_nonlinear1(:,3,3)];
           
TABLE_RMSE_23 =[A2(:,1,3) B2(:,1,3) p_linear2(:,1,3) p_nonlinear2(:,1,3) ...
                A2(:,2,3) B2(:,2,3) p_linear2(:,2,3) p_nonlinear2(:,2,3) ...
                A2(:,3,3) B2(:,3,3) p_linear2(:,3,3) p_nonlinear2(:,3,3)];

TABLE_RMSE_33 =[A3(:,1,3) B3(:,1,3) p_linear3(:,1,3) p_nonlinear3(:,1,3) ...
                A3(:,2,3) B3(:,2,3) p_linear3(:,2,3) p_nonlinear3(:,2,3) ...
                A3(:,3,3) B3(:,3,3) p_linear3(:,3,3) p_nonlinear3(:,3,3)];

TABLE_RMSE_43 =[A4(:,1,3) B4(:,1,3) p_linear4(:,1,3) p_nonlinear4(:,1,3) ...
                A4(:,2,3) B4(:,2,3) p_linear4(:,2,3) p_nonlinear4(:,2,3) ...
                A4(:,3,3) B4(:,3,3) p_linear4(:,3,3) p_nonlinear4(:,3,3) ];
           
fprintf('%2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f &%2.3f && %2.3f & %2.3f & %2.3f & %2.3f  \n',TABLE_RMSE_43') 
fprintf('\n\n\n\n');
%fprintf('%2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f \n',TABLE_RMSE_2')
%fprintf('\n\n\n\n');
%fprintf('%2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f \n',TABLE_RMSE_3')
%fprintf('\n\n\n\n');
%fprintf('%2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f && %2.3f & %2.3f & %2.3f & %2.3f & %2.3f \n',TABLE_RMSE_4')
           
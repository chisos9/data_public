function y = prevfracfilter(x,d,trunc)

T =length(x);

j   = (1:trunc-1)';
psi = [0;gamma(j-d)./(gamma(-d)*gamma(j+1))];

z = zeros(T-trunc,trunc);
w = zeros(trunc,trunc);
t0 = trunc+1;
for i=0:trunc-1,
    z(:,i+1) = x(t0-i:T-i);
    w(trunc-i,1:trunc-i) = x(trunc-i:-1:1);
end
y = -[w;z]*psi;
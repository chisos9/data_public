function f = siglog(x)

f = 1./(1+exp(-x));
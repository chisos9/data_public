function gz = g_logistic_regime(z,gamma)

gz=1./(1+exp(-gamma(1)*(z-gamma(2))));
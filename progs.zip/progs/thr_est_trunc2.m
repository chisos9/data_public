%qhat = thr_est(dat,names,yi,xi,qi,h)

%The inputs are:
%  dat     = data matrix (nxk)
%  names   = variable names (kx1), corresponding to dat matrix

%MATLAB: names is cell array of strings, e.g. name = {'name1' 'name2' 'name3'}

%  yi      = index of dependent (y) variable, e.g.: yi = 1
%  xi      = indexes of independent (x) variables, e.g.: xi = 2|3
%  qi      = index of threshold (q) variable, e.g.: qi = 4;
%  h       = heteroskedasticity indicator
%            Set h=0 to impose homoskedasticity assumption
%            Set h=1 to use White-correction for heteroskedasticity


%Output:
%  qhat    = LS estimate of threshold

%The remaining outputs are printed to the screen.

%Notes:  
%  (1)  Do not include a constant in the independent variables;
%       the program automatically adds an intercept to the regression.
%
%  (2)  There are three other control parameters, governing the choice
%       of confidence level, the nonparametric method used to compute
%       the nuisance parameter in the event of heteroskedastic, and 
%       whether to print the graph of the likelihood.  These controls
%       are listed at the beginning of the procedure code.
%
%  (3)  The program includes code to produce a graph.
%       This requires that the pgraph library is active.
%       Thus, the command "library pgraph" must have been issued
%       previously in the GAUSS session.
%       If this is a problem, delete the lines between
%          "if _graph==1;"  and  "endif;"



%Example:
%If the nxk matrix "dat" contains the dependent variable in the first
%column, the independent variables in the second through tenth columns,
%and the threshold variable in the fifth.  If the error is homoskedastic:

%    xi = 2|3|4|5|6|7|8|9|10;
%    qhat = thr_est(dat,1,xi,5,0);

%while if the error is (possibly)heteroskedatic, 
%replace the second line with

%    qhat = thr_est(dat,1,xi,5,1);


%*******************************************************************/

function [qhat lr] = thr_est_trunc2(dat,yi,xi,qi,h)


% Control Parameters, can be modified if desired  @

conf1 = .95;  %@ Confidence Level for Confidence Regions  @
conf2 = .8;   %@ Confidence Level for first step of two-step
              %   Confidence Regions for regression parameters @
nonpar = 2;   %@ Indicator for non-parametric method used to
              %   estimate nuisance scale in the presence of
              %   heteroskedasticity (only relevant if h=1).
              %   Set _nonpar=1  to estimate regressions using
              %   a quadratic.
              %   Set _nonpar=2  to estimate regressions using
              %   an Epanechnikov kernel with automatic bandwidth. @

graph  = 0;   %@ Set _graph=1 for the program to produce the graph
              %   of the concentrated likelihood in gamma.
              %   Set _graph=0 to not view the graph.             @


if (h ~= 0) && (h ~= 1)
    disp(['You have entered h = ' h]);
    disp('This number must be either 0 (homoskedastic case) or 1 (heteoskedastic)');
    disp('The program will either crash or produce invalid results');
end
if  (nonpar ~= 1) && ( nonpar ~= 2) && (h==1)
    disp(['You have entered  nonpar = '  nonpar]);
    disp('This number should be either 1 (quadratic regression)');
    disp('or 2 (kernel regression)');
    disp('The program will employ the quadratic regression method');
end

n = size(dat,1);
q = dat(:,qi);
[q,qs]=sort(q);
y = dat(qs,yi);
x = [ones(n,1) dat(qs,xi)];
k = size(x,2);

mi = inv(x'*x);
beta = mi*(x'*y);
e=y-x*beta;
ee=e'*e;
sig = ee/(n-k);
xe = x.*(e*ones(1,k));
if h==0
  se = sqrt(diag(mi)*sig);
else
  se = sqrt(diag(mi*xe'*xe*mi));
end
vy = sum((y - mean(y)).^2);
r2 = 1-ee/vy;

qs = unique(q);
qn = size(qs,1);
sn = zeros(qn,1);

irb = zeros(n,1);
mm = zeros(k,k);
sume = zeros(k,1);
ci = 0;

e1=zeros(qn,1);
yy=y'*y;
r=1; 
while r<=qn
    if (r<=5) || (r==qn-5)
        sn(r)=yy;
    else
        irf = (q >= qs(r));
        X=[x x.*repmat(irf,1,size(x,2))];
        e1=y - X*(pinv(X'*X)*X'*y);
        sn(r) = e1'*e1;
    end
    r=r+1;
end
  

[smin,rmin]=min(sn);
qhat=qs(rmin);
sighat=smin/n;
lr  = (sn-smin)/sighat;
     


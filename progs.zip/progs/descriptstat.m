names = strvcat('AA','AXP','BA','BAC','CAT','CSCO','CVX','DD','DIS','GE','HD','HPQ','IBM','INTC','JNJ','JPM','KFT','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','T','UTX','VZ','WMT','XOM');

k = 3;

for n = 1:30;   
    data = load(strcat('..\data\',names(n,:),'.txt'));
    date = data(:,1);   
    if n==7
        aux  = find(date==20011010);
    elseif n==17
        aux  = find(date==20010613);
    else
        aux  = find(date==20000103);
    end
    data = data(aux:end,:);
    date = data(:,1);
            
    r{n}      = 100*data(:,end);
    y{n}      = data(:,k+2);
    logy{n}   = log(y{n});
    stdret{n} = r{n}./sqrt(y{n});
    T(n)      = size(logy{n},1);       
        
    s(n,1) = T(n);
    s(n,2) = nanmean(logy{n});
    s(n,3) = nanstd(logy{n});
    s(n,4) = skewness(logy{n});
    s(n,5) = kurtosis(logy{n});
    
    [~,s(n,6)] = adtest(logy{n});
    [~,s(n,7)] = chi2gof(logy{n});
    [~,s(n,8)] = lillietest(logy{n});
    [~,s(n,9)] = jbtest(logy{n});
    [~,s(n,10)]= kstest((logy{n}- s(n,2))/s(n,3));   
end
function [d,c,gamma,omega] = getparfi(psi,m,nQ)

d     = psi(1);
c     = psi(2:m+1);
gamma = psi(m+2:2*m+1);
if nQ>1
    omega = reshape(psi(2*m+2:end),nQ,m);
else
    omega = ones(1,m);
end



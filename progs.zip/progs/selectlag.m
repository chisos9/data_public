function selectp=selectlag(y,X,critselect,maxp,T)

% selection criteria
% ------------------
critselect = 1; % SBIC
result=[];
    
for i=1:maxp,
    Xregress=[ones(T,1) X(:,2:i+1)];
    [AIC,SBIC]=ols(Xregress,y,T);
    summary(1,i)=1;
    if critselect==1
        summary(1,maxp+1)=AIC;
    else
        summary(1,maxp+1)=SBIC;
    end
    result=[result;summary];
end

summary=zeros(1,maxp+1);
Xregress=ones(T,1);
[AIC,SBIC]=ols(Xregress,y,T);
if critselect==1
    summary(1,maxp+1)=AIC;
else
    summary(1,maxp+1)=SBIC;
end
result=[result;summary];

imin = find(result(:,maxp+1)==min(result(:,maxp+1)));
j    = max(find(result(imin,1:maxp)==1));
j    = j(1);

selectset=1:maxp;

selectp = selectset(j);

%--------------------------------------------------------------------------
% Data Construction
%--------------------------------------------------------------------------

function make_data(T,seed)



MC = 1;
T = 2000;

flag_nonlin = 0;
flag_outliers = 0;
flag_vol = 0;
flag_sb = 0;
flag_dist = 0;

df_error = [];

options.const = 0;
options.trunc = 100;

d_mc = zeros(MC,1);
alpha_mc = zeros(MC,1);
for i=1:MC
    data = genarfima([1;-0.8],1,[],[],[],[],1,0.4,...
                 flag_dist,flag_vol,flag_outliers,...
                 flag_nonlin,flag_sb,...
                 T);

             
    output = estimation_ari(data.variance,1,T,options);
    d_mc(i,1)=output.d;
    alpha_mc(i,1)=output.alpha;
end
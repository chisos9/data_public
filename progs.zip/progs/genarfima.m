function data = genarfima(phi,theta,alpha,lambda,gamma,c,omega,sigma,d,...
                          flag_dist,flag_vol,flag_outliers,...
                          flag_nonlin,flag_sb,T,df_error,J)

M  = T + 500;
t0 = 101;

P = size(phi,1)-1;
H = size(phi,2)-1;
Q = size(theta,1);

trunc = 100;

z = normrnd(0,1,M,1);
z = (z - mean(z))/std(z);

%--------------------------------------------------------------------------
% Selection of the distribution of the errors
%--------------------------------------------------------------------------
if flag_dist==0
    e = normrnd(0,1,M,1);    % Normal
elseif flag_dist==1
    e = gevrnd(0,1,0,M,1);   % Generalized Extreme Value
elseif flag_dist==2
    e = evrnd(0,1,M,1);      % Extreme value
elseif flag_dist==3
    e = trnd(df_error,M,1);  % t-distribution with df_error degrees of freedom
end
e = (e - mean(e))/std(e);

%--------------------------------------------------------------------------
% Unconditional variance of the residuals
%--------------------------------------------------------------------------
if flag_vol==0
    h = ones(M,1)*sigma^2;    % homoskedastic model
else
    h = ones(M,1)*(alpha(1)/(1-alpha(2)-alpha(3)));     % GARCH(1,1) errors
end

%--------------------------------------------------------------------------
% Outliers (Jumps)
%--------------------------------------------------------------------------
if flag_outliers==0
    k = zeros(M,1);
else
    k = lambda(1)*poissrnd(lambda(2),M,1);  % Lambda is the jump frequency
end

%--------------------------------------------------------------------------
% Initial condition
%--------------------------------------------------------------------------
u  = (h.^(0.5)).*e;
mu = phi(1,1)/(1-sum(phi(2:end,1)));
v = filter([1;theta],[1;-phi(2:end,1)],u) + mu; 
if d ~= 0
    y = invfracfilter(v,d,trunc);
else
    y = v;
end
% Returns
r = exp(y).*z;

% Transiton Variable
if isempty(J)==0
    if J>0
        q = zeros(M,J);
        for i = 0:J-1
            q(J:end,i+1) = r(J-i:M-i); 
        end
    else
        q = r;
    end
else
    q = [];
end

% Transition function
f = zeros(M,H);

%--------------------------------------------------------------------------
% Vol of Vol model
%--------------------------------------------------------------------------
if flag_vol==1
    % GARCH errors
    for t=t0:M
        h(t) = alpha(1) + alpha(2)*h(t-1)+alpha(3)*u(t-1)^2;
        u(t) = (h(t)^(0.5))*e(t);
    end
    % Linear model
    if flag_nonlin==0
        v = filter([1;theta],[1;-phi(2:end,1)],u) + mu;
        if d ~= 0
            y = invfracfilter(v,d,trunc);
        else
            y = v;
        end
        r = exp(y).*z;
    end
end  
    
if flag_nonlin==1
    theta = [1;theta];
    for t=t0:M-1
        if flag_sb==0
            f(t+1,:) = siglog(gamma'.*(q(t,:)*omega' - c'))';
        else
            f(t+1,:) = siglog(gamma.*(repmat(t+1,H,1)- T*c - 500))';      
        end
        v(t+1) = phi(1,1) + phi(1,2:end)*f(t+1,:)' + ...
                 phi(2:end,1)'*v(t:-1:t-P+1)+...
                 sum(sum(repmat(v(t:-1:t-P+1),1,H).*repmat(f(t+1,:),P,1).*phi(2:end,2:end)))+ ...
                 theta'*u(t+1:-1:t+1-Q) + k(t+1);
        if d ~= 0
            y = invfracfilter(v,d,trunc);
        else
            y = v;
        end
        r = exp(y).*z;
        if J>0
            q = zeros(M,J);
            for i = 0:J-1
                q(J:end,i+1) = r(J-i:M-i); 
            end
        else
            q = r;
        end
    end
end

aux = T+500;
data.volatility = y(501:aux);
%data.vov        = sqrt(h(501:aux));
data.mean       = r(501:aux);
%data.lagmean    = r(500:aux-1);
%data.jumps      = k(501:aux);
%data.error      = u(501:aux);
%data.stderror   = e(501:aux);
%data.short      = v(501:aux);
%if flag_nonlin==0
%    data.transfunc  = [];
%    data.transvar   = [];
%else
%    if flag_sb==0
%        data.transfunc  = f(501:aux,:);
%        data.transvar   = q(500:T+499,:);
%    else
%        data.transfunc  = f(501:aux,:);
%        data.transvar   = (1:T)';
%    end
%end
%if length(omega)>1
%    keyboard
%end
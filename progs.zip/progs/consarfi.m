function [cons,cons_eq,g_cons,g_cons_eq] = consarfi(psi,~,~,~,m,~,nQ,~,~)

[~,~,~,omega] = getparfi(psi,m,nQ);

numpar = size(psi,1);

cons_eq = 1 - sum(omega.*omega)';
cons = [];
g_cons = [];

g_cons_eq = zeros(numpar,m);

for i = 1:m
    g_cons_eq(1+2*m+(i-1)*nQ+1:1+2*m+(i-1)*nQ+nQ,i) = -2*omega(:,i);
end
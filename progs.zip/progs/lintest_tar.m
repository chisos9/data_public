function isLinear = lintest_tar(y,X,q)

sig = 0.80:0.01:0.99;
sig = 1-sig;

[ftest, pv] = thr_test([y,X,q],1,[3:size(X,2)+1],size(X,2)+2,.15,1000);

isLinear = pv>sig';

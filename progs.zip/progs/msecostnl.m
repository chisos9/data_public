function [f,G] = msecostnl(psi,y,q,p,m,T,nQ,const,trunc)

% Input variables:
% ---------------
% psi:  parameter vector
% y:    dependent variable
% p:    AR order    

% Get parameters
[d,c,gamma,omega] = getparfi(psi,m,nQ);

% construct filtered series
v = fracfilter(y,d,trunc);

% construct lagged series
pnew = p + const;
V = zeros(T-p,pnew*(m+1));
Y = zeros(T-p,pnew*(m+1));
if const == 1
    V(:,1) = ones(T-p,1);
    Y(:,1) = ones(T-p,1);
end
for i=1:p
    V(:,i + const) = v(p-i+1:T-i);
    Y(:,i + const) = y(p-i+1:T-i);
end
v = v(p+1:end);
y = y(p+1:end);
q = q(p+1:end,:);

fX = zeros(T-p,m);
for i = 1:m
    transition               = gamma(i)*(q*omega(:,i) - c(i));
    fX(:,i)                  = siglog(transition);
    V(:,i*pnew+1:(i+1)*pnew) = repmat(fX(:,i),1,pnew).*V(:,1:pnew);
    Y(:,i*pnew+1:(i+1)*pnew) = repmat(fX(:,i),1,pnew).*Y(:,1:pnew);
end
VV = V'*V;
if rank(VV)<size(VV,2)
    theta = pinv(VV)*V'*v;
else
    theta = VV\(V'*v);
end
phi   = reshape(theta,pnew,m+1);
vhat  = V(:,1:pnew)*phi(:,1) + V(:,pnew+1:end)*vec(phi(:,2:end));
z     = y - Y(:,1:pnew)*phi(:,1) - Y(:,pnew+1:end)*vec(phi(:,2:end));
u     = v - vhat;

f = u'*u/T;

% restrictions on c and gamma
s = q*omega;
lb_c = prctile(s,1)';
ub_c = prctile(s,99)';

if sum(c<lb_c)>0 || sum(c>ub_c)>0 || sum(gamma<=0)>0
    f = 99999999999999999999999999999999999999999999999999999999999999999;
end

%--------------------------------------------------------------------------
% Gradient Computation
%--------------------------------------------------------------------------
dfX  = dsiglog(fX);

aux = zeros(T-p-trunc,1);
aux2 = zeros(trunc,trunc-1);

for j=1:trunc
    i=0:j-1;
    aux(:,j) = ((((-1)^j)/factorial(j))*sum(1./(d-i))*prod(d-i))*z(trunc-j+1:T-p-j);
    if j > 1
        trunc2 = j-1;
        for k=1:trunc2
            l=0:k-1;
            aux2(j,k) = ((((-1)^k)/factorial(k))*sum(1./(d-l))*prod(d-l))*z(j-k);
        end
    end
end

if d == 0
    Gd = 0;
else
    Gd = 2*u'*[sum(aux2,2);sum(aux,2)]/T;
end

if nQ>1
    Gomega = ones(m*nQ,1);
    for i=1:nQ
        Gomega((i-1)*m+1:i*m,1) = 2*u'*((V(:,1:pnew)*phi(:,2:end)).*...
            (repmat(q(:,i),1,m).*dfX).*repmat(gamma',T-p,1))/T;
    end
else
    Gomega = [];
end

Gc     =  2*u'*((V(:,1:pnew)*phi(:,2:end)).*dfX.*repmat(gamma',T-p,1))/T;
Ggamma =  -2*u'*((V(:,1:pnew)*phi(:,2:end)).*dfX.*(q*omega-repmat(c',T-p,1)))/T;

G = [Gd;Gc';Ggamma';Gomega];
function e = invfilter(u,d,T)

fi = zeros(1,T);
v  = zeros(T,1);
e  = zeros(T,1);

fi(1) = d/(1-d);
v(1) = gamma(-2*d+1)/(gamma(-d+1)^2);

e(1) = (v(1)^.5)*u(1);
auxe = zeros(1,T);

for j = 1:T-1
  fi1 = fi;
  fi = zeros(1,T);
  fi(j+1) = d/(j+1-d);
  v(j+1) = v(j)*(1-fi1(j)^2);
  i = 1:j;
  fi(i) = fi1(i) - fi(j+1).*fi1((j+1)*ones(size(i))-i);
  auxe = [e(j) auxe(1:T-1)];
  e(j+1,1) = auxe*fi1' + (v(j+1)^.5)*u(j+1);
end


function [rejectH0,pvalue,LM,rejectH0_robust,pvalue_robust,LM_robust]=testnl(v,V,u,z,s,fX,d,phi,gamma,c,M,p,T,sig)

%sigma2_u = var(u);
%q_0 = calcgrad(V,u,z,s,fX,d,phi,gamma,c,M,p,T);

x_a = zeros(T-p,3*p);
for i=1:3
    x_a(:,(i-1)*p+1:i*p) = V(:,1:p).*repmat((s.^i),1,p);
end
%q_a = repmat((u./sigma2_u),1,size(x_a,2)).*x_a;

iota = ones(T-p,1);
%Q    = [q_0 q_a];

% standard test (original version)
%LM = (iota'*Q)*inv(Q'*Q)*(Q'*iota);

crit     = chi2inv(sig,3*p);
%rejectH0 = LM > crit;
%pvalue   = 1-chi2cdf(LM,3*p);

% standard test (auxiliary regression version)
x_0 = calcreg(V,z,s,fX,d,phi,gamma,c,M,p,T);

lambda  = inv(x_0'*x_0)*x_0'*u;
u_tilde = u - x_0*lambda;
SSE_0   = sumsqr(u_tilde);

X      = [x_0 x_a];
lambda = inv(X'*X)*X'*u_tilde;
e      = u_tilde - X*lambda;
SSE_a  = sumsqr(e);

LM = T*(SSE_0-SSE_a)/(SSE_0);
rejectH0 = LM > crit;
pvalue   = 1-chi2cdf(LM,3*p);

% robust test
beta = pinv(x_0'*x_0)*x_0'*x_a;
r    = x_a-x_0*beta;
aux  = repmat(u_tilde,1,size(x_a,2)).*r;
beta = pinv(aux'*aux)*aux'*iota;
e    = iota - aux*beta;
SSE  = sumsqr(e);

LM_robust       = T - SSE;
rejectH0_robust = LM_robust > crit;
pvalue_robust   = 1-chi2cdf(LM_robust,3*p);

function X = vec(A)
	[m,n] = size(A);
	X     = reshape(A,m*n,1);
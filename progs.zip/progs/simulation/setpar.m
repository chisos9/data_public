function PSI = setpar(d,gamma,c)

PSI = [d;gamma;c];
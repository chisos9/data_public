function AL = applik(paramset,Y,p,q);

% Evaluates the function to be minimised using the Whittle approach
% in the time series Y. Paramset is a line vectors with the
% parameters of AR, d and MA polynomials, in the format:
% [fi1 ... fip d teta1 ... tetaq]   (ARFIMA)

fi = [1 -paramset(1:p)];
d = paramset(p+1);
teta = [1 -paramset(p+2:p+q+1)];
n = max(size(Y));
w = 2*pi/n:2*pi/n:floor((n-1)/2)*2*pi/n;
w = w';
auxperi=fft(Y);
peri = (abs(auxperi).^2)/(2*pi*n);
peri = peri(2:(1+floor((n-1)/2)));

pp = 0:p;
qq = 0:q;

auxAR2 = 1;
auxMA2 = 1;
if p > 0
   auxAR = (ones(size(w))*fi).*(exp(-i.*w*pp));
   auxAR = auxAR';
   auxAR2 = (abs(sum(auxAR))).^2;
end;
if q > 0
   auxMA = (ones(size(w))*teta).*(exp(-i.*w*qq));
   auxMA = auxMA';
   auxMA2 = (abs(sum(auxMA))).^2;
end;
auxd = (2.*sin(w'./2)).^(-2*d);       
funlik = auxMA2.*auxd./auxAR2; 
const = (2/n)*sum(peri./funlik); 
AL = sum(peri./(funlik*const)+log(funlik*const));
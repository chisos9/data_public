function [y,s,f] = nlarfima_old(p,d,M,T,phi,phi0,theta,gamma,c,sigma,type)

% Hyperparameters
% ---------------
% p:    autoregressive order
% d:    order of fractional difference
% M:    number of transition functions
% T:    number of observations

% Parameters
% ----------
% gamma:    smoothness parameter
% c:        location parameter
% phi:      autoregressive parameters (p x (M+1))
% theta:    moving average parameters (q x 1)
% sigma:    error standard deviation

% Variables
% ---------
% type: type of transition variable

% Error term
u = sigma*randn(T+500,1);
u = filter(theta,1,u); % ---> generates MA errors 

% Long-memory errors: (1-L)^{-d}u_t
e = invfilter(u,d,T+500);

f      = zeros(T+500,M);
F      = zeros(T+500,M+1);
F(:,1) = ones(T+500,1);
PHI    = zeros(T+500,p);
PHI0   = zeros(T+500,p);

if type == 1    % linear time trend
    s = -499:T;
    s = s'/T;
    
    % Start recursion
    for m=1:M
        f(:,m)=siglog(gamma(m)*(s-c(m)));
    end
    F(:,2:end) = f;

    for i=1:p
        PHI(:,i) = sum(repmat(phi(i,:),T+500,1).*F,2);
    end
    PHI0(:,1) = sum(repmat(phi0,T+500,1).*F,2);

    y = zeros(p,1);
    for t=p+1:T+500
        y(t,1) = PHI0(t,:)+PHI(t,:)*y(t-1:-1:t-p,1)+e(t,1);
    end
    y = y(501:end,1);
    s = s(501:end,1);
    f = f(501:end,:);
end
keyboard


function y = fractint_filter_d(x,d,trunc)

T=length(x);
y=zeros(T,1);
for t=1:trunc
    tvec=(1:t)';
    factvec=factorial(tvec-1);
    pvec=[1;d-(tvec(1:t-1)-1)];
    alt=(-1).^(tvec-1);
    fdcoeff=alt.*cumprod(pvec)./factvec;
    y(t)=fdcoeff'*flipud(x(1:t));
end
tvec=(1:trunc)';
factvec=factorial(tvec-1);
pvec=[1;d-(tvec(1:trunc-1)-1)];
alt=(-1).^(tvec-1);
fdcoeff=alt.*cumprod(pvec)./factvec;
for t=trunc+1:T
    y(t)=fdcoeff'*flipud(x(t-trunc+1:t));
end
% Main settings
T = 1000;
p = 1;      % autoregressive order
d = 0;      % fractional difference parameter

M = 2;      % number of transitions

phi0 = [0.5 1 -1];
phi = [0.8 0 0];        % AR parameters
theta = 1;              % MA parameters (always set to 1, no MA)

gamma = [30;30];        % slope parameters
c = [.35;.65];          % location parameters
sigma = 0.5;            % error standard deviation

[y,s,f] = nlarfima_old(p,d,M,T,phi,phi0,theta,gamma,c,sigma,1);
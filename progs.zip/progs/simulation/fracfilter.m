function resid = fracfilter(y,d)

y = y';
Tam = length(y);

fi(1) = d/(1-d);
v(1) = 1;
resid(1) = y(1);

for j = 1:Tam-1
  fi2 = fi; 
  fi1 = fi;
  fi(j+1) = d/(j+1-d);
  v(j+1) = v(j)*(1-fi1(j)^2);
  resid(j+1) = (y(j+1) - rot90(rot90(y(1:j)))*fi2')/sqrt(v(j+1)); 
  i = 1:j;
  fi(i) = fi1(i) - fi(j+1).*fi1((j+1)*ones(size(i))-i);
end
resid = resid';



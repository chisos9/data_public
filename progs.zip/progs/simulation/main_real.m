% ************************
% Main Estimation Program
% ************************

load('..\..\data\data.txt');
numSeries = 23;

pmax  = 10;
const = 0;

for n = 1:numSeries
    disp(n)
    
    numtrade = data(:,3*n+6);
    RV       = data(:,3*n+7);
    ret      = data(:,3*n+8);
      
    % ---------------------------------------------------------------------
    % Find huge outliers and zero variances
    % ---------------------------------------------------------------------
    
    % Outliers in returns
    outindex = find(ret<=prctile(ret,.5));
    ret(outindex)=nan;
    ret(outindex)=nanmean(ret);
    outindex = find(ret>=prctile(ret,99.5));
    ret(outindex)=nan;
    ret(outindex)=nanmean(ret);
    
    % Outliers in volatility
    meanRV = filter(ones(10,1)/10,1,RV);
    stdRV = sqrt(filter(ones(10,1)/10,1,RV.^2));
    outbound = meanRV + 2*stdRV;
    
    outindex = find(RV>=outbound);
    RV(outindex)= meanRV(outindex);
    
    zeroindex = find(RV==0);
    RV(zeroindex) = RV(zeroindex-1);
    
    % ---------------------------------------------------------------------
    % ---------------------------------------------------------------------

    y = log(sqrt(RV));
    T = length(y);
    
    % ---------------------------------------------------------------------
    % Generate average volatility (HAR terms) and cumulated returns
    % ---------------------------------------------------------------------
    
    % horizon for cumulative returns
    retset = [1;5;10;22;66;252];
    Nret   = length(retset);
    
    % Compute cumulative returns
    X_ret = zeros(T,Nret-1);
    for i = 1:Nret
        b = ones(retset(i),1);
        X_ret(:,i) = filter(b,1,ret);
    end
            
    % HAR terms
    harset = [1;5;22];
    Nhar   = length(harset);
    pHAR   = max(harset);
      
    % build original regressors and dependent variables
    X_har = zeros(T,Nhar);
    for i=1:Nhar
        b = (1/harset(i))*ones(harset(i),1);
        X_har(:,i) = filter(b,1,y);
    end
    
    % ---------------------------------------------------------------------
    % ---------------------------------------------------------------------
    
    % ---------------------------------------------------------------------
    % Transition Variables
    % ---------------------------------------------------------------------
    aux = 1:T;
    aux = aux'/T;
    S = [aux X_ret X_har];
    
    % Determine in-sample period
    % --------------------------
    Tout = 600;
    T    = length(y) - Tout;
    yin  = y(1:T); 
    
    %----------------------------------------------------------------------
    % Estimation and Forecasting
    %----------------------------------------------------------------------
    
    % Linear estimation
    % -----------------
    p_linear = pestimation(yin,[],T,pmax,3,2);    
    [d_linear,phi_linear] = nlestimation(yin,[],T,0,p_linear,0);
   
    % Nonlinear estimation and forecasting
    % ------------------------------------
    s   = S(:,1);
    sin = s(1:T); 
    
    p_hat = pestimation(yin,sin,T,pmax,3,2);
    
    [d_hat,phi_hat,gamma_hat,c_hat,sigma_hat,M_hat,G_hat,ybar,...
    pvalue_linear,LM_linear,pvalue_robust_linear,LM_robust_linear,...
    pvalue,LM,pvalue_robust,LM_robust]= nlestimation(yin,sin,T,[],p_hat,1);

    yout = y(T-p_hat+1:end);
    sout = s(T-p_hat+1:end);
    
    yout_hat = nlprev(yout - ybar,sout,d_hat,phi_hat,gamma_hat,c_hat,M_hat,p_hat,Tout+p_hat,const) + ybar;
            
    % ---------------------------------------------------------------------
    % ---------------------------------------------------------------------
   
    save(strcat('\..\results\',num2str(n),'_linear_forecasting'));
end
    
function y = fractint_filter_invd(x,d,trunc)

T=length(x);
z=zeros(T,1);
for t=1:trunc
    tvec=(1:t)';
    factvec=factorial(tvec-1);
    pvec=[1;d+(tvec(1:t-1)-1)];
    fdcoeff=cumprod(pvec)./factvec;
    z(t)=fdcoeff'*flipud(x(1:t));
end
tvec=(1:trunc)';
factvec=factorial(tvec-1);
pvec=[1;d+(tvec(1:trunc-1)-1)];
fdcoeff=cumprod(pvec)./factvec;
for t=trunc+1:T
    z(t)=fdcoeff'*flipud(x(t-trunc+1:t));
end
y=z(trunc+1:T);
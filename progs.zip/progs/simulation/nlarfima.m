function [y,s,f] = nlarfima(p,d,M,T,phi,theta,gamma,c,sigma,type)

% Hyperparameters
% ---------------
% p:    autoregressive order
% d:    order of fractional difference
% M:    number of transition functions
% T:    number of observations

% Parameters
% ----------
% gamma:    smoothness parameter
% c:        location parameter
% phi:      autoregressive parameters (p x (M+1))
% theta:    moving average parameters (q x 1)
% sigma:    error standard deviation

% Variables
% ---------
% type: type of transition variable

% Error term
u = sigma*randn(T+500,1);
u = filter(theta,1,u); % ---> generates MA errors 
u = u - mean(u);

f      = zeros(T+500,M);
F      = zeros(T+500,M+1);
F(:,1) = ones(T+500,1);
PHI    = zeros(T+500,p);

if type == 1    % linear time trend
    s = -499:T;
    s = s'/T;
    
    % Start recursion
    for m=1:M
        f(:,m)=siglog(gamma(m)*(s-c(m)));
    end
    F(:,2:end) = f;

    for i=1:p
        PHI(:,i) = sum(repmat(phi(i,:),T+500,1).*F,2);
    end

    y = zeros(p,1);
    for t=p+1:T+500
        y(t,1) = PHI(t,:)*y(t-1:-1:t-p,1)+u(t,1);
    end
    %y = invfilter(y,d,T+500);
    if d>0
        y = fractint_filter_invd(y,d,100);
        y = y(401:end,1);
    else
        y=y(501:end);
    end
    s = s(501:end,1);
    f = f(501:end,:);
elseif type == 2 % past returns as transition variable
    y = zeros(p,1);
    r = sqrt(exp(y+0.001*randn))*randn;
    for t=p+1:T+500
        for m=1:M
            f(t,m)=siglog(gamma(m)*(r(t-1)-c(m)));
        end
        F(t,2:end) = f(t,:);
        for i=1:p
            PHI(t,i) = sum(phi(i,:).*F(t,:),2);
        end
        y(t,1) = PHI(t,:)*y(t-1:-1:t-p,1)+u(t,1);
        r(t,1) = sqrt(exp(y(t,1)+0.001*randn))*randn;
    end
    %y = invfilter(y,d,T+500);
    if d>0
        y = fractint_filter_invd(y,d,100);
        y = y(401:end,1);
    else
        y=y(501:end);
    end
    s = r(500:end-1);
    f = f(501:end,:);
elseif type == 3 % linear model
    y = zeros(p,1);
    for t=p+1:T+500
        y(t,1) = phi'*y(t-1:-1:t-p,1)+u(t,1);
    end
    %y = invfilter(y,d,T+500);
    if d>0
        y = fractint_filter_invd(y,d,100);
        y = y(401:end,1);
    else
        y=y(501:end);
    end
end
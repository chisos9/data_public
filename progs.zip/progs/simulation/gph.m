function d = gph(X,alfa);

% Estima o d de s�ries de mem�ria longa pelo m�todo GPH (log-periodograma)
% X = s�rie; n = N^alfa; N = tamanho da s�rie original;
% n = no. de pontos a serem usados na regress�o

% Leonardo Rocha Souza  17/08/99


[A,B] = size(X);
if (A>B)
   Tam = A;
else
   Tam = B;
   X = X';
end;

auxperi=fft(X);
peri=(abs(auxperi).^2)/Tam;
w=2*pi/Tam:2*pi/Tam:2*pi;
lperi=log(peri);
n = floor(Tam^(alfa));
w=w(1:n);
y(:,1)=ones(n,1);
y(:,2)=log((2*sin(w'/2)).^2);
lperi=lperi(2:n+1);

auxd=estima2(y,lperi);
d=-auxd(2);

function [fi, d, teta] = whittle(X,p,q);

% Estimates the ARFIMA(p,d,q) model of the series X using the Whittle approach

func = 'applik2';
pp = [zeros(1,p)];
qq = [zeros(1,q)];
Y0 = [pp 0 qq];
lbound = [-1.*ones(size(pp)) -0.5+eps -1.*ones(size(qq))];
ubound = [1*ones(size(pp)) 0.5-eps 1*ones(size(qq))]; 
options = optimset('display','off','diffmaxchange',0.02,'diffminchange',1E-6,'LineSearchType','cubicpoly');

Y = fmincon(func,Y0,[],[],[],[],lbound,ubound,[],options,X,p,q);

fi = Y(1:p);
d = Y(p+1);
teta = Y(p+2:p+q+1);
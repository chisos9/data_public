function [d,gamma,c] = getpar(PSI,M)

d     = PSI(1);
gamma = PSI(2:M+1);
c     = PSI(M+2:end);



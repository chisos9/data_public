% ************************
% Main Simulation Program
% ************************

Tset = [500 1000];  % number of observations
MC   = 1000;        % number of Monte Carlo replications
pmax = 6;           % maximum AR order
k    = 3;           % order of the polynomial expansion
IC   = 2;           % select p via BIC

N    = length(Tset);

% ************************************************************************
% Case A: Time is the transition variable
% ************************************************************************

% Main settings
p = 1;      % autoregressive order
d = 0;      % fractional difference parameter

M = 2;      % number of transitions

phi = [0.8 -0.4 0.4];   % AR parameters
theta = 1;              % MA parameters (always set to 1, no MA)

gamma = [30;30];        % slope parameters
c = [.35;.65];          % location parameters
sigma = 0.5;            % error standard deviation

for n = 1:N
    T = Tset(n);
    phi_hat               = zeros(p,M+1,MC);
    gamma_hat             = zeros(M,MC);
    gamma_initial         = zeros(M,MC);
    c_hat                 = zeros(M,MC);
    sigma_hat             = zeros(MC,1);
    d_hat                 = zeros(MC,1);
    M_hat                 = zeros(MC,1);
    p_hat                 = zeros(MC,1);
    sigma_hat_flex        = zeros(MC,1);
    d_hat_flex            = zeros(MC,1);
    ybar                  = zeros(MC,1);
    phi_hat_flex          = cell(MC,1);
    gamma_hat_flex        = cell(MC,1);
    c_hat_flex            = cell(MC,1);
    M_hat_robust          = zeros(MC,1);
    sigma_hat_flex_robust = zeros(MC,1);
    d_hat_flex_robust     = zeros(MC,1);
    ybar_robust           = zeros(MC,1);
    phi_hat_flex_robust   = cell(MC,1);
    gamma_hat_flex_robust = cell(MC,1);
    c_hat_flex_robust     = cell(MC,1);

    for i=1:MC
        disp(i)
        % Transition variable definition
        [y,s,f] = nlarfima(p,d,M,T,phi,theta,gamma,c,sigma,1);    % generate data
                        
        % estimation under fixed M and p
        [gamma_initial(:,i),d_hat(i,1),phi_hat(:,:,i),gamma_hat(:,i),c_hat(:,i),sigma_hat(i,1),ybar(i,1)]=...
            nlestimation(y,s,T,M,p);
   
        % estimation with estimated M and p
        %p_hat(i) = pestimation(y,s,T,pmax,3,2);
        %[d_hat_flex(i,1),phi_hat_flex{i},gamma_hat_flex{i},c_hat_flex{i},sigma_hat_flex(:,1),M_hat(i,1)]=...
        %    nlestimation(y,s,T,[],p_hat(i),0);
       
        %[d_hat_flex_robust(i,1),phi_hat_flex_robust{i},gamma_hat_flex_robust{i},c_hat_flex_robust{i},sigma_hat_flex_robust(:,1),M_hat_robust(i,1)]=...
        %    nlestimation(y,s,T,[],p_hat(i),1);
    end
    filename = strcat('simulation_time_',num2str(n));
    save(filename)
end

% % ************************************************************************
% % Case B: Linear Model
% % ************************************************************************
 
% Main settings
p = 1;      % autoregressive order
d = 0.4;    % fractional difference parameter
 
M = 0;      % number of transitions
 
phi   = 0.8;  % AR parameters
theta = 1;    % MA parameters (always set to 1, no MA)
sigma = 0.5;  % error standard deviation
 
for n = 1:N
    T = Tset(n);
    M_hat                 = zeros(MC,1);
    p_hat                 = zeros(MC,1);
    sigma_hat_flex        = zeros(MC,1);
    d_hat_flex            = zeros(MC,1);
    ybar                  = zeros(MC,1);
    phi_hat_flex          = cell(MC,1);
    gamma_hat_flex        = cell(MC,1);
    c_hat_flex            = cell(MC,1);
    M_hat_robust          = zeros(MC,1);
    sigma_hat_flex_robust = zeros(MC,1);
    d_hat_flex_robust     = zeros(MC,1);
    ybar_robust           = zeros(MC,1);
    phi_hat_flex_robust   = cell(MC,1);
    gamma_hat_flex_robust = cell(MC,1);
    c_hat_flex_robust     = cell(MC,1);

    for i=1:MC
        disp(i)
        % Transition variable definition
        y = nlarfima(p,d,M,T,phi,theta,[],[],sigma,3);    % generate data
         
        % estimation under fixed M and p
        [d_hat(i,1),phi_hat(:,:,i),gamma_hat(:,i),c_hat(:,i),sigma_hat(i,1),ybar(i,1)]=...
            nlestimation(y,[],T,M,p);
                         
        % estimation with estimated M and p (assuming time is the
%         % transition variable)
%         s = 1:T;
%         s = s'/T;
%         p_hat(i) = pestimation(y,[],T,pmax,3,2);
%         [d_hat_flex(i,1),phi_hat_flex{i},gamma_hat_flex{i},c_hat_flex{i},sigma_hat_flex(:,1),M_hat(i,1)]=...
%             nlestimation(y,s,T,[],p_hat(i),0);
%        
%         [d_hat_flex_robust(i,1),phi_hat_flex_robust{i},gamma_hat_flex_robust{i},c_hat_flex_robust{i},sigma_hat_flex_robust(:,1),M_hat_robust(i,1)]=...
%             nlestimation(y,s,T,[],p_hat(i),1);
%     end
%     filename = strcat('simulation_linear_',num2str(n));
%     save(filename)
% end
% 
% % ************************************************************************
% % Case C: Past returns is the transition variable
% % ************************************************************************
% 
% % Main settings
% p = 1;      % autoregressive order
% d = 0.4;    % fractional difference parameter
% 
% M = 2;      % number of transitions
% 
% phi = [0.8 -0.4 0.4];   % AR parameters
% theta = 1;              % MA parameters (always set to 1, no MA)
% 
% gamma = [5;5];      % slope parameters
% c = [-2;2];         % location parameters
% sigma = 0.5;        % error standard deviation
% 
% for n = 1:N
%     T = Tset(n);
%     phi_hat               = zeros(p,M+1,MC);
%     gamma_hat             = zeros(M,MC);
%     c_hat                 = zeros(M,MC);
%     sigma_hat             = zeros(MC,1);
%     d_hat                 = zeros(MC,1);
%     M_hat                 = zeros(MC,1);
%     p_hat                 = zeros(MC,1);
%     sigma_hat_flex        = zeros(MC,1);
%     d_hat_flex            = zeros(MC,1);
%     ybar                  = zeros(MC,1);
%     phi_hat_flex          = cell(MC,1);
%     gamma_hat_flex        = cell(MC,1);
%     c_hat_flex            = cell(MC,1);
%     M_hat_robust          = zeros(MC,1);
%     sigma_hat_flex_robust = zeros(MC,1);
%     d_hat_flex_robust     = zeros(MC,1);
%     ybar_robust           = zeros(MC,1);
%     phi_hat_flex_robust   = cell(MC,1);
%     gamma_hat_flex_robust = cell(MC,1);
%     c_hat_flex_robust     = cell(MC,1);
% 
%     for i=1:MC
%         disp(i)
%         % Transition variable definition
%         [y,s,f] = nlarfima(p,d,M,T,phi,theta,gamma,c,sigma,2);    % generate data
%                         
%         % estimation under fixed M and p
%         [d_hat(i,1),phi_hat(:,:,i),gamma_hat(:,i),c_hat(:,i),sigma_hat(i,1),ybar(i,1)]=...
%             nlestimation(y,s,T,M,p);
%     
%         % estimation with estimated M and p
%         p_hat(i) = pestimation(y,s,T,pmax,3,2);
%         [d_hat_flex(i,1),phi_hat_flex{i},gamma_hat_flex{i},c_hat_flex{i},sigma_hat_flex(:,1),M_hat(i,1)]=...
%             nlestimation(y,s,T,[],p_hat(i),0);
%        
%         [d_hat_flex_robust(i,1),phi_hat_flex_robust{i},gamma_hat_flex_robust{i},c_hat_flex_robust{i},sigma_hat_flex_robust(:,1),M_hat_robust(i,1)]=...
%             nlestimation(y,s,T,[],p_hat(i),1);
%     end
%     filename = strcat('simulation_return_',num2str(n));
%     save(filename)
% end
% 
% % ************************************************************************
% % Case D: Time is the transition variable and no long memory
% % ************************************************************************
% 
% % Main settings
% p = 1;      % autoregressive order
% d = 0;      % fractional difference parameter
% 
% M = 2;      % number of transitions
% 
% phi = [0.8 -0.4 0.4];   % AR parameters
% theta = 1;              % MA parameters (always set to 1, no MA)
% 
% gamma = [100;100];      % slope parameters
% c = [.25;.75];          % location parameters
% sigma = 0.5;            % error standard deviation
% 
% for n = 1:N
%     T = Tset(n);
%     phi_hat               = zeros(p,M+1,MC);
%     gamma_hat             = zeros(M,MC);
%     c_hat                 = zeros(M,MC);
%     sigma_hat             = zeros(MC,1);
%     d_hat                 = zeros(MC,1);
%     M_hat                 = zeros(MC,1);
%     p_hat                 = zeros(MC,1);
%     sigma_hat_flex        = zeros(MC,1);
%     d_hat_flex            = zeros(MC,1);
%     ybar                  = zeros(MC,1);
%     phi_hat_flex          = cell(MC,1);
%     gamma_hat_flex        = cell(MC,1);
%     c_hat_flex            = cell(MC,1);
%     M_hat_robust          = zeros(MC,1);
%     sigma_hat_flex_robust = zeros(MC,1);
%     d_hat_flex_robust     = zeros(MC,1);
%     ybar_robust           = zeros(MC,1);
%     phi_hat_flex_robust   = cell(MC,1);
%     gamma_hat_flex_robust = cell(MC,1);
%     c_hat_flex_robust     = cell(MC,1);
% 
%     for i=1:MC
%         disp(i)
%         % Transition variable definition
%         [y,s,f] = nlarfima(p,d,M,T,phi,theta,gamma,c,sigma,1);    % generate data
%                         
%         % estimation under fixed M and p
%         [d_hat(i,1),phi_hat(:,:,i),gamma_hat(:,i),c_hat(:,i),sigma_hat(i,1),ybar(i,1)]=...
%             nlestimation(y,s,T,M,p);
%     
%         % estimation with estimated M and p
%         p_hat(i) = pestimation(y,s,T,pmax,3,2);
%         [d_hat_flex(i,1),phi_hat_flex{i},gamma_hat_flex{i},c_hat_flex{i},sigma_hat_flex(:,1),M_hat(i,1)]=...
%             nlestimation(y,s,T,[],p_hat(i),0);
%        
%         [d_hat_flex_robust(i,1),phi_hat_flex_robust{i},gamma_hat_flex_robust{i},c_hat_flex_robust{i},sigma_hat_flex_robust(:,1),M_hat_robust(i,1)]=...
%             nlestimation(y,s,T,[],p_hat(i),1);
%     end
%     filename = strcat('simulation_time_nolong_',num2str(n));
%     save(filename)
% end
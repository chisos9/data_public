%It computes a test for a threshold in linear regression
%under homoskedasticity.  The procedure takes the form

%{f_test,p_value} = thr_test(dat,yi,xi,qi,trim_per,rep)

%The inputs are:
%dat      = data matrix (nxk)
%yi       = index of dependent (y) variable, e.g. yi = 1
%xi       = indexes of independent (x) variables, e.g. xi = 2|3
%qi       = index of threshold (q) variable, e.g. qi = 4
%trim_per = percentage of sample to trim from ends, e.g. trim_per = .15
%rep      = number of bootstrap replications, e.g. rep = 1000


%Output:
%f_test   = Value of Maximal (Quandt) F-statistic
%p_value  = Bootstrap p-value


%Notes: 
%(1)    Do not include a constant in the independent variables,
%       the program automatically adds an intercept to the regression.


%(2)    The program stores the sequential design matrices in order
%       to speed up the bootstrap computations.  It is possible that if
%       your dataset is very large, this will exceed your computer RAM
%       memory.  If so, program will crash, and the message
%              error G0030: Insufficient Workspace Memory
%       will be displayed.  If a more RAM is not available, 
%       change the switch _quick in the program to read "_quick=0;".  
%       This switch requires the bootstrap to re-calculate the design
%       matrices for each bootstrap replication, which requires less memory,
%       but somewhat more computer time.


%Example:
%If the nxk matrix "dat" contains the dependent variable in the first
%column, the independent variables in the second through tenth columns,
%and the threshold variable in the fifth:


%xi = 2|3|4|5|6|7|8|9|10;
%{f_test,p_value} = thr_test(dat,1,xi,5,.15,1000);


%*******************************************************************/


function [ftest, pv] = thr_test(dat,yi,xi,qi,trim_per,rep)


%/******************************************************
%Control Parameters, may be changed  */


cr = .95;        %@ This is the confidence level used to plot the
                 %   critical value in the graph.  It is not used
                 %   elsewhere in the analysis.                          @
graph   = 1;     %@ Graph indicator
                 %   Set _graph=0 to not view the graph of the likelihood
                 %   Set _graph=1 to view the graph of the likelihood    @
quick   = 1;     %@ Indicator of method used for bootstrap
                 %   Set _quick=1 for efficient, quick computation
                 %   Set _quick=0 if memory is limited (perhaps for
                 %   large data sets).                                   @ 



%/******************************************************/


n  = size(dat,1);
q = dat(:,qi);
[q qs] = sort(q);
y = dat(qs,yi);
x = [ones(n,1) dat(qs,xi)];
k = size(x,2);
qs = unique(q);
qn = size(qs,1);
qq = zeros(qn,1);
r=1; 
while r<=qn
    qq(r) = sum(q==qs(r));
    r=r+1; 
end
cqq = cumsum(qq);
sq = logical((cqq>=floor(n*trim_per)).*(cqq<=(floor(n*(1-trim_per)))));
qs = qs(sq);
cqq = cqq(sq);
qn = size(qs,1);


mi = inv(x'*x);
e  = y-x*mi*(x'*y);
ee = e'*e;
xe = cumsum(x.*(e*ones(1,k)));
sn = zeros(qn,1);


if quick == 1;
  %mmistore = zeros(k*(k+1)/2,qn);
  mmistore=zeros(k,k,qn);
  cqqb = 1;
  mm = zeros(k,k);
  r=1; 
  while r<=qn
    cqqr = cqq(r);
    mm = mm + x(cqqb:cqqr,:)'*x(cqqb:cqqr,:);
    sume = xe(cqqr,:)';
    mmi = inv(mm - mm*mi*mm);
    sn(r) = sume'*mmi*sume;
    cqqb = cqqr+1;
    %temp=reshape(tril(mmi)',size(mmi,1)^2,1);
    %temp=temp(temp~=0);
    %mmistore(:,r) = temp;
    mmistore(:,:,r)=mmi;
  r=r+1;
  end


  [smax si] = max(sn);
  qmax = qs(si);
  sig = (ee - smax)/n;
  lr = sn/sig;
  ftest = smax/sig;
  fboot = zeros(rep,1);
  j=1; 
  while j<=rep
    y  = randn(n,1);
    e  = y-x*mi*(x'*y);
    ee = e'*e;
    xe = cumsum(x.*(e*ones(1,k)));
    sn = zeros(qn,1);
    r=1; 
    while r<=qn
      %mmi = xpnd(mmistore[.,r]);
      mmi = mmistore(:,:,r);
      sume = xe(cqq(r),:)';
      sn(r) = sume'*mmi*sume;
    r=r+1;
    end
    smax = max(sn);
    sig = (ee - smax)/n;
    fboot(j) = smax/sig;
  j=j+1;
  end
elseif quick==0;
  cqqb = 1;
  mm = zeros(k,k);
  r=1; 
  while r<=qn
    cqqr = cqq(r);
    mm = mm + x(cqqb:cqqr,:)'*x(cqqb:cqqr,:);
    sume = xe(cqqr,:)';
    mmi = mm - mm*mi*mm;
    sn(r) = sume'*(mmi\sume);
    cqqb = cqqr+1;
  r=r+1;
  end
  [smax si] = max(sn);
  qmax = qs(si);
  sig = (ee - smax)/n;
  lr = sn/sig;
  ftest = smax/sig;
  fboot = zeros(rep,1);
  j=1; 
  while j<=rep
    y  = randn(n,1);
    e  = y-x*mi*(x'*y);
    ee = e'*e;
    xe = cumsum(x.*(e*ones(1,k)));
    sn = zeros(qn,1);
    cqqb = 1;
    mm = zeros(k,k);
    r=1; 
    while r<=qn;
      cqqr = cqq(r);
      mm = mm + x(cqqb:cqqr,:)'*x(cqqb:cqqr,:);
      mmi = mm - mm*mi*mm;
      sume = xe(cqqr,:)';
      sn(r) = sume'*(mmi\sume);
      cqqb = cqqr+1;
    r=r+1;
    end
    smax = max(sn);
    sig = (ee - smax)/n;
    fboot(j) = smax/sig;
  j=j+1;
  end
end
fboot = sort(fboot);
pv = mean(fboot >= ftest);
cr = fboot(round(rep*cr));
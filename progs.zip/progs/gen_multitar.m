function [r,h] = gen_tar(alpha_0,alpha_1,alpha_2,phi_0,phi_1,phi_2,tv,sigma_u,T)

p = length(phi_0);
lags = 1:p;
h(1:p,1) = eps;
e(1:p,1) = randn(p,1);
r(1:p,1) = sqrt(exp(h)).*e;

u = sigma_u*randn(T+500,1);

for t = p+1:T+500
    h(t,1) = (alpha_0+phi_0'*h(t-lags,1))*(r(t-1,1)<=-tv)+(alpha_1+phi_1'*h(t-lags,1))*(r(t-1,1)>=+tv)+(alpha_2+phi_2'*h(t-lags,1))*(r(t-1,1)>-tv & r(t-1,1)<tv)+u(t);
    g1(t,1) = (r(t-1,1)<=-tv);
    g2(t,1) = (r(t-1,1)>=tv);
    g3(t,1) = (r(t-1,1)>-tv & r(t-1,1)<tv);
    e(t,1)  = randn(1,1);
    r(t,1)  = sqrt(exp(h(t,1))).*e(t,1);
end

r = r(501:T+500);
h = h(501:T+500);
h=exp(h);
%--------------------------------------------------------------------------
% Data Construction
%--------------------------------------------------------------------------

function [y,r] = makedata(T,MC)

% Reset random number generator
reset(RandStream.getDefaultStream)

% Initialize data matrices
numModels = 19;
y = zeros(T,MC,numModels);
r = zeros(T,MC,numModels);

y1 = zeros(T,MC);
r1 = zeros(T,MC);
y2 = zeros(T,MC);
r2 = zeros(T,MC);
y3 = zeros(T,MC);
r3 = zeros(T,MC);
y4 = zeros(T,MC);
r4 = zeros(T,MC);
y5 = zeros(T,MC);
r5 = zeros(T,MC);
y6 = zeros(T,MC);
r6 = zeros(T,MC);
y7 = zeros(T,MC);
r7 = zeros(T,MC);
y8 = zeros(T,MC);
r8 = zeros(T,MC);
y9 = zeros(T,MC);
r9 = zeros(T,MC);
y10 = zeros(T,MC);
r10 = zeros(T,MC);
y11 = zeros(T,MC);
r11 = zeros(T,MC);
y12 = zeros(T,MC);
r12 = zeros(T,MC);
y13 = zeros(T,MC);
r14 = zeros(T,MC);
y15 = zeros(T,MC);
r15 = zeros(T,MC);
y16 = zeros(T,MC);
r16 = zeros(T,MC);
y17 = zeros(T,MC);
r17 = zeros(T,MC);
y18 = zeros(T,MC);
r18 = zeros(T,MC);

%--------------------------------------------------------------------------
% Short-Memory Linear Models
%--------------------------------------------------------------------------

% (1) AR(2) with Gaussian Errors
% ------------------------------
phi_1      = [0.04;0.55;0.34];  % AR coefficients (x -1)
theta_1    = [];                % MA coefficients
sigma_1    = 0.1;               % unconditional standard deviation
alpha_1    = [];                % GARCH(1,1) coefficients
lambda_1   = [];                % Jump intensity (Poisson)
gamma_1    = [];                % Transition function parameter (speed)
omega_1    = [];                % Transition function parameter (linear combination)
c_1        = [];                % Transition function parameter (location)
d_1        = 0;                 % Fractional difference parameter
df_error_1 = [];                % Degrees of freedom for t distribution
J_1        = [];                % Horizon for long-term returns

flag_dist_1     = 0;      % Gaussian errors
flag_vol_1      = 0;      % Homoskedasticity
flag_outliers_1 = 0;      % No outliers
flag_nonlin_1   = 0;      % Linear model
flag_sb_1       = 0;      % No breaks

% (2) AR(2) with t Distributed Errors
% -----------------------------------
phi_2      = [0.04;0.55;0.34];  % AR coefficients (x -1)
theta_2    = [];                % MA coefficients
sigma_2    = 0.1;               % unconditional standard deviation
alpha_2    = [];                % GARCH(1,1) coefficients
lambda_2   = [];                % Jump intensity (Poisson)
gamma_2    = [];                % Transition function parameter (speed)
omega_2    = [];                % Transition function parameter (linear combination)
c_2        = [];                % Transition function parameter (location)
d_2        = 0;                 % Fractional difference parameter
df_error_2 = 5;                 % Degrees of freedom for t distribution
J_2        = [];                % Horizon for long-term returns

flag_dist_2     = 3;      % Gaussian errors
flag_vol_2      = 0;      % Homoskedasticity
flag_outliers_2 = 0;      % No outliers
flag_nonlin_2   = 0;      % Linear model
flag_sb_2       = 0;      % No breaks

% (3) AR(2) with GARCH Errors
% ---------------------------
phi_3      = [0.04;0.55;0.34];          % AR coefficients (x -1)
theta_3    = [];                        % MA coefficients
sigma_3    = 0.1;                       % unconditional standard deviation
alpha_3    = [0.0001;0.95;0.049];       % GARCH(1,1) coefficients
lambda_3   = [];                        % Jump intensity (Poisson)
gamma_3    = [];                        % Transition function parameter (speed)
omega_3    = [];                        % Transition function parameter (linear combination)
c_3        = [];                        % Transition function parameter (location)
d_3        = 0;                         % Fractional difference parameter
df_error_3 = [];                        % Degrees of freedom for t distribution
J_3        = [];                        % Horizon for long-term returns

flag_dist_3     = 0;      % Gaussian errors
flag_vol_3      = 1;      % Homoskedasticity
flag_outliers_3 = 0;      % No outliers
flag_nonlin_3   = 0;      % Linear model
flag_sb_3       = 0;      % No breaks

%--------------------------------------------------------------------------
% Short-Memory Nonlinear Models with Leverage
%--------------------------------------------------------------------------

% (4) LSTAR(2) with Gaussian Errors
% ---------------------------------
phi_4      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_4    = [];                                  % MA coefficients
sigma_4    = 0.1;                                 % unconditional standard deviation
alpha_4    = [];                                  % GARCH(1,1) coefficients
lambda_4   = [];                                  % Jump intensity (Poisson)
gamma_4    = [12;4];                              % Transition function parameter (speed)
omega_4    = 1;                                   % Transition function parameter (linear combination)
c_4        = [-0.5;1];                            % Transition function parameter (location)
d_4        = 0;                                   % Fractional difference parameter
df_error_4 = [];                                  % Degrees of freedom for t distribution
J_4        = 0;                                   % Horizon for long-term returns

flag_dist_4     = 0;      % Gaussian errors
flag_vol_4      = 0;      % Homoskedasticity
flag_outliers_4 = 0;      % No outliers
flag_nonlin_4   = 1;      % Linear model
flag_sb_4       = 0;      % No breaks
 
% (5) LSTAR(2) with t Distributed Errors
% --------------------------------------
phi_5      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_5    = [];                                  % MA coefficients
sigma_5    = 0.25;                                 % unconditional standard deviation
alpha_5    = [];                                  % GARCH(1,1) coefficients
lambda_5   = [];                                  % Jump intensity (Poisson)
gamma_5    = [12;4];                              % Transition function parameter (speed)
omega_5    = 1;                                   % Transition function parameter (linear combination)
c_5        = [-0.5;1];                            % Transition function parameter (location)
d_5        = 0;                                   % Fractional difference parameter
df_error_5 = 5;                                   % Degrees of freedom for t distribution
J_5        = 0;                                   % Horizon for long-term returns

flag_dist_5     = 3;      % Gaussian errors
flag_vol_5      = 0;      % Homoskedasticity
flag_outliers_5 = 0;      % No outliers
flag_nonlin_5   = 1;      % Linear model
flag_sb_5       = 0;      % No breaks

% (6) LSTAR(2) with GARCH Errors
% ------------------------------
phi_6      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_6    = [];                                  % MA coefficients
sigma_6    = 0.1;                                 % unconditional standard deviation
alpha_6    = [0.0001;0.95;0.049];                   % GARCH(1,1) coefficients
lambda_6   = [];                                  % Jump intensity (Poisson)
gamma_6    = [12;4];                              % Transition function parameter (speed)
omega_6    = 1;                                   % Transition function parameter (linear combination)
c_6        = [-0.5;1];                            % Transition function parameter (location)
d_6        = 0;                                   % Fractional difference parameter
df_error_6 = [];                                  % Degrees of freedom for t distribution
J_6        = 0;                                   % Horizon for long-term returns

flag_dist_6     = 0;      % Gaussian errors
flag_vol_6      = 1;      % Homoskedasticity
flag_outliers_6 = 0;      % No outliers
flag_nonlin_6   = 1;      % Linear model
flag_sb_6       = 0;      % No breaks

%--------------------------------------------------------------------------
% Short-Memory Nonlinear Models with Time Breaks
%--------------------------------------------------------------------------

% (7) LSTAR(2) with Gaussian Errors
% ---------------------------------
phi_7      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_7    = [];                                  % MA coefficients
sigma_7    = 0.1;                                 % unconditional standard deviation
alpha_7    = [];                                  % GARCH(1,1) coefficients
lambda_7   = [];                                  % Jump intensity (Poisson)
gamma_7    = [0.2;0.1];                               % Transition function parameter (speed)
omega_7    = 1;                                   % Transition function parameter (linear combination)
c_7        = [0.25;0.75];                         % Transition function parameter (location)
d_7        = 0;                                   % Fractional difference parameter
df_error_7 = [];                                  % Degrees of freedom for t distribution
J_7        = [];                                  % Horizon for long-term returns

flag_dist_7     = 0;      % Gaussian errors
flag_vol_7      = 0;      % Homoskedasticity
flag_outliers_7 = 0;      % No outliers
flag_nonlin_7   = 1;      % Linear model
flag_sb_7       = 1;      % No breaks

% (8) LSTAR(2) with t Distributed Errors
% --------------------------------------
phi_8      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_8    = [];                                  % MA coefficients
sigma_8    = 0.1;                                 % unconditional standard deviation
alpha_8    = [];                                  % GARCH(1,1) coefficients
lambda_8   = [];                                  % Jump intensity (Poisson)
gamma_8    = [0.2;0.1];                               % Transition function parameter (speed)
omega_8    = 1;                                   % Transition function parameter (linear combination)
c_8        = [0.25;0.75];                         % Transition function parameter (location)
d_8        = 0;                                   % Fractional difference parameter
df_error_8 = 5;                                   % Degrees of freedom for t distribution
J_8        = [];                                  % Horizon for long-term returns

flag_dist_8     = 3;      % Gaussian errors
flag_vol_8      = 0;      % Homoskedasticity
flag_outliers_8 = 0;      % No outliers
flag_nonlin_8   = 1;      % Linear model
flag_sb_8       = 1;      % No breaks

% (9) LSTAR(2) with GARCH Errors
% ------------------------------
phi_9      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_9    = [];                                  % MA coefficients
sigma_9    = 0.1;                                 % unconditional standard deviation
alpha_9    = [0.0001;0.95;0.049];                   % GARCH(1,1) coefficients
lambda_9   = [];                                  % Jump intensity (Poisson)
gamma_9    = [0.2;0.1];                               % Transition function parameter (speed)
omega_9    = [];                                  % Transition function parameter (linear combination)
c_9        = [0.25;0.75];                         % Transition function parameter (location)
d_9        = 0;                                   % Fractional difference parameter
df_error_9 = [];                                  % Degrees of freedom for t distribution
J_9        = [];                                  % Horizon for long-term returns

flag_dist_9     = 0;      % Gaussian errors
flag_vol_9      = 1;      % Homoskedasticity
flag_outliers_9 = 0;      % No outliers
flag_nonlin_9   = 1;      % Linear model
flag_sb_9       = 1;      % No breaks

%--------------------------------------------------------------------------
% Long-Memory Linear Models
%--------------------------------------------------------------------------

% (10) ARFI(2) with Gaussian Errors
% ---------------------------------
phi_10      = [0;0.55;0.34]; % AR coefficients (x -1)
theta_10    = [];               % MA coefficients
sigma_10    = 0.1;              % unconditional standard deviation
alpha_10    = [];               % GARCH(1,1) coefficients
lambda_10   = [];               % Jump intensity (Poisson)
gamma_10    = [];               % Transition function parameter (speed)
omega_10    = [];               % Transition function parameter (linear combination)
c_10        = [];               % Transition function parameter (location)
d_10        = 0.4;              % Fractional difference parameter
df_error_10 = [];               % Degrees of freedom for t distribution
J_10        = [];               % Horizon for long-term returns

flag_dist_10     = 0;      % Gaussian errors
flag_vol_10      = 0;      % Homoskedasticity
flag_outliers_10 = 0;      % No outliers
flag_nonlin_10   = 0;      % Linear model
flag_sb_10       = 0;      % No breaks

% (11) ARFI(2) with t Distributed Errors
% --------------------------------------
phi_11      = [0;0.55;0.34]; % AR coefficients (x -1)
theta_11    = [];               % MA coefficients
sigma_11    = 0.1;              % unconditional standard deviation
alpha_11    = [];               % GARCH(1,1) coefficients
lambda_11   = [];               % Jump intensity (Poisson)
gamma_11    = [];               % Transition function parameter (speed)
omega_11    = [];               % Transition function parameter (linear combination)
c_11        = [];               % Transition function parameter (location)
d_11        = 0.4;              % Fractional difference parameter
df_error_11 = 5;                % Degrees of freedom for t distribution
J_11        = [];               % Horizon for long-term returns

flag_dist_11     = 3;      % Gaussian errors
flag_vol_11      = 0;      % Homoskedasticity
flag_outliers_11 = 0;      % No outliers
flag_nonlin_11   = 0;      % Linear model
flag_sb_11       = 0;      % No breaks

% (12) ARFI(2) with GARCH Errors
% ------------------------------
phi_12      = [0;0.55;0.34];          % AR coefficients (x -1)
theta_12    = [];                        % MA coefficients
sigma_12    = 0.1;                       % unconditional standard deviation
alpha_12    = [0.0001;0.95;0.049];         % GARCH(1,1) coefficients
lambda_12   = [];                        % Jump intensity (Poisson)
gamma_12    = [];                        % Transition function parameter (speed)
omega_12    = [];                        % Transition function parameter (linear combination)
c_12        = [];                        % Transition function parameter (location)
d_12        = 0.4;                       % Fractional difference parameter
df_error_12 = [];                        % Degrees of freedom for t distribution
J_12        = [];                        % Horizon for long-term returns

flag_dist_12     = 0;      % Gaussian errors
flag_vol_12      = 1;      % Homoskedasticity
flag_outliers_12 = 0;      % No outliers
flag_nonlin_12   = 0;      % Linear model
flag_sb_12       = 0;      % No breaks

%--------------------------------------------------------------------------
% Long-Memory Nonlinear Models with Leverage
%--------------------------------------------------------------------------

% (13) LSTAR(2) with Gaussian Errors
% ---------------------------------
phi_13      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_13    = [];                                  % MA coefficients
sigma_13    = 0.1;                                 % unconditional standard deviation
alpha_13    = [];                                  % GARCH(1,1) coefficients
lambda_13   = [];                                  % Jump intensity (Poisson)
gamma_13    = [12;4];                              % Transition function parameter (speed)
omega_13    = 1;                                   % Transition function parameter (linear combination)
c_13        = [-0.5;1];                            % Transition function parameter (location)
d_13        = 0.4;                                 % Fractional difference parameter
df_error_13 = [];                                  % Degrees of freedom for t distribution
J_13        = 0;                                   % Horizon for long-term returns

flag_dist_13     = 0;      % Gaussian errors
flag_vol_13      = 0;      % Homoskedasticity
flag_outliers_13 = 0;      % No outliers
flag_nonlin_13   = 1;      % Linear model
flag_sb_13       = 0;      % No breaks

% (14) LSTAR(2) with t Distributed Errors
% --------------------------------------
phi_14      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_14    = [];                                  % MA coefficients
sigma_14    = 0.1;                                 % unconditional standard deviation
alpha_14    = [];                                  % GARCH(1,1) coefficients
lambda_14   = [];                                  % Jump intensity (Poisson)
gamma_14    = [12;4];                              % Transition function parameter (speed)
omega_14    = 1;                                   % Transition function parameter (linear combination)
c_14        = [-0.5;1];                            % Transition function parameter (location)
d_14        = 0.4;                                 % Fractional difference parameter
df_error_14 = 5;                                   % Degrees of freedom for t distribution
J_14        = 0;                                   % Horizon for long-term returns

flag_dist_14     = 3;      % Gaussian errors
flag_vol_14      = 0;      % Homoskedasticity
flag_outliers_14 = 0;      % No outliers
flag_nonlin_14   = 1;      % Linear model
flag_sb_14       = 0;      % No breaks

% (15) LSTAR(2) with GARCH Errors
% ------------------------------
phi_15      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_15    = [];                                  % MA coefficients
sigma_15    = 0.1;                                 % unconditional standard deviation
alpha_15    = [0.0001;0.95;0.049];                   % GARCH(1,1) coefficients
lambda_15   = [];                                  % Jump intensity (Poisson)
gamma_15    = [12;4];                              % Transition function parameter (speed)
omega_15    = 1;                                   % Transition function parameter (linear combination)
c_15        = [-0.5;1];                            % Transition function parameter (location)
d_15        = 0.4;                                 % Fractional difference parameter
df_error_15 = [];                                  % Degrees of freedom for t distribution
J_15        = 0;                                   % Horizon for long-term returns

flag_dist_15     = 0;      % Gaussian errors
flag_vol_15      = 1;      % Homoskedasticity
flag_outliers_15 = 0;      % No outliers
flag_nonlin_15   = 1;      % Linear model
flag_sb_15       = 0;      % No breaks

%--------------------------------------------------------------------------
% Long-Memory Nonlinear Models with Time Breaks
%--------------------------------------------------------------------------

% (16) LSTAR(2) with Gaussian Errors
% ---------------------------------
phi_16      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_16    = [];                                  % MA coefficients
sigma_16    = 0.1;                                 % unconditional standard deviation
alpha_16    = [];                                  % GARCH(1,1) coefficients
lambda_16   = [];                                  % Jump intensity (Poisson)
gamma_16    = [0.2;0.1];                               % Transition function parameter (speed)
omega_16    = 1;                                   % Transition function parameter (linear combination)
c_16        = [0.25;0.75];                         % Transition function parameter (location)
d_16        = 0.4;                                 % Fractional difference parameter
df_error_16 = [];                                  % Degrees of freedom for t distribution
J_16        = [];                                  % Horizon for long-term returns

flag_dist_16     = 0;      % Gaussian errors
flag_vol_16      = 0;      % Homoskedasticity
flag_outliers_16 = 0;      % No outliers
flag_nonlin_16   = 1;      % Linear model
flag_sb_16       = 1;      % No breaks

% (17) LSTAR(2) with t Distributed Errors
% --------------------------------------
phi_17      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_17    = [];                                  % MA coefficients
sigma_17    = 0.1;                                 % unconditional standard deviation
alpha_17    = [];                                  % GARCH(1,1) coefficients
lambda_17   = [];                                  % Jump intensity (Poisson)
gamma_17    = [0.2;0.1];                               % Transition function parameter (speed)
omega_17    = 1;                                   % Transition function parameter (linear combination)
c_17        = [0.25;0.75];                         % Transition function parameter (location)
d_17        = 0;                                   % Fractional difference parameter
df_error_17 = 5;                                   % Degrees of freedom for t distribution
J_17        = [];                                  % Horizon for long-term returns

flag_dist_17     = 3;      % Gaussian errors
flag_vol_17      = 0;      % Homoskedasticity
flag_outliers_17 = 0;      % No outliers
flag_nonlin_17   = 1;      % Linear model
flag_sb_17       = 1;      % No breaks

% (18) LSTAR(2) with GARCH Errors
% ------------------------------
phi_18      = [0 0 0;0.55 -0.4 0.4;0.34 -0.2 0.2]; % AR coefficients (x -1)
theta_18    = [];                                  % MA coefficients
sigma_18    = 0.1;                                 % unconditional standard deviation
alpha_18    = [0.0001;0.95;0.049];                   % GARCH(1,1) coefficients
lambda_18   = [];                                  % Jump intensity (Poisson)
gamma_18    = [0.2;0.1];                              % Transition function parameter (speed)
omega_18    = 1;                                   % Transition function parameter (linear combination)
c_18        = [0.25;0.75];                         % Transition function parameter (location)
d_18        = 0;                                   % Fractional difference parameter
df_error_18 = [];                                  % Degrees of freedom for t distribution
J_18        = [];                                  % Horizon for long-term returns


flag_dist_18     = 0;      % Gaussian errors
flag_vol_18      = 1;      % Homoskedasticity
flag_outliers_18 = 0;      % No outliers
flag_nonlin_18   = 1;      % Linear model
flag_sb_18       = 1;      % No breaks

parfor i=1:MC
    data1 = genarfima(phi_1,theta_1,alpha_1,lambda_1,gamma_1,c_1,omega_1,sigma_1,d_1,...
                          flag_dist_1,flag_vol_1,flag_outliers_1,...
                          flag_nonlin_1,flag_sb_1,...
                          T,df_error_1,J_1);
    y1(:,i) = data1.volatility;
    r1(:,i) = data1.mean; 
    
    data2 = genarfima(phi_2,theta_2,alpha_2,lambda_2,gamma_2,c_2,omega_2,sigma_2,d_2,...
                          flag_dist_2,flag_vol_2,flag_outliers_2,...
                          flag_nonlin_2,flag_sb_2,...
                          T,df_error_2,J_2);
    y2(:,i) = data2.volatility;
    r2(:,i) = data2.mean;
    
    data3 = genarfima(phi_3,theta_3,alpha_3,lambda_3,gamma_3,c_3,omega_3,sigma_3,d_3,...
                          flag_dist_3,flag_vol_3,flag_outliers_3,...
                          flag_nonlin_3,flag_sb_3,...
                          T,df_error_3,J_3);
    y3(:,i) = data3.volatility;
    r3(:,i) = data3.mean;

    data4 = genarfima(phi_4,theta_4,alpha_4,lambda_4,gamma_4,c_4,omega_4,sigma_4,d_4,...
                          flag_dist_4,flag_vol_4,flag_outliers_4,...
                          flag_nonlin_4,flag_sb_4,...
                          T,df_error_4,J_4);
    y4(:,i) = data4.volatility;
    r4(:,i) = data4.mean;
    
    data5 = genarfima(phi_5,theta_5,alpha_5,lambda_5,gamma_5,c_5,omega_5,sigma_5,d_5,...
                          flag_dist_5,flag_vol_5,flag_outliers_5,...
                          flag_nonlin_5,flag_sb_5,...
                          T,df_error_5,J_5);
    y5(:,i) = data5.volatility;
    r5(:,i) = data5.mean;
    
    data6 = genarfima(phi_6,theta_6,alpha_6,lambda_6,gamma_6,c_6,omega_6,sigma_6,d_6,...
                          flag_dist_6,flag_vol_6,flag_outliers_6,...
                          flag_nonlin_6,flag_sb_6,...
                          T,df_error_6,J_6);
    y6(:,i) = data6.volatility;
    r6(:,i) = data6.mean;
    
    data7 = genarfima(phi_7,theta_7,alpha_7,lambda_7,gamma_7,c_7,omega_7,sigma_7,d_7,...
                          flag_dist_7,flag_vol_7,flag_outliers_7,...
                          flag_nonlin_7,flag_sb_7,...
                          T,df_error_7,J_7);
    y7(:,i) = data7.volatility;
    r7(:,i) = data7.mean;
    
    data8 = genarfima(phi_8,theta_8,alpha_8,lambda_8,gamma_8,c_8,omega_8,sigma_8,d_8,...
                          flag_dist_8,flag_vol_8,flag_outliers_8,...
                          flag_nonlin_8,flag_sb_8,...
                          T,df_error_8,J_8);
    y8(:,i) = data8.volatility;
    r8(:,i) = data8.mean;
    
    data9 = genarfima(phi_9,theta_9,alpha_9,lambda_9,gamma_9,c_9,omega_9,sigma_9,d_9,...
                          flag_dist_9,flag_vol_9,flag_outliers_9,...
                          flag_nonlin_9,flag_sb_9,...
                          T,df_error_9,J_9);
    y9(:,i) = data9.volatility;
    r9(:,i) = data9.mean;
    
    data10 = genarfima(phi_10,theta_10,alpha_10,lambda_10,gamma_10,c_10,omega_10,sigma_10,d_10,...
                          flag_dist_10,flag_vol_10,flag_outliers_10,...
                          flag_nonlin_10,flag_sb_10,...
                          T,df_error_10,J_10);
    y10(:,i) = data10.volatility;
    r10(:,i) = data10.mean;
    
    data11 = genarfima(phi_11,theta_11,alpha_11,lambda_11,gamma_11,c_11,omega_11,sigma_11,d_11,...
                          flag_dist_11,flag_vol_11,flag_outliers_11,...
                          flag_nonlin_11,flag_sb_11,...
                          T,df_error_11,J_11);
    y11(:,i) = data11.volatility;
    r11(:,i) = data11.mean;
    
    data12 = genarfima(phi_12,theta_12,alpha_12,lambda_12,gamma_12,c_12,omega_12,sigma_12,d_12,...
                          flag_dist_12,flag_vol_12,flag_outliers_12,...
                          flag_nonlin_12,flag_sb_12,...
                          T,df_error_12,J_12);
    y12(:,i) = data12.volatility;
    r12(:,i) = data12.mean;
    
    data13 = genarfima(phi_13,theta_13,alpha_13,lambda_13,gamma_13,c_13,omega_13,sigma_13,d_13,...
                          flag_dist_13,flag_vol_13,flag_outliers_13,...
                          flag_nonlin_13,flag_sb_13,...
                          T,df_error_13,J_13);
    y13(:,i) = data13.volatility;
    r13(:,i) = data13.mean;
    
    data14 = genarfima(phi_14,theta_14,alpha_14,lambda_14,gamma_14,c_14,omega_14,sigma_14,d_14,...
                          flag_dist_14,flag_vol_14,flag_outliers_14,...
                          flag_nonlin_14,flag_sb_14,...
                          T,df_error_14,J_14);
    y14(:,i) = data14.volatility;
    r14(:,i) = data14.mean;
    
    data15 = genarfima(phi_15,theta_15,alpha_15,lambda_15,gamma_15,c_15,omega_15,sigma_15,d_15,...
                          flag_dist_15,flag_vol_15,flag_outliers_15,...
                          flag_nonlin_15,flag_sb_15,...
                          T,df_error_15,J_15);
    y15(:,i) = data15.volatility;
    r15(:,i) = data15.mean;
    
    data16 = genarfima(phi_16,theta_16,alpha_16,lambda_16,gamma_16,c_16,omega_16,sigma_16,d_16,...
                          flag_dist_16,flag_vol_16,flag_outliers_16,...
                          flag_nonlin_16,flag_sb_16,...
                          T,df_error_16,J_16);
    y16(:,i) = data16.volatility;
    r16(:,i) = data16.mean;
    
    data17 = genarfima(phi_17,theta_17,alpha_17,lambda_17,gamma_17,c_17,omega_17,sigma_17,d_17,...
                          flag_dist_17,flag_vol_17,flag_outliers_17,...
                          flag_nonlin_17,flag_sb_17,...
                          T,df_error_17,J_17);
    y17(:,i) = data17.volatility;
    r17(:,i) = data17.mean;
    
    data18 = genarfima(phi_18,theta_18,alpha_18,lambda_18,gamma_18,c_18,omega_18,sigma_18,d_18,...
                          flag_dist_18,flag_vol_18,flag_outliers_18,...
                          flag_nonlin_18,flag_sb_18,...
                          T,df_error_18,J_18);
    y18(:,i) = data18.volatility;
    r18(:,i) = data18.mean;
end

y(:,:,1)=y1;
y(:,:,2)=y2;
y(:,:,3)=y3;
y(:,:,4)=y4;
y(:,:,5)=y5;
y(:,:,6)=y6;
y(:,:,7)=y7;
y(:,:,8)=y8;
y(:,:,9)=y9;
y(:,:,10)=y10;
y(:,:,11)=y11;
y(:,:,12)=y12;
y(:,:,13)=y13;
y(:,:,14)=y14;
y(:,:,15)=y15;
y(:,:,16)=y16;
y(:,:,17)=y17;
y(:,:,18)=y18;

r(:,:,1)=r1;
r(:,:,2)=r2;
r(:,:,3)=r3;
r(:,:,4)=r4;
r(:,:,5)=r5;
r(:,:,6)=r6;
r(:,:,7)=r7;
r(:,:,8)=r8;
r(:,:,9)=r9;
r(:,:,10)=r10;
r(:,:,11)=r11;
r(:,:,12)=r12;
r(:,:,13)=r13;
r(:,:,14)=r14;
r(:,:,15)=r15;
r(:,:,16)=r16;
r(:,:,17)=r17;
r(:,:,18)=r18;

%script run_erv_synthetic

function erv=run_erv_synthetic()

%generate data
T=2501;
X_exog=ones(T,1);
Z=ones(T,1);
betar=1e-4;
r_ar=0;
gamma=[.3;-.5];
betav=-4;
phi=0;
psi=0;
matheta=0;
kinmean=0;
d=0.4;
sigmav=0.1;
g='g_nelson';
[r, v] = erv_maker(T,X_exog,Z,r_ar,betar,gamma,betav,phi,psi,matheta,kinmean,d,sigmav,g);

%setup problem structure
X=ones(T,1);
Z=ones(T,1);
%r=r(2:T);
%v=v(2:T);
kphi=0;
kpsi=0;
kmatheta=0;
kinmean=0;
theta=[betar;gamma;betav;d;sigmav];
erv = erv_setup(v,r,X,Z,kphi,kpsi,kmatheta,kinmean,g);

%call solver
erv=erv_matlab(erv);
function [isLinear_AIC,isLinear_SBIC,gamma,c] = star_ic(y,X,q,T,p)

% Estimate the linear model
% -------------------------
b = inv(X'*X)*X'*y;
u = y-X*b;

AIC_linear  = log(var(u))+2*length(b)/T;
SBIC_linear = log(var(u))+log(T)*length(b)/T;


% Estimate the STAR model
% -----------------------
[alpha,lambda,gamma,c,e,G]=parestlm(y,X,q,T,p);

numpar = length(alpha)+length(lambda) + 2;
AIC_STAR  = log(var(e))+2*numpar/T;
SBIC_STAR = log(var(e))+log(T)*numpar/T;

if AIC_STAR<AIC_linear
    isLinear_AIC=0;
else
    isLinear_AIC=1;
end

if SBIC_STAR<SBIC_linear
    isLinear_SBIC=0;
else
    isLinear_SBIC=1;
end
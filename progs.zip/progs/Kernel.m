function K = Kernel(u,ker);
%K = kernel(u,ker)
%
% Compute the usual kernel functions.
%	u	support of the kernel
%	ker	'g' for Gaussian
%		'b' for Bartlett
%		'c' for cosinus
%		'e' for Epanechnikov 
%		'q' for quartic
%		'u' for uniform
%		't' for Triweighted
%		'a' for Andrews
%       'g4' for the Gaussian-based 4th order kernel

% Marcelo Fernandes (08/98)

trunc=abs(u)<=1;
if strcmp(ker, 'g'),
	K=(1/sqrt(2*pi))*exp(-(u.^2)/2);
elseif strcmp(ker, 'b'),
	K=(1-abs(u)).*trunc;
elseif strcmp(ker, 'c'),
	K=(pi/4)*cos(u*pi/2).*trunc;
elseif strcmp(ker, 'e'),
	K=(3/4)*(1-u.^2).*trunc;
elseif strcmp(ker, 'q'),
	K=(15/16)*((1-u.^2).^2).*trunc;
elseif strcmp(ker, 't'),
	K=(35/32)*((1-u.^2).^3).*trunc;
elseif strcmp(ker, 'u'),
	K=.5*trunc;
elseif strcmp(ker, 'a'),
	K=25*(sin(6*pi*u/5)/(6*pi*u/5)-cos(6*pi*u/5))./(12*(pi*u).^2);
elseif strcmp(ker, 'g4'),
	K=(3/sqrt(8*pi))*(1-(u.^2)/3).*exp(-(u.^2)/2);
	K(find(u==0))=1;
end
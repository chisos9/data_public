function erv = erv_setup(v,r,X,Z,kphi,kpsi,kmatheta,kinmean,g,theta)

%data
erv.v=v;
erv.r=r;
erv.X=X;
erv.Z=Z;
erv.T=size(v,1);
T=erv.T;

%parameter vector size bookkeeping
erv.kbetar=size(X,2);
if strcmp(g,'g_nelson')
    kg=2;
end
if strcmp(g,'g_logistic_regime')
    kg=2;
end
if strcmp(g,'g_logistic_change')
    kg=1;
end
if kinmean~=0
    erv.kgamma=kinmean+kg;%depends on vol-in-mean and non-linear function erv.nonlin
else
    erv.kgamma=kg;
end
gamma=zeros(erv.kgamma,1);
erv.kbetav=size(Z,2);
erv.kphi=kphi;
erv.kpsi=kpsi;
erv.kmatheta=kmatheta;
erv.kinmean=kinmean;

erv.theta=zeros(erv.kbetar+erv.kgamma+erv.kbetav+erv.kphi+erv.kpsi+erv.kmatheta+2,1);

%non-linear function
%erv.nonlin must be function of the form
%function vector = g(data vector, parameter vector)
erv.nonlin=g;

if nargin<10
    
    %startvalue d
    [d,se] = gph(v, 0.55);
    if (d<=-0.5)||(d>=0.5)
        d=0.4;
    end

    if kinmean>0
        %startvalue betar and gamma(1)
        X1=[X sqrt(exp(v))];
        b1=(X1'*X1)\(X1'*r);
        betar=b1(1:end-1);
        gamma(1)=b1(end);
    else
        b1=(X'*X)\(X'*r);
        betar=b1;
    end

    %startvalue betav
    betav=(Z'*Z)\(Z'*v);

    %startvalue phi
    if kphi>0
        X2=[Z(1:T-1,:) v(1:T-1)];
        b2=(X2'*X2)\(X2'*v(2:T));
        e2=v(2:T)-X2*b2;
        phi=b2(2);
    else
        e2=v-Z*betav;
        phi=[];
    end

    %startvalue psi
    if kpsi>0
        psi=.5;
    else
        psi=[];
    end
    
    %startvalue matheta
    if kmatheta>0
        matheta=.5;
    else
        matheta=[];
    end
    
    %startvalue gamma
    if kinmean>0
        if strcmp(g,'g_nelson')
            gamma(2:end)=[.5;.5];
        end
        if strcmp(g,'g_logistic_regime')
            gamma(2:end)=[3;0];
        end
        if strcmp(g,'g_logistic_change')
            gamma(2:end)=[.5];
        end
    else
        if strcmp(g,'g_nelson')
            gamma=[.5;.5];
        end
        if strcmp(g,'g_logistic_regime')
            gamma=[3;0];
        end
        if strcmp(g,'g_logistic_change')
            gamma=[.5];
        end
    end

    %startvalue sigmav
    sigmav=sqrt(e2'*e2/(T-1));

    erv.theta0=[betar;gamma;betav;phi;psi;matheta;d;sigmav];
    erv.theta=erv.theta0;

else
    
    erv.theta0=theta;
    erv.theta=theta;
    
end

%solver
erv.llh='erv_likelihood';
erv.solver='erv_matlab';

%infrastructure standard errors
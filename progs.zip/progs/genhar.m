% Function genhar: Generates data from linear and nonlinear HAR models with
% GARCH errors and jumps (outliers)
%
% Input parameters: 
% ----------------
% w: exogenous variables
% beta: parameters of the exogenous variables
% theta: parameters of the GARCH(1,1) model
% alpha: parameters of the HAR model
% phi
% gamma
% c
% sigma
% tau
% flag_dist
% flag_vol
% flag_outliers
% flag_nonlin
% flag_sb
% T
%
% Output parameters:
% -----------------


function data = genhar(w,theta,alpha,beta,phi,gamma,c,sigma,...
                      tau,flag_dist,flag_vol,flag_outliers,...
                      flag_nonlin,flag_sb,...
                      T,df_error)
                                   
M  = T + 500;       % Total number of observations (500 observations for burn-in period
N  = length(tau);   % Number of regressors (constant not included)
t0 = max(tau);      % Maximum lag
H  = length(gamma); % Number of additional regimes. Total number of regimes is H+1

z = normrnd(0,1,M,1);   

% Selection of the distribution of the errors
if flag_dist==0
    e = normrnd(0,1,M,1);    % Normal
elseif flag_dist==1
    e = gevrnd(0,1,0,M,1);   % Generalized Extreme Value
elseif flag_dist==2
    e = evrnd(0,1,M,1);      % Extreme value
elseif flag_dist==3
    e = trnd(df_error,M,1);  % t-distribution with df_error degrees of freedom
end
e = (e - mean(e))/std(e);

if flag_vol==0
    h = ones(M,1)*sigma;    % homoskedastic model
else
    h = ones(M,1)*(alpha(1)/(1-alpha(2)-alpha(3)));     % GARCH(1,1) errors
end

% Outliers (Jumps)
if flag_outliers==0
    k = zeros(M,1);
else
    k = phi(1)*poissrnd(phi(2),M,1);  % Lambda is the jump frequency
end

y = randn(M,1);
q = (exp(y).^(1/2)).*z;
f = zeros(M,H);
x = ones(M,N+1);

u = (h.^(0.5)).*e;
for t=t0:M-1
    for i=1:N
        x(t,i+1)=sum(y(t-tau(i)+1:t))/tau(i);
    end
    
    if flag_nonlin==0
        if flag_vol==0
            if isempty(w)==0
                y(t+1) = w(t+1,:)*beta + x(t,:)*alpha + u(t+1) + k(t+1);
            else
                y(t+1) = x(t,:)*alpha + u(t+1) + k(t+1);
            end
        else
            h(t+1) = theta(1) + theta(2)*h(t,1) + theta(3)*u(t)^2;
            u(t+1) = (h(t+1).^(0.5)).*e(t+1);
            if isempty(w)==0
                y(t+1) = w(t+1,:)*beta + x(t,:)*alpha + u(t+1) + k(t+1);
            else
                y(t+1) = x(t,:)*alpha + u(t+1) + k(t+1);
            end
        end
    else
        if flag_sb==0
            f(t+1,:) = siglog(gamma'.*(repmat(q(t),1,H)- c'));
        else
            f(t+1,:) = siglog(gamma'.*(repmat(t+1,1,H)- c'-500));      
        end
        
        if flag_vol==0
            if isempty(w)==0
                y(t+1) = w(t+1,:)*beta + x(t,:)*alpha(:,1)+...
                         sum(sum(repmat(x(t,:)',1,H).*repmat(f(t+1,:),N+1,1).*alpha(:,2:end)))+ ...
                         u(t+1) + k(t+1);
            else
                y(t+1) = x(t,:)*alpha(:,1)+...
                         sum(sum(repmat(x(t,:)',1,H).*repmat(f(t+1,:),N+1,1).*alpha(:,2:end)))+ ...
                         u(t+1) + k(t+1);
            end
        else
            h(t+1) = theta(1) + theta(2)*h(t,1) + theta(3)*u(t)^2;
            u(t+1) = (h(t+1).^(0.5)).*e(t+1);
            if isempty(w)==0
                y(t+1) = w(t+1,:)*beta + x(t,:)*alpha(:,1)+...
                         sum(sum(repmat(x(t,:)',1,H).*repmat(f(t+1,:),N+1,1).*alpha(:,2:end)))+ ...
                         u(t+1) + k(t+1);
            else
                y(t+1) = x(t,:)*alpha(:,1)+...
                         sum(sum(repmat(x(t,:)',1,H).*repmat(f(t+1,:),N+1,1).*alpha(:,2:end)))+ ...
                         u(t+1) + k(t+1);
            end
        end
    end
    
    q(t+1,1) = (exp(y(t+1)).^(1/2))*z(t+1);
end

aux = T+500;
data.variance   = y(501:aux);
data.vov        = h(501:aux);
data.mean       = q(501:aux);
data.jumps      = k(501:aux);
data.error      = u(501:aux);
data.stderror   = e(501:aux);
if flag_nonlin==0
    data.transfunc  = [];
    data.transvar   = [];
else
    if flag_sb==0
        data.transfunc  = f(501:aux,:);
        data.transvar   = q(500:T+499);
    else
        data.transfunc  = f(501:aux,:);
        data.transvar   = (1:T)';
    end
end
function [alphaf,lambdaf,gammaf,cf,bestcost]=startval(x,y,z,T,p)

bestcost=999999999999999999999999;

maxgamma=15;
mingamma=1;
rategamma=0.1;

minc=quantile(x,.05);
maxc=quantile(x,.95);
ratec=(maxc-minc)/100;

for gamma=mingamma:rategamma:maxgamma
    for c=minc:ratec:maxc
        fX=siglog(gamma*(x-c));
        Z=[z' (repmat(fX,p,1)'.*z')];
        theta=pinv(Z'*Z)*Z'*y;
        alpha=theta(1:p);
        lambda=theta(p+1:2*p);
        y_hat=alpha'*z+lambda'*(repmat(fX,p,1).*z);
        e=y-y_hat';
      	cost=sumsqr(e)/T;
      	if cost<=bestcost
            bestcost=cost;
            gammaf=gamma;
            cf=c;
            alphaf=alpha;
            lambdaf=lambda;
        end
    end
end



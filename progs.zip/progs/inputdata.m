function [y,X,q]=inputdata(r,h,p)

T=length(h);
t0=p+1;
X=[];

for i=1:p,
	X(:,i)=h(t0-i:T-i);
end
y = h(t0:T);
q = r(t0-1:T-1);

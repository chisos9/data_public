function [Y, f, period, par, lorentzian] = ehspectrum(x, w, overlap, scale, sf, nolorentz);

% x is time series
% w is window size - set to 256
% overlap is the overlap of the windows - set to 64
% scale is a scaling factor - set to 20
% sf is the sampling frequency - set to 4
% we're not interested in computing the lorentzian, so set nolorentz to 1

N = length(x);
%window = hanning(w);
if ~rem(w,2)
   % Even length window
   m = w/2;
   window = .5*(1 - cos(2*pi*(1:m)'/(w+1))); 
   window = [window; window(end:-1:1)];
else
   % Odd length window
   m = (w+1)/2;
   window = .5*(1 - cos(2*pi*(1:m)'/(w+1))); 
   window = [window; window(end-1:-1:1)];
end

k = fix((N-overlap)/(w-overlap));
normal = k*norm(window)^2;
segment = 1:w;
Y = zeros(w,1);
for i=1:k
    xseg = window.*x(segment);
    segment = segment + w - overlap;
    y = abs(fft(xseg)).^2;              % THIS IS THE CENTRAL PART: FOURIER TRANSF OF DATA
    Y = Y + y;
end
if rem(w,2)
	half = 1:(w+1)/2;
else
	half = 1:w/2+1;
end
Y = Y(half')*scale/normal;
f = half'*scale*sf/w;
par = [max(Y)/2; 1; 1];
if nargin < 6
    options = optimset('MaxFunEvals', 100000, 'MaxIter', 100000);
    par = lsqnonlin('lorentzian',par,[0 0 scale/w],[],options,Y,f) ;
end
%A = [];
%b = [];
%Aeq = [];
%beq = [];
%lb = [1e-20, 1e-20, scale/w];
%ub = [];
%nonlcon = [];
%options = optimset('LargeScale', 'off');
%[par,fval,exitflag,output,grad,hessian] = fmincon('lorentziansum',par,A,b,Aeq,beq,lb,ub,nonlcon,options,Y,f);

b1 = par(2);
par = par .* [1/scale;1/(scale^3*sf^2);1/(scale*sf*b1)];
f = f/(scale*sf);
Y = Y/scale;
%lorentzian = par(1) + par(2)./ (par(3)^2 + f.^2);
lorentzian = [];
period = 1./f;

function [r, v] = erv_maker(T,X_exog,Z,r_ar,betar,gamma,betav,phi,psi,matheta,kinmean,d,sigmav,g)

%stochastic drivers
%rand('state',198793);
%randn('state',1987236);
z=randn(T,1);
u=sigmav*randn(T,1);

%non-linear function
if kinmean>0
    gz=feval(g,z,gamma(2:end));
else
    gz=feval(g,z,gamma);
end

%lag order
p=length(phi);
q=length(matheta);
o=length(psi);
m=max([(o+1) p q]);

%build v(t)
    %build ma_part
    ma_part=zeros(T,1);
    for t=m+1:T
        ma_part(t)=[1;matheta]'*flipud(u(t-q:t));
    end
    %build arma_part: only ARMA(1,1) implemented
    arma_part=zeros(T,1);
    for t=m+1:T
        arcoeff=phi.^(0:t-1)';
        arma_part(t)=arcoeff'*flipud(ma_part(1:t));
    end
    %build fract_part
    trunc=100;
    fract_part=zeros(T,1);
    for t=m+1:trunc
        tvec=(1:t)';
        factvec=factorial(tvec-1);
        pvec=[1;d+(tvec(1:end-1)-1)];
        fdcoeff=cumprod(pvec)./factvec;
        fract_part(t)=fdcoeff'*flipud(arma_part(1:t));
    end
    tvec=(1:trunc)';
    factvec=factorial(tvec-1);
    pvec=[1;d+(tvec(1:end-1)-1)];
    fdcoeff=cumprod(pvec)./factvec;
    for t=trunc+1:T
        fract_part(t)=fdcoeff'*flipud(arma_part(t-trunc+1:t));
    end
    %build w(t)
    w=zeros(T,1);
    w1=Z*betav;
    w(1:m)=w1(1:m);
    for t=m+1:T
        w(t)=w1(t)+[1;psi]'*flipud(gz(t-o-1:t-1));
    end
    v=w+fract_part;

%build r(t)
    r=zeros(T,1);
    if kinmean>0
        t_indep=gamma(1)*sqrt(exp(v))+sqrt(exp(v)).*z;
    else
        t_indep=sqrt(exp(v)).*z;
    end
    if r_ar>0
        r(1)=X_exog(1,:)*betar(1:end-1)+t_indep(1);
        for t=2:T
            r(t)=[X_exog(t,:) r(t-1)]*betar+t_indep(t);
        end
    else
        r=X_exog*betar+t_indep;
    end
    %disp('hello')
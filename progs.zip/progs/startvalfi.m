% Function to compute starting values for a multiple-regime Long Memory Smooth
% Transition Regression (STR). The algorithm is based on a grid search over
% the parameters d,c, and gamma.

function [df,cf,gammaf,omegaf]=startvalfi(y,q,m,c,gamma,omega,T,p,nQ,const,trunc,N)

% inputs:
% ------
% y:        time-series data
% q:        transition variable
% m:        number of nonlinear terms (number of regimes - 1)
% gamma:    gamma values for the previous nonlinear terms
% c:        c values for the previous nonlinear terms
% p:        AR order
% T:        number of observations

bestcost = 999999999999999999999999;

pnew = p + const;
if nQ > 1
    lambda = unifrnd(-1,1,nQ,N);
    for k = 1:N
        lambda(:,k) = lambda(:,k)./norm(lambda(:,k));
        s = q*lambda(:,k);
        
        % Maximum and minimum values for gamma
        % ------------------------------------
        maxxi  = 20;
        minxi  = 1;
        ratexi = 1;
  
        % Maximum and minumum values for c
        % --------------------------------
        minc  = prctile(s,10);
        maxc  = prctile(s,90);
        ratec = (maxc-minc)/50;
       
        omega(:,m) = lambda(:,k);
        gamma(m,1) = 0;
        c(m,1)     = 0;
        for d = 0.1:0.1:0.49
            v = fracfilter(y,d,trunc);
            V = zeros(T-p,(m+1)*pnew);
            if const == 1
                V(:,1) = ones(T-p,1);
            end
            for i=1:p
                V(:,i+const) = v(p-i+1:T-i);
            end   
            fX = zeros(T-p,m);
            v  = v(p+1:end);
            for newxi = minxi:ratexi:maxxi
                for newc = minc:ratec:maxc
                    gamma(m,1) = newxi;
                    c(m,1)     = newc;
                    for i = 1:m
                        transition               = gamma(i)*(s(p+1:end,:)-c(i));
                        fX(:,i)                  = siglog(transition);
                        V(:,i*pnew+1:(i+1)*pnew) = repmat(fX(:,i),1,pnew).*V(:,1:pnew);
                    end
                    VV = (V'*V);
                    if rank(VV)<size(VV,2)
                        theta = pinv(VV)*V'*v;
                    else
                        theta = VV\(V'*v);
                    end
                    phi   = reshape(theta,pnew,m+1);
                    vhat  = V(:,1:pnew)*phi(:,1) + V(:,pnew+1:end)*vec(phi(:,2:end));
                    e     = v - vhat;
                    cost  = var(e);
                    if cost<=bestcost
                        bestcost = cost;
                        gammaf   = gamma;
                        omegaf   = omega;
                        cf       = c;
                        df       = d;
                    end
                end
            end
        end
    end 
else
    % Maximum and minimum values for gamma
    % ------------------------------------
    maxgamma  = 20;
    mingamma  = 1;
    rategamma = 1;
  
    % Maximum and minumum values for c
    % --------------------------------
    minc  = prctile(q,10);
    maxc  = prctile(q,90);
    ratec = (maxc-minc)/50;

    gamma(m,1) = 0;
    c(m,1)     = 0;
    for d = 0.1:0.1:0.49
        v    = fracfilter(y,d,trunc);
        pnew = p + const;
        V    = zeros(T-p,(m+1)*pnew);
        if const == 1
            V(:,1) = ones(T-p,1);
        end
        for i=1:p
            V(:,i+const) = v(p-i+1:T-i);
        end   
        fX = zeros(T-p,m);
        v  = v(p+1:end);
        for newgamma = mingamma:rategamma:maxgamma
            for newc = minc:ratec:maxc
                gamma(m,1) = newgamma;
                c(m,1)     = newc;
                for i = 1:m
                    transition               = gamma(i)*(q(p+1:end,:)-c(i));
                    fX(:,i)                  = siglog(transition);
                    V(:,i*pnew+1:(i+1)*pnew) = repmat(fX(:,i),1,pnew).*V(:,1:pnew);
                end
                VV = (V'*V);
                if rank(VV)<size(VV,2)
                    theta = pinv(VV)*V'*v;
                else
                    theta = VV\(V'*v);
                end
                phi   = reshape(theta,pnew,m+1);
                vhat  = V(:,1:pnew)*phi(:,1) + V(:,pnew+1:end)*vec(phi(:,2:end));
                e     = v - vhat;
                cost  = var(e);
                if cost<=bestcost
                    bestcost = cost;
                    gammaf   = gamma;
                    omegaf   = [];
                    cf       = c;
                    df       = d;
                end
            end
        end
    end
end
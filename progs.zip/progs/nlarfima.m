function [y,s,r,f,v] = nlarfima(p,d,M,T,phi0,phi1,theta,gamma,c,sigma,type)

% Hyperparameters
% ---------------
% p:    autoregressive order
% d:    order of fractional difference
% M:    number of transition functions
% T:    number of observations

% Parameters
% ----------
% phi0:     intercepts (1 x (M+1))
% phi1:     autoregressive parameters (p x (M+1))
% theta:    moving average parameters (q x 1)
% sigma:    error standard deviation
% gamma:    smoothness parameter
% c:        location parameter

% Variables
% ---------
% type: type of transition variable

% Error term
u = sigma*randn(T+500,1);
u = filter(theta,1,u); % ---> generates MA errors 
u = u - mean(u);

f      = zeros(T+500,M);
F      = zeros(T+500,M+1);
F(:,1) = ones(T+500,1);
PHI0   = zeros(T+500,1);
PHI1   = zeros(T+500,p);

s = -499:T;
s = s'/T;
   
v = zeros(100,1);
y = zeros(T+500,1);
r = zeros(T+500,1);
for t=101:T+500
    for m=1:M
        if type == 1        % Linear trend
            f(t,m) = siglog(gamma(m)*(s(t)-c(m)));
        elseif type == 2    % Pas return
            f(t,m) = siglog(gamma(m)*(r(t-1)-c(m)));
        else                % No transition
            f(t,m) = 0;
        end
    end
    F(t,2:end) = f(t,:);
    PHI0(t,1)  = sum(phi0.*F(t,:),2);
    for i=1:p
        PHI1(t,i) = sum(phi1(i,:).*F(t,:),2);
    end
    v(t,1) = PHI0(t,:) + PHI1(t,:)*v(t-1:-1:t-p,1)+u(t,1);
    if d>0
        aux = fractint_filter_invd_gen(v(1:t,1),d,100);
            y(t,1) = aux(end); 
    else
            y(t,1) = v(t,1);
    end        
    r(t,1) = sqrt(exp(y(t,1))/1000+0.00001*randn)*randn;
end
y = y(501:end,1);
s = s(501:end);
r = r(500:end-1);
f = f(501:end,:);
v = v(501:end);
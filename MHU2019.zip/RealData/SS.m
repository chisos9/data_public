function [mAhat]= SS(vP,Data,matF)
% The Kalman smoother for DFM with r factor - equation by equation
% Input:    vP - vector of parameters
%           Data - vector of data
%           mF - principal components
% Output:   mL - Txr matrix of loadings

% Specify the matrices
iR=size(matF,2);
f=matF;
T=eye(iR);
Q=eye(iR);
P_t=eye(iR);
mu=zeros(iR,1);
start=zeros(iR,1);
for j=1:iR
    T(j,j)=vP(3*j-2);
    Q(j,j)=vP(3*j);
    mu(j,1)=vP(3*j-1);
    P_t(j,j)=Q(j,j)/(1-T(j,j)^2);
end
sigmaeps=vP(3*iR+1);

% KF
iT=size(Data,1);
mAhat=zeros(iT,iR);
vF=zeros(iT,1);
vV=zeros(iT,1);
vK=zeros(iT,iR);
vA=zeros(iT+1,iR);
mL=cell(iT,1);
mP=cell(iT+1,1);
vA(1,:)=start';                            
mP{1,1}=P_t;

for i=1:iT
   vV(i) =Data(i)-f(i,:)*(vA(i,:)'+mu);
   vF(i) = f(i,:)*mP{i,1}*f(i,:)'+sigmaeps;
   vK(i,:) = (T*mP{i,1}*f(i,:)'/vF(i))';
   vA(i+1,:) = (T*vA(i,:)' + vK(i,:)'*vV(i))';
   mL{i}=(T-vK(i,:)'*f(i,:));
   mP{i+1,1} = T*mP{i,1}*mL{i}' + Q;
end
% SS
r_t=zeros(1,iR);
N_t=0;
for i=iT:-1:1
    r_t=vV(i)/vF(i)*f(i,:)+r_t*mL{i};
    mAhat(i,:)= vA(i,:)+r_t*mP{i,1}';
end
mAhat=bsxfun(@plus,mAhat,mu');
% mLKF=vA(1:end-1,:)+mu';

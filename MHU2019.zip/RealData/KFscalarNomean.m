function [vV,vVf,vF,vMean]= KFscalarNomean(vP,Data,matF)
% The Kalman filter for DFM with one factor by concentrating out means
% Input:    vP - vector of parameters, no mean parameters
%           Data - Data
%           mF - principal components/factors
% Output:   vF - vector of prediction error variances
%           vV - vector of predictione errors for data
%           vVf - vector of predictione errors for factors
%           vMean - Mean estimate
% Works 09/10/2015
% Specify the matrices
f=matF;
phi = vP(1);
sigmaxi=vP(2);
sigmaeps=vP(3);
% d = vP(5);      % Constant in measurement equation

% KF
iT=size(Data,1);
vF=zeros(iT+1,1);
vV=zeros(iT+1,1);
vVf=zeros(iT+1,1);
a_t=0;                                  % Initial state
af_t=0;                                 % Initial state
P_t=sigmaxi/(1-phi^2);

for i=1:iT
   vV(i) = Data(i)-f(i)*a_t;        
   vVf(i) = f(i)-f(i)*af_t;
   vF(i) = f(i)^2*P_t+sigmaeps;
   temp = P_t*f(i)/vF(i);  
   a_tt = a_t+temp*vV(i); 
   af_tt= af_t+temp*vVf(i); 
   P_tt=P_t - temp*f(i)*P_t;
   a_t = phi*a_tt; 
   af_t = phi*af_tt;  
   P_t = phi^2*P_tt + sigmaxi;
end
vV = vV(1:iT,1);  % Delete the last element as it is only relevant for forecasting 
vVf= vVf(1:iT,1);
vF = vF(1:iT);    % Same here
XdivF =bsxfun(@rdivide,vVf,vF)';
vMean = (XdivF*vVf)\(XdivF*vV);
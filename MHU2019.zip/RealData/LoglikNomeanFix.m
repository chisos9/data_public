function [Value]= LoglikNomeanFix(vP,Data,mF,k)
% Calculates the loglikelihood function by concentrating out the mean
% parameters
% Input:    vP - vector of parameters, not including means
%           Data - vector of data
%           mF - principal components/Factors
%           k - index number for constant factor loading
% Output:   Value - loglikelihood value
% 09/10/2015 - Works
iT = size(Data,1);
iRk=size(mF,2)-1;
vPtrans=vP;
for i=1:iRk
    vPtrans(2*i)=exp(vP(2*i));
end   
vPtrans(end)=exp(vP(end));

[vV,mV,vF,vMean]= KFNomeanFix(vPtrans,Data,mF,k);

res=vV-mV*vMean;
Value = (0.5*sum(log(vF))+0.5*bsxfun(@rdivide,res,vF)'*res)/iT;

if ~isreal(Value) || isnan(Value) || isinf(Value)
    Value=1e20;
end
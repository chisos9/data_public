% /10/2015 - Tables of rejection frequencies across factors and equations
% Load data
% Works 27/10/2015

PathSave = 'C:\Users\sbgx643\Dropbox\PhD\Dynamic Factor Models\Matlab\RealData\Results\';
PathLoad = 'C:\Users\sbgx643\Dropbox\PhD\Dynamic Factor Models\Matlab\RealData\Results\';

Factors = 'mCatreject';
Cross = 'vCatreject';

L1 = [PathLoad Factors '.mat'];
Lcross1 = [PathLoad Cross '.mat'];

S1 = [PathSave Factors '.tex'];  

S =char(S1);
L=char(L1);
Lcross=char(Lcross1);
Colname = {};%{'Category', '$F_1$','$F_2$','$F_3$','$F_4$'};
Rowname = {'Output', 'Consumption', 'Labour market', 'Housing', 'Investment', 'Prices \& Wages' ,'Financial variables', 'Money \& Credit', 'Other', 'All'};
NumDec =  '%3.3f';

for i=1;
    load(deblank(L(i,:)));
    load(deblank(Lcross(i,:)));
    filename=deblank(S(i,:));
    temp=mCatreject(:,6:end);
    temp = [temp vCatreject(:,end)]
%     latextable(tab,'Horiz',Colname,'Vert',Rowname,'Hline',[0,1,NaN],'format',NumDec,'name',filename);
%     latextableSS(temp,'Horiz',Colname,'Vert',Rowname,'Hline',[],'name',filename);
    latextableRejectFactor(temp,'Horiz',Colname,'Vert',Rowname,'Hline',[9],'name',filename);
end

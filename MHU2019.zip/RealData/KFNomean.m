function [vV,mVf,vF,vMean]= KFNomean(vP,Data,matF)
% The Kalman filter for DFM by concentrating out means
% Input:    vP - vector of parameters, no mean parameters
%           Data - Data
%           mF - principal components/factors
% Output:   vF - vector of prediction error variances
%           vV - vector of predictione errors for data
%           mVf - matrix of predictione errors for factors
%           vMean - Mean estimate
%     Works 09/10/2015

% Specify the matrices
iR=size(matF,2);
f=matF;
T=eye(iR);
Q=eye(iR);
P_t=eye(iR);

for j=1:iR
    T(j,j)=vP(2*j-1);
    Q(j,j)=vP(2*j);
    P_t(j,j)=Q(j,j)/(1-T(j,j)^2);
end
sigmaeps=vP(end);

% KF
iT=size(Data,1);
vF=zeros(iT+1,1);
vV=zeros(iT+1,1);
mVf=zeros(iT+1,iR);
a_t=zeros(iR,1);                        % Estimate mean in measurement eq
Af_t=zeros(iR,iR);
for i=1:iT
   vV(i) = Data(i)-f(i,:)*a_t;
   mVf(i,:) = f(i,:)-f(i,:)*Af_t;   
   vF(i) = f(i,:)*P_t*f(i,:)'+sigmaeps;
   temp = P_t*f(i,:)'/vF(i);
   a_tt = a_t+temp*vV(i); 
   Af_tt = Af_t+ temp*mVf(i,:); 
   P_tt=P_t - temp*f(i,:)*P_t;
   a_t = T*a_tt;   
   Af_t = T*Af_tt;
   P_t = T*P_tt*T' + Q;
end
vV = vV(1:iT,1);  % Delete the last element as it is only relevant for forecasting 
mVf = mVf(1:iT,:);  % Delete the last element as it is only relevant for forecasting 
vF = vF(1:iT);    % Same here
XdivF =bsxfun(@rdivide,mVf,vF)';
vMean = (XdivF*mVf)\(XdivF*vV);
 % Estimate model for Stock&Watson data 
% Works 19/10/2015
clear
clc
% Load data
X=xlsread('data');
trans=xlsread('trans_code');
Category=xlsread('tab4code');
[~, ~, name] = xlsread('name','Sheet1');
name(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),name)) = {''};
[~, ~, descrshort] = xlsread('descr_short','Sheet1');
descrshort(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),descrshort)) = {''};
dates=xlsread('dates');
% format short g
Catnames={'Out', 'Cons', 'Labor', 'Housing', 'Inv.', 'Prices & Wages' ,'Financial', 'Money', 'Other'};

% Sort data
Ident = [1:size(X,2)];
Xcat=[Ident;Category; X];
Xcatsort=sortrows(Xcat',2)';
barnames= cellfun(@num2str,num2cell(Xcatsort(2,:)),'UniformOutput',false)';

% Estimate Factors
[T,N]=size(X);
iR = 4;                                     % Number of factors
mF = PC(X,iR);
mFsort=PC(Xcatsort(3:end,:),iR);
vEig=eigs(X'*X,size(X,2)-1);                % Eigenvalue of covariance matrix
vEigShare = cumsum(vEig)/sum(vEig); 
Lambda=mFsort'*Xcatsort(3:end,:)/T;         % Constant loadings
Lambda=Lambda';

% Plot factors
figure
for i=1:iR
    subplot(iR,1,i);
    hold on
    axis([dates(1) dates(end) -inf inf])
    plot(dates,mFsort(:,i));
    title(['Factor ' int2str(i)]); 
end
%saveas(gcf,'Plots/FactorPlot','epsc');
%print('Plots/FactorPlot','-djpeg','-r200')
% Plot (p)acf's
figure
for i=1:iR
    subplot(iR,1,i);
    [acf,~,sig]=autocorr(mFsort(:,i));
    pacf = parcorr(mFsort(:,i));
    sigline=sig*ones(1,21);
    hold on
    ylim([-0.5 1]);
    z=bar([acf pacf]);
    set(z(1),'FaceColor','b');
    set(z(2),'FaceColor','r');
    z=plot(sigline');
    set(z(1),'color','k');
    set(z(2),'color','k');
    title(['Factor ' int2str(i)]); 
    legend('ACF','PACF');
end   
%saveas(z,'FactorAcf','jpg');
%print('Plots/FactorAcf','-djpeg','-r200')

% Make R2 stats for factors to get interpretation
mCorrXF= [];
for i=1:iR
    mCorrXF(:,i)=corr(X,mF(:,i)).^2;
end
mCorrXFsort= [];
for i=1:iR
    mCorrXFsort(:,i)=corr(Xcatsort(3:end,:),mFsort(:,i)).^2;
end
BarnamesString={'Output'};
Barline=[1];
position=[1.5];
j=2;
for i=2:N
    if Xcatsort(2,i)==Xcatsort(2,i-1)
        BarnamesString=horzcat(BarnamesString,{''});
        Barline=horzcat(Barline,0);
    else
        BarnamesString=horzcat(BarnamesString,Catnames(j));
        Barline=horzcat(Barline,1);
        j=j+1;
    end
    position(i)=i+0.5;
end
BarnamesCenter={''};
j=1;
for i=2:N
    if i == 3 || i == 10 || i ==23 || i ==37 || i ==45 || i ==62 || i ==85 || i ==99 || i ==109
        BarnamesCenter=horzcat(BarnamesCenter,Catnames(j));
        j=j+1;
    else
        BarnamesCenter=horzcat(BarnamesCenter,{''});
    end
end
% Bar plots
figure
for i =1:iR
    subplot(iR,1,i);
    bar(mCorrXF(:,i));
    title(['Factor' int2str(i)]); 
end
for i =1:iR
    subplot(iR,1,i);
    hold on
    h=bar(position,mCorrXFsort(:,i));
    %h=stem(Barline,'Marker','none','LineWidth',1);
    title(['Factor ' int2str(i)]); 
%     set(gca, 'XTick', 1:size(mCorrXFsort,1), 'XTickLabel', BarnamesCenter);
 %     set(gca, 'XTick', 1:8, 'XTickLabel', Catnames{1});
 ax = gca;
 ax.XTick=[1:size(mCorrXFsort,1)];
 ax.XTickLabel = BarnamesCenter;
%  ax.XTickLabelRotation = 90;
end
%saveas(h,'FactorCorr','epsc');
%print('Plots/FactorCorr','-djpeg','-r200')


% VAR(1) FOR FACTORS
mRho=(mFsort(2:end,:)'*mFsort(2:end,:))\(mFsort(2:end,:)'*mFsort(1:end-1,:));     % First column of coefficients for first factor and so on
% Estimate loading parameters
opts = optimoptions('fminunc','Algorithm','quasi-newton','Display','off','MaxFunctionEvaluations',10000);
mParm = zeros(N,3*iR+1);                            % Parameters
vLoklik = zeros(N,1);                               % Likelihood values
vLoglikOLS= zeros(N,1);                             % Likelihood values for restricted model with all loadings constant
vLoglikFix= zeros(N,iR);                            % Likelihood values for restricted model with loading on k'th factor fixed
cLoadings=cell(N,1);                                % Loadings from state smoother
vChi2=zeros(N,1);                                   % Chi2 statistics for testing constant loadings for variable i 

vExit=zeros(N,1);                                   % Minimization exit condition
mExit=zeros(N,iR);                                  % Minimization exit condition  for fixed loadings

%warning('off');
for j=1:N
%for j=[24, 52]    
    disp(j)
    data = Xcatsort(3:end,j);
    resOLS= data-mFsort*mFsort'*data./T;
    sigma2=resOLS'*resOLS/T;
    vLoglikOLS(j)=-0.5*T*(log(sigma2)+1);
    vP0=[zeros(2*iR,1);log(sigma2)];
    [vP,Value,exit,~]=fminunc('LoglikNomean',vP0,opts,data,mFsort);
    vLoklik(j)=-Value;     % Loglik not divided by T
    vExit(j)=exit;
    for s=1:iR
        vPfix0=[zeros(2*(iR-1),1);log(sigma2)];
        [vPfix,Valuefix,exit,~]=fminunc('LoglikNomeanFix',vPfix0,opts,data,mFsort,s);
        vLoglikFix(j,s)=-Valuefix; 
        mExit(j,s)=exit;
    end
    for v=1:iR
%       vP(iR*(2*v-1)+v+1:2*v*iR+1) = exp(vP(iR*(2*v-1)+v+1:2*v*iR+1)); 
        vP(2*v)=exp(vP(2*v));
    end   
    vP(end)=exp(vP(end));
    if iR==1
        [~,~,~,vMean]= KFscalarNomean(vP,data,mFsort);
    else
        [~,~,~,vMean]= KFNomean(vP,data,mFsort);
    end
    vPmean=zeros(3*iR+1,1);
    for v=1:iR
        vPmean(3*v-2)=vP(2*v-1);    
        vPmean(3*v-1)=vMean(v);    
        vPmean(3*v)=vP(2*v);
    end   
    vPmean(end)=vP(end);
    mParm(j,:)=vPmean';
    mL=SS(vPmean,data,mFsort);
    cLoadings{j,1}=mL;
end
%save(['Results/Parameters'],'mParm');
%save(['Results/KS_Loadings'],'cLoadings');

%save results_Mar17

% % Plot loadings
% % One-year/three-month Treasure term spread
% for j=1:iR
%     subplot(iR,1,j);
%     hold on
%     axis([dates(1) dates(end) -2 2])
%     y=plot(dates,cLoadings{81,1}(:,j));
%     title(['Loading ' int2str(j)]); 
%     legend(['Loading ' int2str(j)])
% end
% co = get(gca,'ColorOrder')
%  colorname=[0.9290    0.6940    0.1250; 0.4940    0.1840    0.5560;0.4660    0.6740    0.1880; 0.3010    0.7450    0.9330];
% %colorname=[0.4940    0.1840    0.5560;0.4660    0.6740    0.1880; 0.3010    0.7450    0.9330];
% for i=1:4
%     hold on
%     axis([dates(1) dates(end) -inf inf]);
%     % plot(dates,cLoadings{81,1}(:,1),'b',dates,cLoadings{81,1}(:,2),'g',dates,cLoadings{81,1}(:,3),dates,cLoadings{81,1}(:,4));
%     plot(dates,cLoadings{81,1}(:,i),'Color',colorname(i,:));
%     % title(['Factor Loadings for the One-year/3-month Treasure term spread']); 
% end
% for i=1:4
%     hold on
%     axis([dates(1) dates(end) -inf inf]);
%     % plot(dates,cLoadings{81,1}(:,1),'b',dates,cLoadings{81,1}(:,2),'g',dates,cLoadings{81,1}(:,3),dates,cLoadings{81,1}(:,4));
%     plot(dates,cLoadings{81,1}(:,i),'Color',colorname(i,:));
%     % title(['Factor Loadings for the One-year/3-month Treasure term spread']); 
% end
% legend(['Loading 1'; 'Loading 2'; 'Loading 3'; 'Loading 4']);
% % Durable Consumption
% hold on
% axis([dates(1) dates(end) -inf inf]);
% % plot(dates,cLoadings{81,1}(:,1),'b',dates,cLoadings{81,1}(:,2),'g',dates,cLoadings{81,1}(:,3),dates,cLoadings{81,1}(:,4));
% plot(dates,cLoadings{9,1});
% % title(['Factor Loadings for Dureable Consumption']); 
% legend(['Loading 1'; 'Loading 2'; 'Loading 3'; 'Loading 4']);
% 
% % Plot common component
% mCommon=cLoadings{81,1}.*mFsort;            
% vCommon=sum(mCommon')';                                  % Common component
% vOLSfull=mFsort*mFsort'*Xcatsort(3:end,81)./T;          % Common component OLS full sample
% vOLSsplit1=mFsort(1:98,:)*mFsort(1:98,:)'*Xcatsort(3:100,81)/98;        % Common component OLS split sample
% vOLSsplit2=mFsort(99:end,:)*mFsort(99:end,:)'*Xcatsort(101:end,81)./92;
% vOLSsplit=[vOLSsplit1 ; vOLSsplit2];
% % CC=[ vCommon vOLSsplit vOLSfull Xcatsort(3:end,81)];
% CC=[ Xcatsort(3:end,81) vCommon vOLSfull ];
% for i=1:size(CC,2)
% hold on
% axis([dates(1) dates(end) -inf inf]);
% % plot(dates,cLoadings{81,1}(:,1),'b',dates,cLoadings{81,1}(:,2),'g',dates,cLoadings{81,1}(:,3),dates,cLoadings{81,1}(:,4));
% % plot(dates,[vCommon vOLSsplit vOLSfull]);
% plot(dates,CC(:,i),'Color',colorname(i,:));
% % plot(dates,CC(:,i));
% end
% % legend(['KS         '; 'LS-split   ';'LS-full    ';'Term spread']);
% legend(['Term spread              ';'CC: Time-varying loadings';'CC: Constant loadings    ']);

% % Tests
% vChi2=2*(vLoklik-vLoglikOLS);                                   % Tests statics for each cross-section
% ProbChi2= chi2cdf(vChi2,iR,'upper');
% sum(ProbChi2<0.01)
% vChi2fac=2*bsxfun(@minus,sum(vLoklik),sum(vLoglikFix));
% ProbChi2fac= chi2cdf(vChi2fac,N,'upper')
% mChi2fac=2*bsxfun(@minus,vLoklik,vLoglikFix);                   % Tests statics for each factor
% ProbmChi2fac= chi2cdf(mChi2fac,1,'upper');
% FracRejectFactor=sum(ProbmChi2fac<0.05)
% save(['Results/Test_stat_crosssection'],'vChi2');               % Tests statics for each cross-section
% save(['Results/Test_stat_factors'],'mChi2fac');
% save(['Results/FracRejectFactor'],'FracRejectFactor');
% % The negative chi2 stats is due to all loadings constant or convergence
% % problems. Treat them as zeros. 
% 
% crossReject=ProbChi2<0.05;
% vCatreject=zeros(size(Catnames,2)+1,3);
% vCatreject(1,:)=[crossReject(1) 1 0];
% j=1;
% for i=2:N
%     if Xcatsort(2,i)==Xcatsort(2,i-1)
%         vCatreject(j,1)=vCatreject(j,1)+crossReject(i);
%         vCatreject(j,2)=vCatreject(j,2)+1;
%     else
%         j=j+1;
%         vCatreject(j,1)=vCatreject(j,1)+crossReject(i);
%         vCatreject(j,2)=vCatreject(j,2)+1;
%     end
% end
% vCatreject(:,3)=vCatreject(:,1)./vCatreject(:,2);
% vCatreject(end,:)=sum(vCatreject);
% vCatreject(end,3)=vCatreject(end,1)/vCatreject(end,2);
% save(['Results/vCatreject'],'vCatreject');
% 
% colunmReject=ProbmChi2fac<0.05;
% mCatreject=zeros(size(Catnames,2)+1,2*iR+1);
% mCatreject(1,:)=[colunmReject(1,:) 1 zeros(1,iR)];
% j=1;
% for i=2:N
%     if Xcatsort(2,i)==Xcatsort(2,i-1)
%         for k=1:iR
%             mCatreject(j,k)=mCatreject(j,k)+colunmReject(i,k);
%         end
%         mCatreject(j,iR+1)=mCatreject(j,iR+1)+1;
%         else
%         j=j+1;
%         for k=1:iR
%             mCatreject(j,k)=mCatreject(j,k)+colunmReject(i,k);
%         end
%         mCatreject(j,iR+1)=mCatreject(j,iR+1)+1;
%     end
% end
% for k=1:iR
%     mCatreject(:,iR+1+k)=mCatreject(:,k)./mCatreject(:,iR+1);
% end
% mCatreject(end,:)=sum(mCatreject);
% for k=1:iR
%     mCatreject(end,iR+1+k)=mCatreject(end,k)/mCatreject(end,iR+1);
% end
% save(['Results/mCatreject'],'mCatreject');
% 
% % Updated Factor Estimates
% cLt=cell(T,1);
% for i=1:N
%     for t=1:T
%         cLt{t,1}(i,:)=cLoadings{i,1}(t,:);
%     end
% end
% mF_OLS=[];
% for t=1:T
%     mF_OLS(t,:)=((cLt{t,1}'*cLt{t,1})\(cLt{t,1}'*Xcatsort(t+2,:)'))';
% end
% mRho_OLS=(mF_OLS(2:end,:)'*mF_OLS(2:end,:))\(mF_OLS(2:end,:)'*mF_OLS(1:end-1,:));
% 
% mF_GLS=[];
% for t=1:T
%     temp=[];
%     temp=bsxfun(@rdivide,cLt{t,1},mParm(:,end)); 
%     mF_GLS(t,:)=((temp'*cLt{t,1})\(temp'*Xcatsort(t+2,:)'))';
% end
% mRho_GLS=(mF_GLS(2:end,:)'*mF_GLS(2:end,:))\(mF_GLS(2:end,:)'*mF_GLS(1:end-1,:));
% 
% [mF_SS]= SSfactors(Xcatsort(3:end,:),cLoadings,mParm(:,end),mRho);
% 

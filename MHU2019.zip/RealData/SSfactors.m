function [mFactors]= SSfactors(Data,cL,vPsi,mRho)
% The Kalman smoother factors - collapsing observation vector
% Input:    Data    - TxN matrix of data
%           cL      - N-cell of Txr smoothed loadings 
%           vPsi    - N-vector of error variances
%           mRho    - r x r factor AR matrix 
%        
% Output:   mFactors - Txr matrix of smoothed factprs

iR=size(mRho,2);
[iT iN] = size(Data);
% Transform model to r dimensional system
datatrans=[];
cLt=cell(iT,1);                                          
H=cell(iT,1);                                    % Loadings matrix at time t
% Inv Error variance transformed
for i=1:iN
    for t=1:iT
        cLt{t,1}(i,:)=cL{i,1}(t,:);
    end
end
for t=1:iT
    temp=[];
    temp=bsxfun(@rdivide,cLt{t,1},vPsi); 
    H{t}= (temp'*cLt{t,1})\eye(iR);
    datatrans(t,:)=(H{t,1}*(temp'*Data(t,:)'))';
end

% Specify the matrices
T=mRho;
Q=eye(iR);
start=zeros(iR,1);
% KF
mFactors=zeros(iT,iR);
vF=cell(iT,1);
vV=cell(iT,1);
vK=cell(iT,1);
vA=zeros(iT+1,iR);
mP=cell(iT+1,1);
vA(1,:)=start';                            
mP{1}=reshape((eye(iR^2)-kron(T,T))\reshape(Q,iR^2,1),iR,iR);

for i=1:iT
   vV{i} =datatrans(i,:)'-vA(i,:)';
   vF{i} = mP{i}+H{i};
   vK{i} = (vF{i}\(mP{i}*T'))';
   vA(i+1,:) = (T*vA(i,:)' + vK{i}*vV{i})';
   mP{i+1} = T*mP{i}*(T-vK{i})' + Q;
end
% SS
r_t=zeros(iR,1);
N_t=0;
for i=iT:-1:1
    mFactors(i,:)= (vA(i,:)'+mP{i}*r_t)';
    r_t=vF{i}\vV{i}+ (T-vK{i})'*r_t;
end

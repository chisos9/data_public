function [Value]= LoglikNomean(vP,Data,mF)
% Calculates the loglikelihood function by concentrating out the mean
% parameters
% Input:    vP - vector of parameters, not including means
%           Data - vector of data
%           mF - principal components/Factors
% Output:   Value - loglikelihood value
% 09/10/2015 - Works
iT = size(Data,1);
iR=size(mF,2);
vPtrans=vP;
for i=1:iR
    vPtrans(2*i)=exp(vP(2*i));
end   
vPtrans(end)=exp(vP(end));

if iR==1
    [vV,vVf,vF,vMean]= KFscalarNomean(vPtrans,Data,mF);
else
    [vV,vVf,vF,vMean]= KFNomean(vPtrans,Data,mF);
end
res=vV-vVf*vMean;
Value = (0.5*sum(log(vF))+0.5*bsxfun(@rdivide,res,vF)'*res)/iT;

if ~isreal(Value) || isnan(Value) || isinf(Value)
    Value=1e20;
end
%load results_Mar17

% Plot loadings
% One-year/three-month Treasure term spread

% fid = fopen('loadings_graphs.tex', 'w');
% for j=1:N
% %for j=[81, 100]
%     axis([dates(1) dates(end) -2 2])
%     plot(dates,cLoadings{j,1}(:,1),'k-',dates,cLoadings{j,1}(:,2),'k--',dates,cLoadings{j,1}(:,3),'k-.',dates,cLoadings{j,1}(:,4),'k:','LineWidth',1.5);
%     legend('Loading 1','Loading 2','Loading 3','Loading 4')
%     %legend('Loading 1','Loading 2','Loading 3','Loading 4','Location','NorthWest')
%     title(descrshort{j})
%     %saveas(gcf,['Plots\Loadings_' num2str(j)],'jpg');
%     print(['Plots\Loadings_' num2str(j)],'-djpeg','-r200');
%     fprintf(fid, ['\\includegraphics[width=\\figuresize]{/Users/Eric.Hillebrand/Dropbox/JoE_R_and_R/matlab/RealData/Plots/Loadings_' num2str(j) '.jpg}']);
%     fprintf(fid, '\n');
% end
% fclose(fid);

mR2=zeros(N,2);  % 1st col: R2 from constant loadings, 2nd col: R2 from t.-v. loadings
for j=1:N
    mCommon=cLoadings{j,1}.*mFsort;            
    vCommon=sum(mCommon')';                                  % Common component
    vY=Xcatsort(3:end,j);
    sYmean=mean(vY);
    sSStot=sum((vY-sYmean).^2);
    sSSres_tv=sum((vY-vCommon).^2);
    vCommon_const=mFsort*Lambda(j,:)';
    sSSres_const=sum((vY-vCommon_const).^2);
    mR2(j,1)=1-sSSres_const/sSStot;
    mR2(j,2)=1-sSSres_tv/sSStot;
%     if (j==24) || (j==52)
%         keyboard
%     end
end
%     
%     
% %% Code for R2 table.
% numSigFigs = 2;
% fid = fopen('R2table.tex', 'w');
% rows = 37;
% cols = 9;
% for i = 1:rows
%       fprintf(fid, ['\\scriptsize{' descrshort{i} '} &']);
%       fprintf(fid, ['\\scriptsize{' num2str(mR2(i, 1), numSigFigs) '} &']);
%       fprintf(fid, ['\\scriptsize{' num2str(mR2(i, 2), numSigFigs) '} &']);
%       fprintf(fid, ['\\scriptsize{' descrshort{i+37} '} &']);
%       fprintf(fid, ['\\scriptsize{' num2str(mR2(i+37, 1), numSigFigs) '} &']);
%       fprintf(fid, ['\\scriptsize{' num2str(mR2(i+37, 2), numSigFigs) '} &']);
%       if 74+i<110
%           fprintf(fid, ['\\scriptsize{' descrshort{i+74} '} &']);
%           fprintf(fid, ['\\scriptsize{' num2str(mR2(i+74, 1), numSigFigs) '} &']);
%           fprintf(fid, ['\\scriptsize{' num2str(mR2(i+74, 2), numSigFigs) '}']);
%       else
%           fprintf(fid, ' &  & ');
%       end
%       fprintf(fid, '\\\\\n');
% end
% fclose(fid);

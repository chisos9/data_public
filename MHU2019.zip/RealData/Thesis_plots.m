% New plots for Thesis - ML paper
% August 2016 - works 17/08/2016
clc
clear
% Load data
X=xlsread('data');
trans=xlsread('trans_code');
Category=xlsread('tab4code');
[~, ~, name] = xlsread('name.xlsx','Sheet1');
name(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),name)) = {''};
[~, ~, descrshort] = xlsread('descr_short.xlsx','Sheet1');
descrshort(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),descrshort)) = {''};
dates=xlsread('dates');
% format short g
Catnames={'Out', 'Cons', 'Labor', 'Housing', 'Inv.', 'Prices & Wages' ,'Financial', 'Money', 'Other'};

% Sort data
Ident = [1:size(X,2)];
Xcat=[Ident;Category; X];
Xcatsort=sortrows(Xcat',2)';
barnames= cellfun(@num2str,num2cell(Xcatsort(2,:)),'UniformOutput',false)';

% Estimate Factors
[T,N]=size(X);
iR = 4;                                     % Number of factors
% mF = PC(X,iR);
% mFsort=PC(Xcatsort(3:end,:),iR);
% vEig=eigs(X'*X,size(X,2)-1);                % Eigenvalue of covariance matrix
% vEigShare = cumsum(vEig)/sum(vEig);
% mFsort(:,1)=-mFsort(:,1);
% mFsort(:,2)=-mFsort(:,2);
% mFsort(:,3)=-mFsort(:,3);
% save(['Results/Factors'],'mFsort');


% For new plots, write '_august' in file names.
load(['Results/Factors_august'],'mFsort');
load(['Results/Parameters_august'],'mParm');
load(['Results/KS_Loadings_august'],'cLoadings');
% Uncomment for original graphs
%  mFsort(:,1)=-mFsort(:,1);
%  % mFsort(:,2)=-mFsort(:,2);
%  mFsort(:,3)=-mFsort(:,3);
%  % mFsort(:,4)=-mFsort(:,4);
lineStyles = linspecer(iR,'qualitative');
z=figure('Position', [100, 100, 1049, 895])
for i=1:4
    hold on
    plot(dates,cLoadings{81,1}(:,i),'color',lineStyles(i,:),'LineWidth',1)
end
axis tight
set(gca,'fontsize',20)
set(0,'defaulttextinterpreter','tex')
%xlabel('T','FontSize',20)
set(0,'defaulttextinterpreter','latex')
leg=legend('Loading 1','Loading 2','Loading 3','Loading 4','Location','northeast');
set(leg,'FontSize',18);
print(z,'-depsc','-r144',['Term_spread_loadings_august_new_est']);
close(z);

% Plot common component
mCommon=cLoadings{81,1}.*mFsort;            
vCommon=sum(mCommon')';                                  % Common component
vOLSfull=mFsort*mFsort'*Xcatsort(3:end,81)./T;          % Common component OLS full sample
vOLSsplit1=mFsort(1:98,:)*mFsort(1:98,:)'*Xcatsort(3:100,81)/98;        % Common component OLS split sample
vOLSsplit2=mFsort(99:end,:)*mFsort(99:end,:)'*Xcatsort(101:end,81)./92;
vOLSsplit=[vOLSsplit1 ; vOLSsplit2];
% CC=[ vCommon vOLSsplit vOLSfull Xcatsort(3:end,81)];
CC=[ Xcatsort(3:end,81) vCommon vOLSfull ];
lineStyles = linspecer(iR,'qualitative');
z=figure('Position', [100, 100, 1049, 895])
for i=1:size(CC,2)
hold on
% plot(dates,cLoadings{81,1}(:,1),'b',dates,cLoadings{81,1}(:,2),'g',dates,cLoadings{81,1}(:,3),dates,cLoadings{81,1}(:,4));
% plot(dates,[vCommon vOLSsplit vOLSfull]);
plot(dates,CC(:,i),'Color',lineStyles(i,:),'LineWidth',1);
% plot(dates,CC(:,i));
end
% legend(['KS         '; 'LS-split   ';'LS-full    ';'Term spread']);
axis tight
set(gca,'fontsize',20)
set(0,'defaulttextinterpreter','tex')
%xlabel('T','FontSize',20)
set(0,'defaulttextinterpreter','latex')
leg=legend('Term spread','CC: Time-varying loadings','CC: Constant loadings');
set(leg,'FontSize',18);
print(z,'-depsc','-r144',['Common_component_KS_OLS_august_new_est']);
close(z);

function [mF] = PC(mX,iR)
% PC - Calculates principal components - uses F'F/T=I identification
% Input:    mX is a TxN matrix of data
%           iR is the estimated number of factors
% Output    mF is a TxR matrix of factors
%           mL is a NxR matrix of loadings
%

iT = size(mX,1);
Z = mX;
[A2,~]=eigs(Z*Z',iR);
mF = sqrt(iT)*A2;


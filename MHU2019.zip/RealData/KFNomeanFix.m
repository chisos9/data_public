function [vV,mV,vF,vMean]= KFNomeanFix(vP,Data,matF,k)
% The Kalman filter for DFM by concentrating out means
% Input:    vP - vector of parameters, no mean parameters
%           Data - Data
%           mF - principal components/factors
%           k - index number for constant factor loading
% Output:   vF - vector of prediction error variances
%           vV - vector of predictione errors for data
%           mVf - matrix of predictione errors for factors
%           vMean - Mean estimate
%     Works 09/10/2015

% Specify the matrices
iR=size(matF,2);
iRk=iR-1;
f=matF;                 % All factors
fk=f;
fk(:,k)=[];
f_fix=f(:,k);
T=eye(iRk);
Q=eye(iRk);
P_t=eye(iRk);

for j=1:iRk
    T(j,j)=vP(2*j-1);
    Q(j,j)=vP(2*j);
    P_t(j,j)=Q(j,j)/(1-T(j,j)^2);
end
sigmaeps=vP(end);

% KF
iT=size(Data,1);
vF=zeros(iT+1,1);
vV=zeros(iT+1,1);
mVf=zeros(iT+1,iRk);
mVf_fix=zeros(iT+1,1);
a_t=zeros(iRk,1);  
afix_t=zeros(iRk,1); 
Af_t=zeros(iRk,iRk);
for i=1:iT
   vV(i) = Data(i)-fk(i,:)*a_t;
   mVf(i,:) = fk(i,:)-fk(i,:)*Af_t;  
   mVf_fix(i)= f_fix(i)-fk(i,:)*afix_t;
   vF(i) = fk(i,:)*P_t*fk(i,:)'+sigmaeps;
   temp = P_t*fk(i,:)'/vF(i);
   a_tt = a_t+temp*vV(i); 
   afix_tt = afix_t+temp*mVf_fix(i); 
   Af_tt = Af_t+ temp*mVf(i,:); 
   P_tt=P_t - temp*fk(i,:)*P_t;
   a_t = T*a_tt;   
   Af_t = T*Af_tt;
   afix_t = T*afix_tt;   
   P_t = T*P_tt*T' + Q;
end
vV = vV(1:iT,1);  % Delete the last element as it is only relevant for forecasting 
mVf = mVf(1:iT,:);  % Delete the last element as it is only relevant for forecasting 
mVf_fix = mVf_fix(1:iT,:);  % Delete the last element as it is only relevant for forecasting 
vF = vF(1:iT);    % Same here
mV=[];
j=0;
for i=1:iR
    if i==k
        mV=[mV mVf_fix];
    else
        j=j+1;
        mV =[mV mVf(:,j)];
    end
end
XdivF =bsxfun(@rdivide,mV,vF)';
vMean = (XdivF*mV)\(XdivF*vV);